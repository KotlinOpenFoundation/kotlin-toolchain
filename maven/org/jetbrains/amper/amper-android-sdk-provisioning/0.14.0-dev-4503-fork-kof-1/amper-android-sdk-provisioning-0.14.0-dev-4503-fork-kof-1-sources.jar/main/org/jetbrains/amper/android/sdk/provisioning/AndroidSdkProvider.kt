/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.android.sdk.provisioning

import com.android.repository.api.ConsoleProgressIndicator
import com.android.repository.api.License
import com.android.repository.api.LocalPackage
import com.android.repository.api.RemotePackage
import com.android.repository.api.RepoManager
import com.android.repository.api.RepoPackage
import com.android.repository.api.Repository
import com.android.repository.impl.meta.LocalPackageImpl
import com.android.repository.impl.meta.SchemaModuleUtil
import com.android.sdklib.repository.AndroidSdkHandler
import com.android.sdklib.repository.meta.DetailsTypes
import io.ktor.http.*
import io.opentelemetry.api.OpenTelemetry
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.withLock
import org.apache.maven.artifact.versioning.ComparableVersion
import org.jetbrains.amper.concurrency.AsyncConcurrentMap
import org.jetbrains.amper.concurrency.StripedFileMutexGroup
import org.jetbrains.amper.concurrency.StripedMutex
import org.jetbrains.amper.concurrency.withDoubleLock
import org.jetbrains.amper.core.AmperUserCacheRoot
import org.jetbrains.amper.core.UsedInIdePlugin
import org.jetbrains.amper.core.downloader.Downloader
import org.jetbrains.amper.core.extract.ExtractOptions
import org.jetbrains.amper.core.extract.extractFileToLocation
import org.jetbrains.amper.events.sink.OperationEventSink
import org.jetbrains.amper.events.sink.operationEventScope
import org.jetbrains.amper.incrementalcache.IncrementalCache
import org.jetbrains.amper.problems.reporting.BuildProblem
import org.jetbrains.amper.problems.reporting.BuildProblemSource
import org.jetbrains.amper.problems.reporting.BuildProblemType
import org.jetbrains.amper.problems.reporting.DiagnosticId
import org.jetbrains.amper.problems.reporting.GlobalBuildProblemSource
import org.jetbrains.amper.problems.reporting.Level
import org.jetbrains.amper.problems.reporting.NonIdealDiagnostic
import org.jetbrains.amper.problems.reporting.ProblemReporter
import org.jetbrains.amper.telemetry.use
import org.jetbrains.amper.telemetry.useWithoutCoroutines
import org.jetbrains.annotations.Nls
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Path
import javax.xml.bind.JAXBElement
import kotlin.io.path.createDirectories
import kotlin.io.path.deleteRecursively
import kotlin.io.path.div
import kotlin.io.path.exists
import kotlin.io.path.inputStream
import kotlin.io.path.isDirectory
import kotlin.io.path.listDirectoryEntries
import kotlin.io.path.name
import kotlin.io.path.outputStream
import kotlin.io.path.relativeTo

data object FailedToAcceptAndroidLicenseId : DiagnosticId

@OptIn(NonIdealDiagnostic::class)
data class FailedToAcceptAndroidLicense(
    val licenseId: AndroidLicenseId,
    val sdkRoot: Path,
) : BuildProblem {
    override val diagnosticId: DiagnosticId = FailedToAcceptAndroidLicenseId
    override val source: BuildProblemSource = GlobalBuildProblemSource
    override val message: @Nls String = AndroidSdkProvisioningBundle.message(
        "android.license.accept.failed",
        licenseId,
        sdkRoot / License.LICENSE_DIR,
    )
    override val level: Level = Level.Error
    override val type: BuildProblemType = BuildProblemType.Generic
}

/**
 * Provisions Android SDK packages into [sdkRoot].
 *
 * Archive downloads are shared through [AmperUserCacheRoot], while package installation is synchronized per
 * SDK root and package path. [IncrementalCache] caches both repository XML lists and license validation results.
 */
class AndroidSdkProvider(
    private val userCacheRoot: AmperUserCacheRoot,
    private val incrementalCache: IncrementalCache,
    openTelemetry: OpenTelemetry = OpenTelemetry.noop(),
    val sdkRoot: Path = AndroidSdkDetector.detectSdkPath(),
    val unacceptedLicenseHandler: AndroidUnacceptedLicenseHandler = AndroidUnacceptedLicenseHandler.DontAccept,
) {
    private val tracer = openTelemetry.getTracer("org.jetbrains.amper.android.sdk.provisioning")
    private val repositoryXmlListsProvider = AndroidSdkRepositoryXmlListsProvider(
        openTelemetry = openTelemetry,
        userCacheRoot = userCacheRoot,
        incrementalCache = incrementalCache,
    )
    private val repositories = AsyncConcurrentMap<AndroidSdkRepository, Repository>()
    private val packages = AsyncConcurrentMap<AndroidSdkPackageRequest, AndroidSdkResult>()
    private val packagesMutexGroup = StripedFileMutexGroup(256)
    private val licenseHandlingMutex = StripedMutex()
    private val handledLicenses = mutableSetOf<AndroidLicenseId>()

    init {
        sdkRoot.createDirectories()
    }

    /**
     * Finds or provisions the SDK package based on the [request].
     *
     * Potential errors in the local SDK storage are reported via [localPackageProblemReporter]
     * (e.g., if the local package is corrupted).
     * The provisioning failures itself are reported as [AndroidSdkResult.Error]s.
     */
    @UsedInIdePlugin
    context(localPackageProblemReporter: ProblemReporter, _: OperationEventSink)
    suspend fun provision(request: AndroidSdkPackageRequest): AndroidSdkResult =
        tracer.spanBuilder("Provision Android SDK package $request")
            .use { span ->
                span.setAttribute("from-memory-cache", true)
                packages.computeIfAbsent(request) {
                    span.setAttribute("from-memory-cache", false)
                    val installedPackage = install(request)
                        ?: return@computeIfAbsent AndroidSdkResult.Error("Failed to provision ${request.displayName}")
                    val license = AndroidSdkBackedLicense(sdkRoot, installedPackage.license)
                    handlePackageLicense(installedPackage.detailedDisplayName, license)

                    AndroidSdkResult.Success(
                        AndroidSdkPackage(
                            packagePath = installedPackage.packagePath,
                            location = installedPackage.packagePath.toLocalPath(),
                            license = license,
                        )
                    )
                }
            }

    private class AndroidSdkBackedLicense(private val sdkRoot: Path, val license: License) : AndroidLicense {
        override val licenseId
            get() = AndroidLicenseId(license.id)

        override val text: String
            get() = license.value

        override fun isAccepted(): Boolean = license.checkAccepted(sdkRoot)
    }

    context(_: ProblemReporter, _: OperationEventSink)
    private suspend fun install(request: AndroidSdkPackageRequest): RepoPackage? =
        when (request) {
            // TODO: Some packages have no version qualifiers or use "latest".
            //  In that case it might make sense to compare it somehow with the remote version (checksum?).
            AndroidSdkPackageRequest.Emulator -> findAndInstallExactPackage(
                PackagePath("emulator"),
                AndroidSdkRepository.Main,
            )
            is AndroidSdkPackageRequest.CommandLineTools -> findAndInstallExactPackage(
                PackagePath("cmdline-tools;${request.version}"),
                AndroidSdkRepository.Main,
            )
            AndroidSdkPackageRequest.PlatformTools -> findAndInstallExactPackage(
                PackagePath("platform-tools"),
                AndroidSdkRepository.Main,
            )
            is AndroidSdkPackageRequest.BuildTools -> findAndInstallExactPackage(
                PackagePath("build-tools;${request.version}"),
                AndroidSdkRepository.Main,
            )
            is AndroidSdkPackageRequest.Platform -> findAndInstallExactPackage(
                request.packagePath,
                AndroidSdkRepository.Main
            )
            is AndroidSdkPackageRequest.PlatformSources -> findAndInstallExactPackage(
                request.packagePath,
                AndroidSdkRepository.Main,
            )
            is AndroidSdkPackageRequest.SystemImage -> installSystemImage(request)
        }

    /**
     * Passes previously unmet unaccepted licenses to [unacceptedLicenseHandler].
     *
     * If the handler returned `true`, marks the license as accepted.
     */
    context(problemReporter: ProblemReporter, _: OperationEventSink)
    private suspend fun handlePackageLicense(
        packageDisplayName: String,
        license: AndroidSdkBackedLicense,
    ) = licenseHandlingMutex.getMutex(license.licenseId.hashCode()).withLock {
        if (!license.isAccepted() && handledLicenses.add(license.licenseId)) {
            val accepted = unacceptedLicenseHandler.onUnacceptedLicense(packageDisplayName, license)
            if (accepted) {
                val success = license.license.setAccepted(sdkRoot)
                if (!success) {
                    problemReporter.reportMessage(FailedToAcceptAndroidLicense(license.licenseId, sdkRoot))
                }
            }
        }
    }

    private val AndroidSdkPackageRequest.Platform.packagePath: PackagePath
        get() = PackagePath(buildString {
            append("platforms;android-")
            append(platformVersionString(apiLevel, minorApiLevel, sdkExtension))
        })

    private val AndroidSdkPackageRequest.PlatformSources.packagePath: PackagePath
        get() = PackagePath(buildString {
            append("sources;android-")
            append(platformVersionString(apiLevel, minorApiLevel))
        })

    private fun platformVersionString(
        apiLevel: Int,
        minorApiLevel: Int,
        sdkExtension: Int? = null,
    ): String = buildString {
        append(apiLevel)
        if (apiLevel >= 37 || minorApiLevel != 0) {
            // Minor API level 0 started being published at API 37. API 36 has only 36 and 36.1.
            append(".$minorApiLevel")
        }
        sdkExtension?.let { append("-ext$it") }
    }

    context(_: ProblemReporter, _: OperationEventSink)
    private suspend fun installSystemImage(request: AndroidSdkPackageRequest.SystemImage): RepoPackage? {
        val lockName = "system-images;android;${request.tag.value};${request.abi.repositoryValue}.lock"
        return packagesMutexGroup.withDoubleLock(sdkRoot / lockName) {
            val localPackage = request.findBestPackageLocally(sdkRoot)
            if (localPackage != null) {
                val deducedPath = PackagePath(localPackage.relativeTo(sdkRoot).joinToString(";"))
                val localPackage = readLocalPackage(deducedPath, localPackage)
                if (localPackage != null) return@withDoubleLock localPackage
                // Fallback to downloading remote package if failed to read it locally
            }

            val remotePackages = getRepository(AndroidSdkRepository.SystemImages).remotePackage
            val alignedName = request.findBestPackageRemotely(remotePackages) ?: return@withDoubleLock null
            installPackageFromRemote(alignedName, remotePackages, AndroidSdkRepository.SystemImages)
        }
    }

    context(_: ProblemReporter, _: OperationEventSink)
    private suspend fun findAndInstallExactPackage(
        packagePath: PackagePath,
        repository: AndroidSdkRepository,
    ): RepoPackage? =
        packagesMutexGroup.withDoubleLock(sdkRoot / "$packagePath.lock") {
            val installedPackagePath = packagePath.toLocalPath()
            if (installedPackagePath.isDirectory()) {
                val localPackage = readLocalPackage(packagePath, installedPackagePath)
                if (localPackage != null) return@withDoubleLock localPackage
                // Fallback to downloading remote package if failed to read it locally
            }

            val remotePackages = getRepository(repository).remotePackage
            installPackageFromRemote(packagePath, remotePackages, repository)
        }

    context(problemReporter: ProblemReporter)
    private fun readLocalPackage(packagePath: PackagePath, path: Path): RepoPackage? =
        tracer.spanBuilder("Read local Android SDK package").useWithoutCoroutines {
            val packageManifest = path / "package.xml"
            if (!packageManifest.exists()) {
                problemReporter.reportMessage(LocalPackageWithoutManifest(packagePath, path))
                return@useWithoutCoroutines null
            }
            packageManifest.readRepository().localPackage
        }

    context(_: ProblemReporter, _: OperationEventSink)
    private suspend fun installPackageFromRemote(
        packagePath: PackagePath,
        remotePackages: List<RemotePackage>,
        repository: AndroidSdkRepository,
    ): RepoPackage? {
        val pkg = remotePackages.firstOrNull { it.path == packagePath.path } ?: return null
        return coroutineScope {
            // Ask for the license acceptance right away before downloading in non-blocking manner
            val licenseHandlingJob =
                async { handlePackageLicense(pkg.displayName, AndroidSdkBackedLicense(sdkRoot, pkg.license)) }
            val remotePackage = installRemotePackage(pkg, URLBuilder(repository.baseUrl))
            // Await for the license handling result before returning the package
            licenseHandlingJob.await()
            remotePackage
        }
    }

    context(_: OperationEventSink)
    private suspend fun installRemotePackage(pkg: RemotePackage, repositoryBaseUrlBuilder: URLBuilder): RepoPackage {
        val localPackagePath = pkg.packagePath.toLocalPath()
        val url = repositoryBaseUrlBuilder.appendPathSegments(pkg.archive.complete.url).build()
        val path = tracer.spanBuilder("Download Android SDK package ${pkg.path}").use {
            operationEventScope("downloading ${pkg.displayName}") {
                Downloader.downloadFileToCacheLocation(
                    url = url.toString(),
                    userCacheRoot = userCacheRoot,
                    knownContentLengthHint = pkg.archive.complete.size,
                )
            }
        }
        return tracer.spanBuilder("Install Android SDK package files ${pkg.path}").use {
            // Clean up possible leftovers of the old package
            if (localPackagePath.exists()) localPackagePath.deleteRecursively()
            operationEventScope("extracting ${pkg.displayName}") {
                extractFileToLocation(path, localPackagePath, ExtractOptions.STRIP_ROOT)
            }
            writePackageXml(pkg, localPackagePath)
        }
    }

    private fun PackagePath.toLocalPath(): Path =
        path.split(";").fold(sdkRoot) { dir, component -> dir.resolve(component) }

    context(_: OperationEventSink)
    private suspend fun getRepository(repository: AndroidSdkRepository): Repository =
        operationEventScope("reading Android repository ${repository.name}") {
            tracer.spanBuilder("Read Android repository ${repository.name}")
                .setAttribute("repository-name", repository.name)
                .setAttribute("repository-url", repository.packageUrl.toString())
                .use { span ->
                    span.setAttribute("from-memory-cache", true)
                    repositories.computeIfAbsent(repository) {
                        span.setAttribute("from-memory-cache", false)
                        repositoryXmlListsProvider.getRepositoryXml(repository).readRepository()
                    }
                }
        }

    private fun writePackageXml(pkg: RemotePackage, localPackagePath: Path): LocalPackage {
        val localPackage = LocalPackageImpl.create(pkg)
        val factory = pkg.createFactory()
        val repo = factory.createRepositoryType()
        repo.setLocalPackage(localPackage)
        repo.addLicense(pkg.license)
        (localPackagePath / "package.xml").outputStream().use { outputStream ->
            tracer.spanBuilder("Write package xml").useWithoutCoroutines {
                outputStream.marshal(factory.generateRepository(repo))
            }
        }
        return localPackage
    }

    private fun Path.readRepository(): Repository = inputStream().use { inputStream ->
        tracer.spanBuilder("Parsing repository from $this").useWithoutCoroutines {
            inputStream.unmarshal<Repository>()
        }
    }

    private inline fun <reified T> InputStream.unmarshal(): T = SchemaModuleUtil.unmarshal(
        this,
        listOf(
            AndroidSdkHandler.repositoryModule,
            AndroidSdkHandler.addonModule,
            AndroidSdkHandler.sysImgModule,
            AndroidSdkHandler.commonModule,
            RepoManager.genericModule,
            RepoManager.commonModule,
        ),
        true,
        ConsoleProgressIndicator(),
        ""
    ) as T

    private fun <T> OutputStream.marshal(obj: T) {
        val allModules = setOf(
            AndroidSdkHandler.repositoryModule,
            AndroidSdkHandler.addonModule,
            AndroidSdkHandler.sysImgModule,
            AndroidSdkHandler.commonModule,
            RepoManager.genericModule,
            RepoManager.commonModule,
        )
        val resourceResolver = SchemaModuleUtil.createResourceResolver(allModules, ConsoleProgressIndicator())
        SchemaModuleUtil.marshal(
            obj as JAXBElement<*>,
            allModules,
            this,
            resourceResolver,
            ConsoleProgressIndicator(),
            true,
        )
    }
}

private val RepoPackage.packagePath: PackagePath get() = PackagePath(path)

private data class LocalSystemImage(val version: ComparableVersion, val servicesRoot: Path)

private fun AndroidSdkPackageRequest.SystemImage.findBestPackageLocally(sdkHome: Path): Path? {
    val systemImagesHome = sdkHome / "system-images"
    if (!systemImagesHome.exists()) return null

    val acceptableVersion = ComparableVersion("$minimalAcceptableApiLevel")
    val (servicesRoot) = systemImagesHome.listDirectoryEntries(glob = "android-*")
        .mapNotNull { imageRoot ->
            // Preview images are skipped here for the same reason as in findBestPackageRemotely
            val version = imageRoot.stableApiVersionOrNull() ?: return@mapNotNull null
            if (version < acceptableVersion) return@mapNotNull null

            val acceptableTag = imageRoot.listDirectoryEntries()
                .sortedBy { it.name } // Sort for consistent choice
                .filter { child ->
                    when (tag) {
                        AndroidSdkPackageRequest.SystemImage.ServicesTag.GoogleApis -> child.name == "google_apis" || child.name == "google_apis_ps16k"
                    }
                }
                .firstOrNull { child ->
                    (child / abi.repositoryValue).exists()
                }
            if (acceptableTag == null) return@mapNotNull null
            LocalSystemImage(version, acceptableTag)
        }
        .maxByOrNull { it.version } ?: return null
    return servicesRoot / abi.repositoryValue
}

/**
 * Regex matching the directory name of a stable system image, such as `android-37`, `android-37.2`, or
 * `android-36-ext19`.
 *
 * Preview images are named after their codename or preview build instead (`android-CANARY`,
 * `android-canary-20260909`, `android-37.2-beta1`), and thus don't match this pattern.
 */
private val stableSystemImageDirRegex = Regex("""android-(?<version>\d+(?:\.\d+)?(?:-ext\d+)?)""")

/**
 * Returns the API version of this local system image directory, or null if it is not a stable image directory.
 */
private fun Path.stableApiVersionOrNull(): ComparableVersion? {
    val match = stableSystemImageDirRegex.matchEntire(name) ?: return null
    val version = match.groups["version"] ?: error("regex matches but mandatory group 'version' is absent")
    return ComparableVersion(version.value)
}

private fun AndroidSdkPackageRequest.SystemImage.findBestPackageRemotely(packages: List<RemotePackage>): PackagePath? {
    return packages.filter { remotePackage ->
        val typeDetails = remotePackage.typeDetails as? DetailsTypes.SysImgDetailsType ?: return@filter false
        // We can't use the channel as an indicator of a stable package, because preview packages (beta, canary) are
        // published to the stable channel. Preview packages are instead identified by their codename.
        if (typeDetails.codename != null) return@filter false

        // We want to download the latest available system image so that it's suitable for most of the projects later on
        typeDetails.apiLevel >= minimalAcceptableApiLevel &&
                typeDetails.abis.contains(abi.repositoryValue) &&
                typeDetails.tags.map { it.id }.contains(tag.value)
    }.maxByOrNull { remotePackage ->
        val typeDetails = remotePackage.typeDetails as DetailsTypes.SysImgDetailsType // already filtered above
        ComparableVersion(typeDetails.apiLevelString)
    }?.packagePath
}
