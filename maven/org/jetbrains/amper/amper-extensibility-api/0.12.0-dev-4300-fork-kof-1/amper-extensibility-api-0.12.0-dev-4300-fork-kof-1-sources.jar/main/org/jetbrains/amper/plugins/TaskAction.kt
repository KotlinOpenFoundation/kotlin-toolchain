/*
 * Copyright 2000-2025 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.plugins

/**
 * Annotates a *top-level* Kotlin function, marking it as a possible task action.
 * Such a function must return [Unit] and may have any number of parameters. The allowed parameter types are the same as
 * for properties in [Configurable]-annotated interfaces.
 *
 * In addition, [java.nio.file.Path] parameters must be annotated with either [Input] or [Output].
 */
@MustBeDocumented
@Retention(AnnotationRetention.BINARY)
@Target(AnnotationTarget.FUNCTION)
annotation class TaskAction(
    /**
     * Execution avoidance strategy for the task action.
     */
    val executionAvoidance: ExecutionAvoidance = ExecutionAvoidance.Automatic,
)
