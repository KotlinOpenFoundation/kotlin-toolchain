/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.plugins.schema.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import org.jetbrains.amper.serialization.paths.SerializablePath

/**
 * Contains all the knowledge about a plugin that is required for the frontend to function.
 *
 * - This includes the general plugin information: [id], [description], [source]
 * - Information about the `module.yaml` schema extension for the plugin:
 *   [pluginSettingsSearchResult] (may be `null` if plugin has no user configuration).
 * - Schema types/tasks descriptions: [declarations]
 */
@Serializable
data class PluginData(
    val id: Id,
    val pluginSettingsSearchResult: PluginSettingsSearchResult? = null,
    val description: String? = null,
    val source: Source,
    val declarations: Declarations,
) {
    @Serializable
    data class Declarations(
        val enums: List<EnumData> = emptyList(),
        val classes: List<ClassData> = emptyList(),
        val variants: List<VariantData> = emptyList(),
        val tasks: List<TaskInfo> = emptyList(),
    )

    @Serializable(SchemaNameSerializer::class)
    data class SchemaName(
        val packageName: String,
        val simpleNames: List<String>,
    ) : Comparable<SchemaName> {
        val qualifiedName: String by lazy {
            buildString {
                if (packageName.isNotEmpty()) append(packageName).append('.')
                simpleNames.joinTo(this, ".")
            }
        }

        fun reflectionName() = buildString {
            if (packageName.isNotEmpty()) append(packageName).append('.')
            simpleNames.joinTo(this, "$")
        }

        override fun compareTo(other: SchemaName): Int = qualifiedName.compareTo(other.qualifiedName)
    }

    @Serializable
    @JvmInline
    value class Id(
        val value: String,
    )

    @Serializable
    sealed interface Source {
        /**
         * The [path] points to the module directory of the plugin.
         */
        @Serializable
        data class Local(val path: SerializablePath): Source
    }

    @Serializable
    data class InternalAttributes(
        val isExternalDependencyNotation: Boolean = false,
    )
    
    @Serializable
    data class VariantData(
        val name: SchemaName,
        val variants: List<Type.ObjectType>,
        val origin: SourceLocation? = null,
    )

    @Serializable
    data class EnumData(
        val schemaName: SchemaName,
        val entries: List<Entry>,
        val origin: SourceLocation? = null,
    ) {
        @Serializable
        data class Entry(
            val name: String,
            val schemaName: String,
            val doc: String? = null,
            val origin: SourceLocation? = null,
        )
    }
    
    @Serializable
    data class ClassData(
        val name: SchemaName,
        val properties: List<Property> = emptyList(),
        val doc: String? = null,
        val origin: SourceLocation? = null,
        val internalAttributes: InternalAttributes? = null,
    ) {
        @Serializable
        data class InternalPropertyAttributes(
            val isProvided: Boolean = false,
            val isShorthand: Boolean = false,
            val isDependencyNotation: Boolean = false,
        )

        @Serializable
        data class Property(
            val name: String,
            val type: Type,
            val default: Defaults? = null,
            val doc: String? = null,
            val origin: SourceLocation? = null,
            val inputOutputMark: InputOutputMark? = null,
            val internalAttributes: InternalPropertyAttributes? = null,
        )
    }

    @Serializable
    sealed interface Type {
        val isNullable: Boolean

        @Serializable
        @SerialName("boolean")
        data class BooleanType(
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("int")
        data class IntType(
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("string")
        data class StringType(
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("path")
        data class PathType(
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("enum")
        data class EnumType(
            val schemaName: SchemaName,
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("map")
        data class MapType(
            val valueType: Type,
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("list")
        data class ListType(
            val elementType: Type,
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("object")
        data class ObjectType(
            val schemaName: SchemaName,
            override val isNullable: Boolean = false,
        ) : Type

        @Serializable
        @SerialName("variant")
        data class VariantType(
            val schemaName: SchemaName,
            override val isNullable: Boolean = false,
        ) : Type
    }

    @Serializable
    data class TaskInfo(
        /**
         * An "imaginary" class type that holds all the task's named parameters.
         * It's used to configure the task in the frontend.
         */
        val syntheticType: ClassData,
        val jvmFunctionClassName: String,
        val jvmFunctionName: String,
        val optOutOfExecutionAvoidance: Boolean = false,
    )
}