/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.jdk.provisioning

import io.opentelemetry.api.OpenTelemetry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import org.jetbrains.amper.core.AmperUserCacheRoot
import org.jetbrains.amper.core.downloader.Downloader
import org.jetbrains.amper.events.sink.OperationEventSink
import org.jetbrains.amper.events.sink.operationEventScope
import org.jetbrains.amper.frontend.schema.JvmDistribution
import org.jetbrains.amper.incrementalcache.IncrementalCache
import org.jetbrains.amper.incrementalcache.ResultWithSerializable
import org.jetbrains.amper.incrementalcache.execute
import org.jetbrains.amper.jdks.IjJdkArchitecture
import org.jetbrains.amper.jdks.IjJdkFamily
import org.jetbrains.amper.jdks.IjJdkOs
import org.jetbrains.amper.jdks.JetBrainsJdksJsonUrl
import org.jetbrains.amper.jdks.readIjJdks
import org.jetbrains.amper.system.info.Arch
import org.jetbrains.amper.system.info.OsFamily
import org.jetbrains.amper.telemetry.use
import kotlin.io.path.inputStream
import kotlin.time.Clock
import kotlin.time.Duration
import kotlin.time.Duration.Companion.hours

internal class JdkListProvider(
    private val openTelemetry: OpenTelemetry,
    private val userCacheRoot: AmperUserCacheRoot,
    private val incrementalCache: IncrementalCache,
    private val listValidityPeriod: Duration = 24.hours,
) {
    private val mutex = Mutex()
    private var jdkPackages: List<JdkPackage>? = null

    /**
     * Fetches the metadata of the JDKs that can be provisioned. The list is cached in memory.
     */
    context(_: OperationEventSink)
    suspend fun getOrFetch(): List<JdkPackage> = openTelemetry.tracer.spanBuilder("Get JDK list").use {
        jdkPackages ?: mutex.withLock {
            jdkPackages ?: fetchAndConvertWithTelemetry().also { packages ->
                jdkPackages = packages
            }
        }
    }

    context(_: OperationEventSink)
    private suspend fun fetchAndConvertWithTelemetry(): List<JdkPackage> = incrementalCache.execute(
        key = "jdk-list-download",
        inputValues = emptyMap(),
        inputFiles = emptyList(),
        serializer = ListSerializer(JdkPackage.serializer()),
    ) {
        val jdkListFile = openTelemetry.tracer.spanBuilder("Fetch JDK list").use {
            operationEventScope("fetching JDK list") {
                Downloader.downloadFileToCacheLocation(
                    JetBrainsJdksJsonUrl,
                    userCacheRoot,
                    infoLog = false,
                    // The Downloader doesn't have any concept of expiration, so we need to manually delete files.
                    // We handle the caching mechanism ourselves via the project's incremental cache.
                    forceRedownload = true,
                )
            }
        }
        val jdks = openTelemetry.tracer.spanBuilder("Read JDK packages metadata").use {
            withContext(Dispatchers.IO) {
                jdkListFile.inputStream().use { it.readIjJdks() }
            }
        }
        val jdkPackages = openTelemetry.tracer.spanBuilder("Convert JDK packages metadata").use {
            jdks.toJdkPackages()
        }
        ResultWithSerializable(
            outputValue = jdkPackages,
            expirationTime = Clock.System.now() + listValidityPeriod,
        )
    }.outputValue
}

@Serializable
internal data class JdkPackage(
    val majorVersion: Int,
    val fullVersion: String,
    val distribution: JvmDistribution,
    val architecture: Arch,
    val operatingSystem: OsFamily,
    val downloadUrl: String,
) {
    override fun toString(): String = "${distribution.name} $fullVersion"
}

private fun List<IjJdkFamily>.toJdkPackages() = filter { !it.preview }.flatMap { it.toJdkPackages() }

private fun IjJdkFamily.toJdkPackages(): List<JdkPackage> = packages.mapNotNull { pkg ->
    JdkPackage(
        majorVersion = jdkVersionMajor,
        fullVersion = pkg.version,
        distribution = jvmDistributionOf(vendor, product) ?: return@mapNotNull null,
        architecture = pkg.arch.toArchitecture(),
        operatingSystem = pkg.os.toOperatingSystem(),
        downloadUrl = pkg.url,
    )
}

private fun jvmDistributionOf(vendor: String, productName: String): JvmDistribution? = when (vendor.lowercase()) {
    "alibaba" -> JvmDistribution.AlibabaDragonwell
    "amazon" -> JvmDistribution.AmazonCorretto
    "azul" -> JvmDistribution.AzulZulu
    "bellsoft" -> JvmDistribution.BellSoftLiberica
    "eclipse" -> JvmDistribution.EclipseTemurin
    "graalvm" -> JvmDistribution.GraalVMCommunityEdition
    "ibm" -> JvmDistribution.IbmSemeru
    "jetbrains" -> JvmDistribution.JetBrainsRuntime
    "microsoft" -> JvmDistribution.Microsoft
    "oracle" -> when (productName.lowercase()) {
        "graalvm" -> JvmDistribution.OracleGraalVM
        "openjdk" -> JvmDistribution.OracleOpenJdk
        else -> null
    }
    "sap" -> JvmDistribution.SapMachine
    else -> null
}

private fun IjJdkArchitecture.toArchitecture(): Arch = when (this) {
    IjJdkArchitecture.x64 -> Arch.X64
    IjJdkArchitecture.aarch64 -> Arch.Arm64
}

private fun IjJdkOs.toOperatingSystem(): OsFamily = when (this) {
    IjJdkOs.Linux -> OsFamily.Linux
    IjJdkOs.MacOS -> OsFamily.MacOs
    IjJdkOs.Windows -> OsFamily.Windows
}
