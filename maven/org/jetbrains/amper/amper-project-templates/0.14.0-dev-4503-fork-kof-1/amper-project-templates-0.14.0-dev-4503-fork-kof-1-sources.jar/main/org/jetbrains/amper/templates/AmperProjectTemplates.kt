/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.templates

import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromStream
import org.jetbrains.amper.templates.json.TemplateDescriptor
import org.jetbrains.amper.templates.json.TemplateResource
import org.jetbrains.annotations.Nls
import java.net.URL
import java.nio.file.Path
import java.util.*
import kotlin.io.path.createDirectories
import kotlin.io.path.outputStream
import kotlin.io.path.writeLines

/**
 * Accessor for Amper project templates.
 */
object AmperProjectTemplates {

    private val bundle = ResourceBundle.getBundle("messages.ProjectTemplatesBundle")

    /**
     * All available Amper project templates.
     */
    @OptIn(ExperimentalSerializationApi::class)
    val availableTemplates by lazy {
        javaClass.getResource("/templates/templates.json")
            ?.openStream()
            ?.use { Json.decodeFromStream<List<TemplateDescriptor>>(it) }
            ?.map { template ->
                AmperProjectTemplate(
                    id = template.id,
                    name = bundle.getString("template.${template.id}.name"),
                    description = bundle.getString("template.${template.id}.description"),
                    fileResources = template.resources,
                )
            }
            ?.sortedBy { it.name.lowercase() }
            ?: error("'templates.json' resource not found")
    }
}

/**
 * A predefined Amper project template, identified by [id].
 */
data class AmperProjectTemplate(
    val id: String,
    @Nls
    val name: String,
    @Nls
    val description: String,
    private val fileResources: List<TemplateResource>,
) {
    /**
     * Finds all files for this template in resources.
     */
    fun listFiles(): List<TemplateFile> = fileResources.map { res ->
        val resourceUrl = javaClass.getResource(res.name) ?: error("Missing resource in template '$id': $res")
        TemplateFile(resourceUrl = resourceUrl, relativePath = res.targetPath)
    }
}

/**
 * A file from an Amper project template.
 */
data class TemplateFile(
    /**
     * The URL to the resource for this file.
     */
    val resourceUrl: URL, // will be used in IDE wizard
    /**
     * The path to this file relative to the project root.
     */
    val relativePath: String,
) {
    /**
     * Extracts this file from the resources to the given [projectRoot], substituting the [TemplatePlaceholders] with
     * [projectId] and [projectName] (binary files are copied verbatim).
     *
     * [projectId] must be a valid dot-separated lowercase identifier, because it is used as a Kotlin package, an
     * Android namespace and application id, and an iOS bundle id. [projectName] is free-form: it is escaped for the
     * format of each file it appears in.
     *
     * If the file already exists in the project root, it will be overwritten.
     */
    fun extractTo(
        projectRoot: Path,
        projectId: String,
        projectName: String,
    ) = writeTo(projectRoot) { text ->
        TemplatePlaceholders.substituteIn(text, relativePath, projectId, projectName)
    }

    /**
     * Copies this file from the resources to the given [projectRoot] as is, without substituting any placeholders.
     * This is meant for templates that are ready to use without any customization.
     *
     * If the file already exists in the project root, it will be overwritten.
     */
    fun copyTo(projectRoot: Path) = writeTo(projectRoot) { it }

    private fun writeTo(projectRoot: Path, transformText: (String) -> String) {
        val path = projectRoot.resolve(relativePath)
        path.parent.createDirectories()
        if (isBinaryTemplateFile(relativePath)) {
            resourceUrl.openStream().use { input ->
                path.outputStream().use { output -> input.copyTo(output) }
            }
        } else {
            val text = resourceUrl.openStream().bufferedReader().use { it.readText() }
            path.writeLines(transformText(text).reader().readLines())
        }
    }
}
