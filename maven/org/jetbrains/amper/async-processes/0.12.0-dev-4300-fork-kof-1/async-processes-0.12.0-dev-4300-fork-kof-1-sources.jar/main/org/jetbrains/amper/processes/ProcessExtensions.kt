/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.processes

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.future.await
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.amper.processes.output.ProcessOutputListener
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.InvocationKind
import kotlin.contracts.contract
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * The default grace period to use in functions that provide this option.
 *
 * The grace period is the time to wait between a regular process destruction request and forcible destruction.
 * If a process doesn't terminate within the grace period after its destruction is requested, it is forcibly destroyed.
 */
@PublishedApi
internal val DefaultGracePeriod = 3.seconds

/**
 * Awaits the termination of this [Process] in a suspending and cancellable way.
 *
 * The given [outputListener] is used to handle lines of output from stdout/stderr while the process is running (for
 * instance to print them to the console).
 *
 * **Important:** the stream collection is performed on the current coroutine context, the dispatcher of which must
 * provide **at least 2 threads** (to perform blocking reads of stdout and stderr in parallel). It is the responsibility
 * of the caller to provide a suitable dispatcher.
 *
 * If this function is cancelled, the cancellation is immediate, but **the process is untouched and can keep running**.
 * The same applies if any exception is thrown (for instance, IO exceptions while reading streams).
 * The caller is responsible for ensuring the process doesn't leak, for instance using [withGuaranteedTermination].
 * The reason for this is that the caller of [ProcessBuilder.start] should be responsible for the life of the process.
 *
 * **Implementation note:** this function always waits for the coroutines reading IO streams to finish before returning,
 * ensuring we don't leak any coroutine nor hold on to extra threads. Non-network IO reads are not cancellable, but the
 * readers are made partially cooperative by allowing cancellation between each line read, so they don't have to keep
 * reading the whole stream if the result is meant to be discarded anyway.
 */
// NOT PUBLIC ON PURPOSE, please check the KDoc - the caller is responsible for too many things
internal suspend fun Process.awaitListening(outputListener: ProcessOutputListener): Int = coroutineScope {
    val pid = pid()
    launch {
        inputStream.consumeLinesBlockingCancellable {
            outputListener.onStdoutLine(it, pid)
        }
    }
    launch {
        errorStream.consumeLinesBlockingCancellable {
            outputListener.onStderrLine(it, pid)
        }
    }

    // This is async: onExit() runs on the ForkJoinPool so it doesn't hold the current thread.
    // This is why we only really need 2 threads in the current dispatcher (to consume stdout and stderr).
    onExit().await().exitValue().also { exitCode ->
        outputListener.onProcessTerminated(exitCode, pid)
    }
}

/**
 * Consumes this input stream by reading the data as UTF-8 text line-by-line, and calls [onEachLine] on each line.
 *
 * **WARNING:** this suspending function blocks the thread despite the suspend keyword!
 *
 * This function complies with coroutine cancellation by checking for cancellation between each line read. However, a
 * single line read blocks the thread and cannot be canceled until it returns (interruption doesn't work on them).
 */
// We're not using Dispatchers.IO on purpose here, so the caller can decide on the thread pool.
private suspend inline fun InputStream.consumeLinesBlockingCancellable(onEachLine: (String) -> Unit) {
    bufferedReader().useLines { lines ->
        try {
            lines.forEach {
                onEachLine(it)

                // We cooperate with cancellation by checking for it between each line read.
                // Using yield() instead of ensureActive() between reads could hurt performance, and wouldn't solve
                // the problem, because we could still block indefinitely on a read that never comes.
                currentCoroutineContext().ensureActive()
            }
        } catch (e: IOException) {
            // If the process is killed externally on unix systems, the stream is eagerly closed,
            // and reading from the sequence throws an IOException with "Stream closed" message,
            // sometimes capitalized as "Stream Closed", or "Bad file descriptor".
            // This check is brittle, but it's kind of the only way to account for this situation
            // by considering this exception as the end of the process output instead of crashing.
            if (e.message?.lowercase() in setOf("stream closed", "bad file descriptor")) {
                return
            }
            throw e
        }
    }
}

/**
 * Executes the given [cancellableBlock], and waits for the process's termination.
 * When this function terminates (normally or exceptionally), the process is guaranteed to be terminated:
 *
 * * If [cancellableBlock] completes successfully, this function simply waits for the termination of this process
 *   **without destroying it**.
 * * If [cancellableBlock] throws an exception, this function **destroys the process** and awaits its termination.
 * * If the current coroutine is canceled, this function **destroys the process** and awaits its termination.
 *   This is true whether the current coroutine is already canceled when calling this function, canceled during the
 *   execution of [cancellableBlock], or canceled after the successful completion of [cancellableBlock] (while waiting
 *   for the process to terminate).
 * * If the JVM is terminated gracefully (Ctrl+C / SIGINT), this function **destroys the process** and waits for its
 *   termination.
 *
 * In cases where the process is destroyed, normal destruction is requested first, and if this process doesn't
 * terminate within the given [gracePeriod], it is then _forcibly destroyed_.
 *
 * > Forcible process destruction is defined as the immediate termination of a process, whereas normal termination
 * > allows the process to shut down cleanly.
 *
 * This function always waits for the process to actually terminate before re-throwing an exception (such as
 * [CancellationException]) to make sure this process doesn't leak. If this process is not killable and hangs, this
 * function also hangs instead of returning and leaking this zombie process.
 */
@OptIn(ExperimentalContracts::class)
internal suspend inline fun <T> Process.withGuaranteedTermination(
    gracePeriod: Duration = DefaultGracePeriod,
    crossinline cancellableBlock: suspend CoroutineScope.(Process) -> T,
): T {
    contract {
        callsInPlace(cancellableBlock, kind = InvocationKind.EXACTLY_ONCE)
//         returnsResultOf(cancellableBlock)
    }
    withDestructionHook(gracePeriod) {
        try {
            // jump straight to the catch block if the coroutine is already canceled
            currentCoroutineContext().ensureActive()

            /*
             * This `coroutineScope` inside a try-catch is here to catch exceptions from coroutines that are started in
             * the caller-provided `cancellableBlock`, to make sure we always terminate the process.
             * If we instead just make `cancellableBlock` non-suspend and rely on inlining, callers may still start
             * nested coroutines by relying on an outer coroutine scope:
             *
             * coroutineScope {
             *   process.withGuaranteedTermination {
             *     launch {
             *       error("I bubble up straight to the coroutineScope, not caught by withGuaranteedTermination")
             *     }
             *   }
             * }
             */
            return coroutineScope {
                /*
                 * We need this manual cancellation tracking because `cancellableBlock` might misbehave. If that block
                 * contains blocking code that hangs without respecting coroutine cancellations, we still want to kill
                 * the process. This is not a theoretical case that can be solved by saying that callers must behave
                 * properly. It's something that cannot be prevented when dealing with blocking I/O. In particular,
                 * our own handling of stdout/stderr streams has to block on an uninterruptible readLine(). Even if we
                 * respect cancellation between line reads, we can indefinitely block on one line read if the process
                 * just doesn't output anything. By tracking cancellation here, we can kill the process which unblocks
                 * the line reads of the stream readers and allows this function to return properly.
                 */
                val cancellationTrackingJob = launch {
                    try {
                        awaitCancellation()
                    } catch (e: CancellationException) {
                        // The NonCancellable is not strictly necessary because this function is blocking, but it shows
                        // the intent that we want to kill and wait for the process to terminate even when canceled, to
                        // avoid zombie processes.
                        withContext(NonCancellable) {
                            killAndAwaitTermination(gracePeriod)
                        }
                        throw e
                    }
                }
                cancellableBlock(this@withGuaranteedTermination).also {
                    onExit().await()
                    // Yes, this will unnecessarily trigger the kill-on-cancellation of the cancellationTrackingJob,
                    // but killAndAwaitTermination is a no-op in this case, so it's fine.
                    cancellationTrackingJob.cancel()
                }
            }
        } catch (e: Throwable) {
            /*
             This block intentionally catches exceptions, errors and cancellations from the preliminary
             ensureActive() check:
               * for regular exceptions, we need to kill the process by contract
               * for JVM errors (ThreadDeath, OOM...), we still attempt to kill the process (best-effort)
               * for the cancellation from the preliminary ensureActive() check, we need to kill the process by contract
               * for other cancellations that might come from the coroutineScope body, they are already handled by the
                 cancellation-tracking job above. In that case, it's fine to call killAndAwaitTermination again because
                 it will be a no-op, so no need for special cases.
             */

            // The NonCancellable is not strictly necessary because this function is blocking, but it shows the intent
            // that we want to kill and wait for the process to terminate even when canceled, to avoid zombie processes.
            withContext(NonCancellable) {
                killAndAwaitTermination(gracePeriod)
            }
            throw e
        }
    }
}

/**
 * Executes the given [block], but also ensures that the process is destroyed in case the JVM is killed (e.g. Ctrl+C)
 * during the execution.
 *
 * A shutdown hook is registered before running [block], and unregistered when the given [block] completes (normally or
 * exceptionally). The shutdown hook destroys this [Process] and waits for its termination. If this process doesn't
 * terminate within the given [gracePeriod], it is _forcibly destroyed_, but still awaited.
 *
 * > Forcible process destruction is defined as the immediate termination of a process, whereas normal termination
 * > allows the process to shut down cleanly.
 *
 * Awaiting the process termination is necessary to show all the output from the process. Some processes like HTTP
 * servers print some output in their own shutdown hooks, and this way the caller can see it.
 *
 * If this process is not killable and hangs, this function will also hang instead of returning, so the caller is aware
 * of the zombie process. While this contradicts the shutdown hook rule of completing fast, it just transitively exposes
 * bad-behaved processes.
 */
@OptIn(ExperimentalContracts::class)
@PublishedApi
internal inline fun <T> Process.withDestructionHook(
    gracePeriod: Duration = DefaultGracePeriod,
    block: (Process) -> T,
): T {
    contract {
        callsInPlace(block, kind = InvocationKind.EXACTLY_ONCE)
//        returnsResultOf(block)
    }
    val command = try {
        info().commandLine().orElse("")
    } catch (_: UnsupportedOperationException) {
        "" // it's ok if the Process doesn't support providing info(), we can just omit the command name
    }
    return withShutdownHook(
        name = "Destroyer for PID=${pid()}: $command",
        runHookIfAlreadyShuttingDown = true, // kill the process immediately if already shutting down
        onJvmShutdown = { killAndAwaitTermination(gracePeriod) },
    ) {
        block(this)
    }
}

@OptIn(ExperimentalContracts::class)
@PublishedApi
internal inline fun <T> withShutdownHook(
    name: String,
    runHookIfAlreadyShuttingDown: Boolean,
    crossinline onJvmShutdown: () -> Unit,
    block: () -> T,
): T {
    contract {
        callsInPlace(block, kind = InvocationKind.EXACTLY_ONCE)
//         returnsResultOf(block)
    }
    val hookThread = Thread(
        /* group = */ null,
        /* task = */ { onJvmShutdown() },
        /* name = */ name,
    )
    val runtime = Runtime.getRuntime()
    try {
        runtime.addShutdownHook(hookThread)
    } catch (e: IllegalStateException) {
        // IllegalStateException is thrown if the JVM is already shutting down (it's the only documented case).
        // In this case, we can't register the hook, but we still want to run the onJvmShutdown callback immediately.
        // Note: there is no direct way to check whether the JVM is shutting down before attempting to add the hook, so
        // we have to rely on this non-obvious exception mechanism.
        if (runHookIfAlreadyShuttingDown) {
            onJvmShutdown()
        }
        // Even though we ran our shutdown code, we still have to fail and let the JVM exit.
        // (we shouldn't try to invent a value for `T` just because we know the JVM is exiting)
        throw e
    }
    try {
        return block()
    } finally {
        try {
            runtime.removeShutdownHook(hookThread)
        } catch (_: IllegalStateException) {
            // IllegalStateException is thrown if the JVM is already shutting down (it's the only documented case).
            // In this case, we don't need to unregister the hook, so it's fine to ignore this exception.
            // Note: there is no direct way to check whether the JVM is shutting down before attempting to remove the
            // hook, so we have to rely on this non-obvious exception mechanism.
        }
    }
}

/**
 * Kills this process and its descendants (first normally, then forcibly) and waits for their termination in a
 * non-cancellable way. If this process is already not alive, this function doesn't do anything and returns immediately.
 *
 * If this process doesn't die within [gracePeriod] after the normal termination request, it is forcibly destroyed.
 * If this process is not killable and hangs, this function also hangs instead of returning and leaking this zombie process.
 *
 * If this function returns normally, the process is guaranteed to be terminated.
 *
 * This operation is not cancellable in the coroutine sense, but it is interruptible. However, interrupting this call
 * should be avoided, as it would allow the process to potentially stay alive, defeating the purpose of this call.
 *
 * @throws InterruptedException if the current thread is interrupted while waiting for the process to terminate
 */
// TODO maybe turn this into non-blocking AND keep it non-cancellable with withContext(NonCancellable) on the call site
@PublishedApi
internal fun Process.killAndAwaitTermination(gracePeriod: Duration = DefaultGracePeriod): Int {
    destroyHierarchy()
    // the destroy operation is asynchronous, we need to give this process a chance to complete gracefully
    val completed = waitFor(gracePeriod.inWholeMilliseconds, TimeUnit.MILLISECONDS)
    if (completed) {
        return exitValue()
    }
    destroyHierarchyForcibly()
    // The forced destroy operation is asynchronous, so we need to wait until this process is actually terminated.
    // This may hang if the process is not killable, but if that's the case, it's better to hang than to return and
    // silently have a live zombie process.
    return waitFor()
}

/**
 * Requests the process and all its descendants to be killed. If the process is not alive, no action is taken.
 * The operating system access controls may prevent the process from being killed.
 *
 * Whether the process represented by this [Process] object is normally terminated or not is implementation-dependent.
 * Forcible process destruction is defined as the immediate termination of the process, whereas normal
 * termination allows the process to shut down cleanly.
 */
private fun Process.destroyHierarchy() {
    descendants().forEach { it.destroy() }
    destroy()
}

/**
 * Kills the process and all descendants forcibly. If the process is not alive, no action is taken.
 *
 * The process represented by this [Process] object is forcibly terminated. Forcible process destruction is defined as
 * the immediate termination of a process, whereas normal termination allows the process to shut down cleanly.
 */
private fun Process.destroyHierarchyForcibly() {
    descendants().forEach { it.destroyForcibly() }
    destroyForcibly()
}
