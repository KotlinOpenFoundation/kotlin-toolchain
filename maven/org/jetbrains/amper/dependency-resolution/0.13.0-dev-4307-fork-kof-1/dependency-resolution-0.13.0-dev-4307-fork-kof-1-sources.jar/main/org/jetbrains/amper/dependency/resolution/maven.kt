/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.dependency.resolution

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import org.jetbrains.amper.dependency.resolution.attributes.Attribute
import org.jetbrains.amper.dependency.resolution.attributes.AttributeValue
import org.jetbrains.amper.dependency.resolution.attributes.Category
import org.jetbrains.amper.dependency.resolution.attributes.DependencyBundling
import org.jetbrains.amper.dependency.resolution.attributes.DependencyBundling.External
import org.jetbrains.amper.dependency.resolution.attributes.KotlinNativeTarget
import org.jetbrains.amper.dependency.resolution.attributes.KotlinPlatformType
import org.jetbrains.amper.dependency.resolution.attributes.KotlinWasmTarget
import org.jetbrains.amper.dependency.resolution.attributes.PluginApiVersion
import org.jetbrains.amper.dependency.resolution.attributes.Usage
import org.jetbrains.amper.dependency.resolution.attributes.getAttributeValue
import org.jetbrains.amper.dependency.resolution.attributes.hasKotlinNativeTarget
import org.jetbrains.amper.dependency.resolution.attributes.hasKotlinPlatformType
import org.jetbrains.amper.dependency.resolution.attributes.hasKotlinWasmTarget
import org.jetbrains.amper.dependency.resolution.attributes.hasNoAttribute
import org.jetbrains.amper.dependency.resolution.attributes.isDocumentation
import org.jetbrains.amper.dependency.resolution.diagnostics.BomDeclaredAsRegularDependency
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.DependencyIsNotMultiplatform
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.FailedRepackagingKMPLibrary
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.KotlinMetadataHashNotResolved
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.KotlinMetadataMissing
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.KotlinMetadataNotResolved
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.KotlinProjectStructureMetadataMissing
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.ModuleFileNotDownloaded
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.MoreThanOneVariant
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.NoVariantForPlatform
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.PomWasFoundButMetadataIsMissing
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.PomWasNotFound
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.UnableToDetermineDependencyVersion
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.UnableToDetermineDependencyVersionForKotlinLibrary
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.UnableToParseMetadata
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.UnexpectedDependencyFormat
import org.jetbrains.amper.dependency.resolution.diagnostics.DependencyResolutionDiagnostics.UnresolvedMavenDependencyPackagingType
import org.jetbrains.amper.dependency.resolution.diagnostics.DiagnosticReporter
import org.jetbrains.amper.dependency.resolution.diagnostics.Message
import org.jetbrains.amper.dependency.resolution.diagnostics.MetadataResolvedWithPomErrors
import org.jetbrains.amper.dependency.resolution.diagnostics.PlatformsAreNotSupported
import org.jetbrains.amper.dependency.resolution.diagnostics.PomResolvedWithMetadataErrors
import org.jetbrains.amper.dependency.resolution.diagnostics.RegularDependencyDeclaredAsBom
import org.jetbrains.amper.dependency.resolution.diagnostics.Severity
import org.jetbrains.amper.dependency.resolution.diagnostics.UnableToResolveDependency
import org.jetbrains.amper.dependency.resolution.diagnostics.asMessage
import org.jetbrains.amper.dependency.resolution.diagnostics.hasErrors
import org.jetbrains.amper.dependency.resolution.files.produceFileWithDoubleLockAndHash
import org.jetbrains.amper.dependency.resolution.maven.resolvePom
import org.jetbrains.amper.dependency.resolution.metadata.xml.Project
import org.jetbrains.amper.dependency.resolution.metadata.xml.localRepository
import org.jetbrains.amper.dependency.resolution.metadata.xml.parseSettings
import org.jetbrains.amper.dependency.resolution.swiftpm.SwiftPMDependenciesMetadataNodeImpl
import org.jetbrains.amper.telemetry.use
import org.jetbrains.gradle.module.metadata.format.AvailableAt
import org.jetbrains.gradle.module.metadata.format.Capability
import org.jetbrains.gradle.module.metadata.format.Dependency
import org.jetbrains.gradle.module.metadata.format.Module
import org.jetbrains.gradle.module.metadata.format.Variant
import org.jetbrains.gradle.module.metadata.format.Version
import org.jetbrains.gradle.module.metadata.format.parseMetadata
import org.jetbrains.kotlin.metadata.format.projectStructure.KotlinProjectStructureMetadata
import org.jetbrains.kotlin.metadata.format.projectStructure.SourceSet
import org.jetbrains.kotlin.metadata.format.projectStructure.parseKmpLibraryMetadata
import org.slf4j.LoggerFactory
import java.nio.file.Path
import java.util.concurrent.CancellationException
import kotlin.collections.filter
import kotlin.contracts.InvocationKind
import kotlin.contracts.contract
import kotlin.io.path.Path
import kotlin.io.path.absolutePathString
import kotlin.io.path.exists
import kotlin.io.path.name
import kotlin.io.path.readText
import kotlin.properties.ReadOnlyProperty
import kotlin.reflect.KProperty

private val logger = LoggerFactory.getLogger("dr/maven.kt")

interface MavenDependencyNode : DependencyNode {
    val originalVersion: String?
    val versionFromBom: String?
    val isBom: Boolean

    val dependency: MavenDependency

    /**
     * Contains nodes that override this node's version and were exact ground for resolving the conflict.
     *
     * Note: There could be other nodes of the resolved version in the same graph not included in this set.
     * Such nodes might have been added to the graph after the conflict was resolved at the conflict resolution wave.
     * Such a node won't produce new conflict, and the next conflict resolution wave will leave overriddenBy untouched.
     */
    val overriddenBy: Set<DependencyNode>

    override val key: Key<MavenDependency>

    override val graphEntryName: String
        get() = if (dependency.version == originalVersion) {
            dependency.coordinates.toPrettyString(
                effectivePackagingType = dependency.mavenPackaging,
                hidePomPackagingType = true,
            )
        } else {
            getOriginalMavenCoordinates().toPrettyString(
                overridingVersion = dependency.version,
                effectivePackagingType = dependency.mavenPackaging,
                hidePomPackagingType = true,
            )
        }

    fun getOriginalMavenCoordinates(): MavenCoordinates = dependency.coordinates.copy(version = originalVersion)

    fun getMavenCoordinatesForPublishing(): MavenCoordinates

    fun getParentKmpLibraryCoordinates(): MavenCoordinates?

    /**
     * This key is the same as used for the resolving unique [MavenDependencyNode]
     * from the module cache during resolution with one difference:
     * It contains an effective maven packaging type instead of a declared one.
     *
     * This helps to group similar nodes not by declarations but by the actual resolution results.
     *
     * Graph could contain two [MavenDependencyNode] referencing different [MavenDependency] that are almost the same
     * but declare different [MavenDependency.mavenPackaging] ("aar" and "null", for instance).
     * Resolution results of those nodes might be the same in spite of the initially declared difference.
     * It will happen in the following cases:
     * - If a dependency was published with Gradle metadata. In this case [MavenDependency.mavenPackaging] is ignored,
     *   resolution is performed based on Gradle metadata descriptor only.
     * - If a dependency was published without Gradle metadata, and packaging type resolved from pom.xml and used for
     *   maven coordinates with unset field [MavenDependency.mavenPackaging] is the same as the one explicitly specified
     *   for another dependency.
     */
    fun uniqueResolutionKey() =
        dependency.coordinates
            .uniqueResolutionKey(
                resolutionConfig = dependency.resolutionConfig,
                isBom = isBom,
                overridingPackagingType = dependency.mavenPackaging
            )
}

internal fun MavenCoordinates.uniqueResolutionKey(
    resolutionConfig: ResolutionConfig,
    isBom: Boolean,
    overridingPackagingType: String? = null
) =
    toPrettyString(effectivePackagingType = overridingPackagingType) +
            ":$isBom" +
            "${resolutionConfig.scope}:${resolutionConfig.platforms.joinToString { it.pretty }}"

internal fun MavenDependencyNode.getKey(): Key<MavenDependency> = Key<MavenDependency>("$group:$module")

val MavenDependencyNode.group
    get() = dependency.group
val MavenDependencyNode.module
    get() = dependency.module
val MavenDependencyNode.classifier
    get() = dependency.classifier

@Serializable
@SerialName("MDN")
internal class SerializableMavenDependencyNode internal constructor(
    override val originalVersion: String?,
    override val versionFromBom: String? = null,
    override val isBom: Boolean = false,
    override val messages: List<Message> = emptyList(),
    private val dependencyRef: MavenDependencyReference,
    override val childrenRefs: MutableList<DependencyNodeReference> = mutableListOf(),
    internal val overriddenByRefs: MutableSet<DependencyNodeReference> = mutableSetOf(),
    private val coordinatesForPublishing: MavenCoordinates? = null,
    private val parentKmpLibraryCoordinates: MavenCoordinates? = null,
    @Transient
    private val graphContext: DependencyGraphContext = currentGraphContext()
) : MavenDependencyNode, SerializableDependencyNodeBase(graphContext) {

    override val key by lazy { getKey() }

    override fun getMavenCoordinatesForPublishing(): MavenCoordinates = coordinatesForPublishing ?: getOriginalMavenCoordinates()
    override fun getParentKmpLibraryCoordinates(): MavenCoordinates? = parentKmpLibraryCoordinates

    override val overriddenBy: Set<DependencyNode> by lazy { overriddenByRefs.map { it.toNodePlain(graphContext) }.toSet() }
    override val dependency: MavenDependency by lazy { dependencyRef.toNodePlain(graphContext) }
}

/**
 * Serves as a holder for a dependency defined by Maven coordinates, namely, group, module, and version.
 * While each node in a graph is expected to be unique, its [dependency] can be shared across other nodes
 * as long as their groups and modules match.
 * A version discrepancy might occur if a conflict resolution algorithm intervenes and is expected.
 *
 * The node doesn't do actual work but simply delegates to the [dependency] that can change over time.
 * This allows reusing dependency resolution results but still holding information about the origin.
 *
 * It's the responsibility of the caller to set a parent for this node if none was provided via the constructor.
 *
 * @see [DependencyNodeHolderWithContext]
 */
class MavenDependencyNodeWithContext internal constructor(
    templateContext: Context,
    dependency: MavenDependencyImpl,
    parentNodes: Set<DependencyNodeWithContext> = emptySet(),
) : MavenDependencyNode, DependencyNodeWithContext {

    internal constructor(
        templateContext: Context,
        coordinates: MavenCoordinates,
        isBom: Boolean,
        parentNodes: Set<DependencyNodeWithContext> = emptySet(),
    ) : this(
        templateContext,
        templateContext.createOrReuseDependency(coordinates, isBom),
        parentNodes,
    )

    override val context: Context = templateContext.copyWithNewNodeCache(parentNodes)

    override val parents: Set<DependencyNode> get() = context.nodeParents

    @Volatile
    override var dependency: MavenDependencyImpl = dependency
        private set(value) {
            assert(group == value.group) { "Groups don't match. Expected: $group, actual: ${value.group}" }
            assert(module == value.module) { "Modules don't match. Expected: $module, actual: ${value.module}" }
            field = value
        }

    /**
     * This method is intended to be used when the dependency version is updated
     * (due to conflict resolution or due to unspecified version substitution).
     * It updates dependency reference and recalculates children immediately
     * causes actualizing parents of old children no longer referenced from this node after update.
     */
    internal fun updateDependency(dependency: MavenDependencyImpl) {
        this.dependency = dependency
        children // causes actualizing parents of old children no longer referenced from this node
    }

    override val originalVersion: String? = dependency.version

    override val isBom: Boolean = dependency.isBom

    override val key = getKey()

    /**
     * This version taken from imported BOM is set to this field by dependency resolution (on the build graph stage)
     * for those nodes having an original version unspecified.
     *
     * Resolved node version is taken from [dependency] anyway, since it could be overridden during conflict resolution.
     * This field is used as additional information representing the intermediate version taken from BOM.
     */
    override var versionFromBom: String? = null
        internal set

    override var overriddenBy: Set<DependencyNode> = emptySet()
        internal set

    override val children: List<DependencyNodeWithContext> by PropertyWithDependencyGeneric(
        dependencyProviders = listOf(
            { thisRef: MavenDependencyNodeWithContext -> thisRef.dependency.children },
            { thisRef: MavenDependencyNodeWithContext -> thisRef.dependency.dependencyConstraints },
            { thisRef: MavenDependencyNodeWithContext -> thisRef.dependency.swiftPMDependenciesMetadata },
        ),
        valueProvider = { dependencies ->
            val children = dependencies[0] as List<*>
            val dependencyConstraints = dependencies[1] as List<*>
            val swiftPMDependenciesMetadata = dependencies[2] as DependencyFileImpl?
            val parentsClosure = this.withTransitiveParents()
            children.map { it as MavenDependencyImpl }.mapNotNull { mavenDependency ->
                context
                    .getOrCreateNode(mavenDependency, this)
                    // skip children that form cyclic dependencies
                    .let { child ->
                        child.takeIf { !child.formsCycle(parentsClosure) }
                            .also { if (it == null) child.context.nodeParents.remove(this) }
                    }
            } + dependencyConstraints.map {
                context.getOrCreateConstraintNode(it as MavenDependencyConstraintImpl, this)
            } + swiftPMDependenciesMetadata?.let {
                listOf(SwiftPMDependenciesMetadataNodeImpl(it, this@MavenDependencyNodeWithContext, templateContext))
            }.orEmpty()
        },
        onValueRecalculated = { oldValue, newValue ->
            if (oldValue != null) {
                (oldValue - newValue.toSet()).forEach { it.context.nodeParents.remove(this) }
            }
        }
    )

    override val messages: List<Message>
        get() = dependency.messages

    override suspend fun resolveChildren(level: ResolutionLevel, transitive: Boolean) {
        dependency.resolveChildren(context, level, transitive)
    }

    override suspend fun downloadDependencies(downloadSources: Boolean) =
        context.debugSpanBuilder("MavenDependencyNode.downloadDependencies")
            .setAttribute("coordinates", dependency.toString())
            .use {
                dependency.downloadDependencies(context, downloadSources)
            }

    override fun toString(): String = graphEntryName

    override val cacheEntryKey: CacheEntryKey
        get() = CacheEntryKey.CompositeCacheEntryKey(listOf(
            getOriginalMavenCoordinates(),
            isBom
        ))

    /**
     * Check that adding the node is safe, i.e., doesn't lead to a cycle in the dependency graph.
     *
     * This method uses the precalculated list of its parents (if it has the only parent) to optimize
     * performance (avoiding traversing parents' hierarchy for each child).
     * If it has more than one parent, then the actual parents closure is calculated
     * (because the node might have been referenced from several places and not all of them are known
     * at the moment precalculated parents closure is calculated.)
     */
    private fun DependencyNode.formsCycle(precalculatedParentsClosure: Set<DependencyNode>): Boolean {
        return if (this.parents.size == 1) {
            precalculatedParentsClosure.any { it.key == this.key }
        } else {
            this.transitiveParents().any { it.key == this.key }
        }
    }

    private fun DependencyNode.withTransitiveParents(): Set<DependencyNode> {
        return transitiveParents() + this
    }

    /**
     * NB: This method currently works properly only in the single-platform resolution context.
     *
     * todo (AB) : Replace with proper isKmpLibrary() condition that takes multi-platform context into account
     */
    fun isKmpLibrary(): Boolean = when {
        context.settings.platforms.size == 1 -> dependency.filesRaw(false).isEmpty()
        else -> false
    }

    /**
     * For a platform-specific artifact introduced into the resolution by a KMP library
     * (as one of its `available-at`), this method returns the coordinates of such a KMP library.
     *
     * This method is useful for IDE to find out if the library can be introduced to a module by depending on the
     * original multiplatform library (e.g., if the symbol from the platform-specific part was found).
     *
     * This is the counterpart of [getMavenCoordinatesForPublishing].
     *
     * If the current node is not a platform-specific variant of a KMP library, `null` is returned.
     */
    override fun getParentKmpLibraryCoordinates(): MavenCoordinates? {
        // When the node is resolved in the multiplatform context, it's unlikely that any platforms-specific artifacts
        // will be resolved for KMP libraries. Thus, there will be no nodes to call this method on.
        if (context.settings.platforms.size != 1) return null

        val thisCoordinates = dependency.coordinates
        for (parent in parents) {
            if (parent !is MavenDependencyNodeWithContext) continue

            if (parent.isKmpLibrary()) {
                val availableAtCoordinates = with(parent.dependency) { variants.withoutDocumentationAndMetadata }
                    .mapNotNull { it.`available-at`?.toCoordinates() }

                if (availableAtCoordinates.any { it == thisCoordinates }) {
                    return parent.dependency.coordinates
                }
            }
        }

        return null
    }

    /**
     * Publishing of a KMP library involves publishing various variants of this library for different platforms.
     * JVM single-platform variant might be consumed by a simple Maven/Gradle project that is not aware of KMP at all.
     * That means, JVM variant, when it comes to declaring dependencies during publication, should not refer to other KMP libraries,
     * but instead it should declare dependencies on JVM-specific variants of those libraries.
     *
     * This method provides coordinates of platform-specific variant for the KMP library.
     *
     * Method is supposed to be called on a maven dependency node from the resolved dependencies graph.
     * If the dependency is a KMP library, but resolution is done in a single-platform context,
     * then this method returns coordinates of the platform-specific library variant.
     * Otherwise (non KMP dependency or multi-platform resolution context), the original dependency coordinates are returned.
     *
     * Returned coordinates should be used while declaring dependency of the platform-specific variant being published
     * instead of the reference on the KMP library itself.
     *
     * Note: Returned maven coordinates contain an original dependency version, which is declared in the configuration file,
     * not the actual one that might have been changed due to a conflict resolution process.
     * This is because declared dependencies are published, not resolved ones.
     */
    override fun getMavenCoordinatesForPublishing(): MavenCoordinates {
        if (context.settings.platforms.size == 1 && isKmpLibrary()) {
            val childrenOriginalCoordinates = children
                .filterIsInstance<MavenDependencyNodeWithContext>()
                .mapNotNull { nested ->
                    nested.originalVersion()?.let { nested.dependency.coordinates.copy(version = it) }
                }
            val singlePlatformCoordinates = with(dependency) { variants.withoutDocumentationAndMetadata }
                .mapNotNull { it.`available-at`?.toCoordinates() }
                .singleOrNull { it in childrenOriginalCoordinates }

            // todo (AB): [KTC-5270] Take corresponding entry from childrenOriginalCoordinates and check its _single_ file extension.
            //  If it is AAR then add it as a packaging type to the return coordinates for publishing.
            //  (maybe not only AAR? maybe KLib as well?)
            //  Ensure, that specified packaging type is actually used on publication for filling dependency.type.
            if (singlePlatformCoordinates != null) return singlePlatformCoordinates
        }

        return getOriginalMavenCoordinates()
    }
}

interface MavenDependencyConstraintNode : DependencyNode {
    val group: String
    val module: String
    val version: Version

    val dependencyConstraint: MavenDependencyConstraint

    /**
     * Contains nodes that override this node's version and were exact ground for resolving the conflict.
     *
     * Note: There could be other nodes of the resolved version in the same graph not included in this set.
     * Such nodes might have been added to the graph after the conflict was resolved at the conflict resolution wave.
     * Such a node won't produce new conflict, and the next conflict resolution wave will leave overriddenBy untouched.
     */
    val overriddenBy: Set<DependencyNode>

    override val key: Key<MavenDependency>

    override val graphEntryName: String
        get() = if (dependencyConstraint.version == version) {
            "$group:$module:${version.resolve()}"
        } else {
            "$group:$module:${version.asString()} -> ${dependencyConstraint.version.asString()}"
        }
}

internal fun MavenDependencyConstraintNode.getKey(): Key<MavenDependency> = Key<MavenDependency>("$group:$module") // reusing the same key as MavenDependencyNode

@Serializable(with = MavenDependencyConstraintReference.Serializer::class)
class MavenDependencyConstraintReference(
    override val index: MavenDependencyConstraintIndex
): GraphEntryReference {
    fun toNodePlain(graphContext: DependencyGraphContext): MavenDependencyConstraint =
        graphContext.getMavenDependencyConstraint(index)

    internal companion object Serializer : ReferenceSerializer<MavenDependencyConstraintReference>() {
        override fun Int.toReference() = MavenDependencyConstraintReference(this)
        override fun getReferenceClass() = MavenDependencyConstraintReference::class
    }
}


@Serializable
@SerialName("MDCN")
internal class SerializableMavenDependencyConstraintNode internal constructor(
    override val group: String,
    override val module: String,
    override val version: Version,
    private val dependencyConstraintRef: MavenDependencyConstraintReference,
    override val childrenRefs: List<DependencyNodeReference> = mutableListOf(),
    internal val overriddenByRefs: MutableSet<DependencyNodeReference> = mutableSetOf(),
    override val messages: List<Message> = emptyList(),
    @Transient
    private val graphContext: DependencyGraphContext = currentGraphContext()
) : MavenDependencyConstraintNode, SerializableDependencyNodeBase(graphContext) {

    override val dependencyConstraint: MavenDependencyConstraint by lazy { dependencyConstraintRef.toNodePlain(graphContext) }

    override val key: Key<MavenDependency> by lazy { getKey() } // reusing the same key as MavenDependencyConstraintNode

    override val overriddenBy: Set<DependencyNode> by lazy { overriddenByRefs.map { it.toNodePlain(graphContext) }.toSet() }

}

class MavenDependencyConstraintNodeWithContext internal constructor(
    templateContext: Context,
    dependencyConstraint: MavenDependencyConstraintImpl,
    parentNodes: Set<DependencyNodeWithContext> = emptySet(),
):  MavenDependencyConstraintNode, DependencyNodeWithContext {

    override val context: Context = templateContext.copyWithNewNodeCache(parentNodes)

    @Volatile
    override var dependencyConstraint: MavenDependencyConstraintImpl = dependencyConstraint
        set(value) {
            assert(group == value.group) { "Groups don't match. Expected: $group, actual: ${value.group}" }
            assert(module == value.module) { "Modules don't match. Expected: $module, actual: ${value.module}" }
            field = value
        }

    override val group: String = dependencyConstraint.group
    override val module: String = dependencyConstraint.module
    override val version: Version = dependencyConstraint.version

    override val key: Key<MavenDependency> = getKey() // reusing the same key as MavenDependencyConstraintNode

    override var overriddenBy: Set<DependencyNode> = emptySet()
        internal set

    override val children: List<DependencyNodeWithContext> = emptyList()
    override val messages: List<Message> = emptyList()


    override suspend fun resolveChildren(level: ResolutionLevel, transitive: Boolean) {}

    override suspend fun downloadDependencies(downloadSources: Boolean) {}

    override fun toString(): String = graphEntryName

    override val cacheEntryKey: CacheEntryKey
        get() = CacheEntryKey.CompositeCacheEntryKey(listOf(group, module, version))
}

private typealias DependencyProvider<T> = (T) -> Any?

/**
 * A lazy property that's recalculated if its dependency changes.
 */
private class PropertyWithDependencyGeneric<T, V : Any>(
    val dependencyProviders: List<DependencyProvider<T>>,
    val valueProvider: (List<Any?>) -> V,
    val onValueRecalculated: (V?, V) -> Unit = { _, _ -> },
) : ReadOnlyProperty<T, V> {

    @Volatile
    private lateinit var dependencies: List<Any?>

    @Volatile
    private lateinit var value: V

    override fun getValue(thisRef: T, property: KProperty<*>): V {
        val newDependencies = dependencyProviders.map { it.invoke(thisRef) }
        if (shouldRecalculate(newDependencies)) {
            synchronized(this) {
                if (shouldRecalculate(newDependencies)) {
                    dependencies = newDependencies
                    val oldValue = if (::value.isInitialized) value else null
                    value = valueProvider(dependencies)
                    onValueRecalculated(oldValue, value)
                }
            }
        }
        return value
    }

    private fun shouldRecalculate(newDependencies: List<Any?>): Boolean =
        !this::value.isInitialized || !this::dependencies.isInitialized || newDependencies.anyIndexed { index, dep -> dep != dependencies[index] }

    private inline fun <T> Iterable<T>.anyIndexed(action: (index: Int, T) -> Boolean): Boolean {
        var index = 0
        for (item in this) {
            if (action(index++, item)) return true
        }
        return false
    }
}

fun Context.createOrReuseDependency(
    coordinates: MavenCoordinates,
    isBom: Boolean = false
): MavenDependencyImpl =
    this.resolutionCache.computeIfAbsent(Key<MavenDependencyImpl>(
        coordinates.uniqueResolutionKey(settings, isBom)
    )) {
        MavenDependencyImpl(this.settings, coordinates, isBom)
    }

internal fun Context.createOrReuseDependencyConstraint(
    group: String,
    module: String,
    version: Version
): MavenDependencyConstraintImpl =
    this.resolutionCache.computeIfAbsent(Key<MavenDependencyConstraintImpl>(
        "$group:$module:$version" +
                "${settings.scope}:${settings.platforms.joinToString { it.pretty }}"
    )) {
        MavenDependencyConstraintImpl(group, module, version)
    }

interface MavenDependencyConstraint {
    val group: String
    val module: String
    val version: Version

    fun toSerializableReference(graphContext: DependencyGraphContext): MavenDependencyConstraintReference {
        return graphContext.getMavenDependencyConstraintReference(this)
            ?: run {
                // 1. register plain
                val newNodePlain = MavenDependencyConstraintPlain(group, module, version)
                val newReference = graphContext.registerMavenDependencyConstraintPlain(this, newNodePlain)

                // 2. enrich it with references

                newReference
            }
    }
}

data class MavenDependencyConstraintImpl(
    override val group: String,
    override val module: String,
    override val version: Version
) : MavenDependencyConstraint

@Serializable
@SerialName("MDC")
data class MavenDependencyConstraintPlain(
    override val group: String,
    override val module: String,
    override val version: Version
) : MavenDependencyConstraint

internal fun shouldIgnoreDependency(group: String, module: String, context: Context): Boolean {
    return MavenGroupAndArtifact(group, module) in context.settings.dependenciesBlocklist
}

internal fun AvailableAt.shouldIgnoreDependency(context: Context) = shouldIgnoreDependency(group, module, context)

/**
 * The name of the KMP source set represented by the given dependency file.
 */
val KmpSourceSetName = Key<String>("KmpSourceSetName")

/**
 * Represents the list of platforms supported by the given source set.
 *
 * It is required for IDE to know about the capabilities of the dependency, which allows properly suggesting it
 * for adding as a dependency found by the unresolved reference search.
 */
val KmpPlatforms = Key<Set<ResolutionPlatform>>("KmpPlatforms")

interface MavenDependency {
    val coordinates: MavenCoordinates
    val mavenPackaging: String?
    val resolutionConfig: ResolutionConfig
    val messages: List<Message>
    val state: ResolutionState
    val pomPath: Path?

    /**
     * Returns all files belonging to the dependency.
     *
     * This method being called after resolution is finished,
     * guarantied for each returned file that
     * - it either points to the existing path [DependencyFile.path]
     * - or the error occurred during file resolution is presented in [messages]
     *   (in that case, [DependencyFile.path] might either not exist or be left unspecified)
     *
     * If it is called before resolution is finished,
     * then a list of files that is going to be resolved is returned.
     *
     * @param withSources if set to true and resolution was requested to include sources, then sources will be returned as well.
     * otherwise, only classpath artifacts are returned.
     */
    fun files(withSources: Boolean = false): List<DependencyFile>

    fun toSerializableReference(graphContext: DependencyGraphContext): MavenDependencyReference {
        return graphContext.getMavenDependencyReference(this)
            ?: run {
                // 1. register plain
                val mavenDependencyPlain = MavenDependencyPlain(
                    coordinates,
                    mavenPackaging,
                    messages,
                    files(true).map { DependencyFilePlain(it) },
                    pomPath?.absolutePathString(),
                    resolutionConfig.toSerializableReference(graphContext),
                    state,
                    graphContext
                )
                graphContext.registerMavenDependencyPlain(this, mavenDependencyPlain)

                // 2. enrich it with references
            }
    }
}

val MavenDependency.group
    get() = coordinates.groupId
val MavenDependency.module
    get() = coordinates.artifactId
val MavenDependency.version
    get() = coordinates.version
val MavenDependency.classifier
    get() = coordinates.classifier

@Serializable
@SerialName("MD")
class MavenDependencyPlain internal constructor (
    override val coordinates: MavenCoordinates,
    override val mavenPackaging: String? = null,
    override val messages: List<Message> = emptyList(),
    val files: List<DependencyFilePlain>,
    private val pomPathAsString: String? = null,
    private val resolutionConfigReference: ResolutionConfigReference,
    override val state: ResolutionState = ResolutionState.RESOLVED,
    @Transient
    private val graphContext: DependencyGraphContext = currentGraphContext()
) : MavenDependency {

    @Transient
    override val pomPath: Path? = pomPathAsString?.let { Path(it) }

    override val resolutionConfig by lazy { resolutionConfigReference.toNodePlain(graphContext) }

    override fun files(withSources: Boolean): List<DependencyFile> {
        return if (withSources) files else files.filterNot { it.isDocumentation }
    }

    override fun toString() = coordinates.toPrettyString(effectivePackagingType = mavenPackaging)
}

@Serializable(with = MavenDependencyReference.Serializer::class)
class MavenDependencyReference(
    override val index: MavenDependencyIndex
): GraphEntryReference {
    fun toNodePlain(graphContext: DependencyGraphContext): MavenDependency =
        graphContext.getMavenDependency(index)

    internal companion object Serializer : ReferenceSerializer<MavenDependencyReference>() {
        override fun Int.toReference() = MavenDependencyReference(this)
        override fun getReferenceClass() = MavenDependencyReference::class
    }
}

/**
 * An actual Maven dependency that can be resolved, that is, populated with children according to the requested
 * [ResolutionScope] and platform.
 * That means MavenDependency is bound to dependency resolution context, i.e., the instance of the class resolved for one context
 * could not be reused in another one.
 * Its [resolve] method contains the resolution algorithm.
 *
 * @see [DependencyFile]
 */
class MavenDependencyImpl internal constructor(
    val settings: Settings,
    override val coordinates: MavenCoordinates,
    val isBom: Boolean
): MavenDependency {
    internal constructor(
        settings: Settings,
        groupId: String,
        artifactId: String,
        version: String?,
        isBom: Boolean = false,
    ) : this(settings, MavenCoordinates(groupId, artifactId, version), isBom)

    override val resolutionConfig: ResolutionConfig
        get() = settings

    @Volatile
    override var state: ResolutionState = ResolutionState.INITIAL
        private set

    @Volatile
    private var downloadState: DownloadState = DownloadState.INITIAL

    @Volatile
    internal var variants: List<Variant> = emptyList()

    @Volatile

    internal var sourceSetsFiles: List<DependencyFileImpl> = emptyList()
        private set

    /**
     * It is resolved from pom.xml (and left null if resolution is done via Gradle metadata).
     */
    @Volatile
    private var pomPackagingType: PomPackagingType? = null

    /**
     * If resolution is performed using pom.xml,
     * this field contains the actual packaging type used for resolving dependency.
     *
     * It contains either dependency type taken from a dependency declaration if it is explicitly specified,
     * or is taken from the value of the packaging element of the pom.xml.
     * If both are unspecified, the default value 'jar' is used.
     */
    override val mavenPackaging: String? get() = pomPackagingType?.let {
        coordinates.packagingType
            ?: it.value
    }

    @Volatile
    var children: List<MavenDependencyImpl> = emptyList()
        private set

    @Volatile
    var swiftPMDependenciesMetadata: DependencyFileImpl? = null
        private set

    @Volatile
    internal var dependencyConstraints: List<MavenDependencyConstraintImpl> = emptyList()
        private set

    internal var metadataResolutionFailureMessage: Message? = null

    override val messages: List<Message>
        get() = if (version == null) {
            listOf(DependencyResolutionDiagnostics.UnspecifiedDependencyVersion.asMessage("$group:$module"))
        } else {
            metadataResolutionFailureMessage
                ?.let { listOf(it) }
                ?: (pom.diagnosticsReporter.getMessages() +
                        moduleFile.diagnosticsReporter.getMessages() +
                        files(withSources = true).flatMap { it.diagnosticsReporter.getMessages() })
        }

    private val mutex = Mutex()

    internal val moduleFile = getDependencyFile(
        dependency = this,
        nameWithoutExtension = getNameWithoutExtension(this, withClassifier = false),
        extension = "module"
    )
    private var moduleMetadata: Module? = null
    val pom = getDependencyFile(dependency = this,
        nameWithoutExtension = getNameWithoutExtension(this, withClassifier = false),
        extension = "pom"
    )
    private var pomText: String? = null
    override val pomPath: Path?
        get() = pom.path

    override fun files(withSources: Boolean): List<DependencyFileImpl> =
        filesRaw(withSources = withSources).filterByExistence()

    /**
     * Internal method that provides an ability to skip filtering of non-existing files.
     * It is useful when resolution is in progress and have intermediate state.
     * External callers are intended to call publicly available [MavenDependency.files]
     * (that returns list of resolved existing files after resolution had finished or a raw list if it is not yet started)
     */
    internal fun filesRaw(withSources: Boolean = false) =
        if (withSources)
            _files
        else
            _filesWithoutSources.filterNot { it.hasSourcesFilename() }

    private fun List<DependencyFileImpl>.filterByExistence(): List<DependencyFileImpl>  {
        val isDownloadFinished = downloadState in [DownloadState.WITHOUT_SOURCES, DownloadState.COMPLETE ]
        if (!isDownloadFinished) return this

        return filter {
            // If an error was detected while resolving this file, return it and skip the existence check.
            // (it might be an error on downloading, or something else that prevented the file from existing locally,
            // the error will be propagated to the main dependency node, see [MavenDependencyImpl.messages])
            val resolvedWithAnError = it.diagnosticsReporter.getMessages().any { it.severity >= Severity.ERROR }
            if (resolvedWithAnError) return@filter true

            val exists = it.path?.exists() == true
            // Check below raises a hard error only in case a file returned by DR is supposed to exist, but it doesn't.
            // It indicates some internal inconsistency and treated as an illegal state, that should never happen.
            check(
                exists
                        // a missing optional file is not an internal issue, there was no error detected during its resolution,
                        // the file simply doesn't exist.
                        || it.isOptional
                        // Missing of auto-added documentation doesn't lead to an error no matter what
                        || it.isAutoAddedDocumentation
                        // Missing of documentation doesn't lead to an error no matter what
                        || it.isDocumentation
            ) {
                "File '$it' was returned from dependency resolution, but is missing on disk"
            }
            exists
        }
    }

    private fun DependencyFileImpl.hasSourcesFilename(): Boolean =
        fileName.endsWith("-sources.jar") || fileName.endsWith("-javadoc.jar")

    private val _files: List<DependencyFileImpl> by filesProvider(withSources = true)
    private val _filesWithoutSources: List<DependencyFileImpl> by filesProvider(withSources = false)

    private fun filesProvider(withSources: Boolean) =
        PropertyWithDependencyGeneric(
            dependencyProviders = listOf(
                { thisRef: MavenDependencyImpl -> thisRef.variants },
                { thisRef: MavenDependencyImpl -> thisRef.pomPackagingType },
                { thisRef: MavenDependencyImpl -> thisRef.sourceSetsFiles }
            ),
            valueProvider = { dependencies ->
                val variants = dependencies[0] as List<*>
                val pomPackagingType = dependencies[1] as PomPackagingType?
                val sourceSetsFiles = dependencies[2] as List<*>
                val dependency = this@MavenDependencyImpl
                buildList {
                    variants
                        .map { it as Variant }
                        .let { if (withSources) it else it.withoutDocumentationAndMetadata }
                        .let {
                            val areSourcesMissing = withSources && it.documentationOnly.isEmpty()
                            it.forEach { variant ->
                                val isDocumentationOrMetadata = variant.isDocumentationOrMetadata
                                variant.files.forEach {
                                    add(getDependencyFile(dependency,it, isDocumentation = isDocumentationOrMetadata))
                                    if (areSourcesMissing) {
                                        add(getAutoAddedSourcesDependencyFile())
                                    }
                                }
                            }
                        }

                    pomPackagingType?.let {
                        if (coordinates.packagingType == "pom" || isBom) {
                            // skip resolving any artifact if dependency type is explicitly set to 'pom'.
                            return@let
                        }

                        val actualPackagingType = coordinates.packagingType
                            // Preferring packaging type resolved from pom.xml (Gradle like) to the default
                            // dependency type 'jar'.
                            // Falling back to 'jar' if pom.xml declares packaging type 'pom'.
                            ?: pomPackagingType.value.takeIf { it != "pom" }
                            ?: "jar"

                        // todo (AB): [KTC-5270]
                        //  Packaging type might also imply classifier (if it is not specified explicitly yet)
                        //  It might affect [getNameWithoutExtension] implementation
                        //  See https://maven.apache.org/repositories/dependencies.html
                        val nameWithoutExtension = getNameWithoutExtension(dependency)

                        val extension = resolveArtifactExtension(actualPackagingType)

                        // Library published with packaging type equal to 'pom' may or may mot contains actual artifacts.
                        // We try to resolve the default artifact, but it is OK if it doesn't exist.
                        val isOptional = coordinates.packagingType == null && pomPackagingType.value == "pom"
                        add(getDependencyFile(dependency, nameWithoutExtension, extension, isOptional = isOptional))
                        if (extension == "jar" && withSources) {
                            add(getAutoAddedSourcesDependencyFile())
                        }
                    }

                    addAll(sourceSetsFiles.map { it as DependencyFileImpl })
                }
            }
        )

    /**
     * The repository module/pom file was downloaded from.
     * If we download a module/pom file from some repository,
     * then it would be optimal to try downloading resolved variants and hashes from the same repository first as well,
     * instead of traversing the list in an original order.
     */
    @Volatile
    internal var repository: Repository? = null
        set(value) {
            if (field == null && value != null) {
                field = value
            }
        }

    override fun toString(): String = coordinates.toPrettyString(effectivePackagingType = mavenPackaging)

    suspend fun resolveChildren(
        context: Context,
        level: ResolutionLevel,
        transitive: Boolean = true,
    ) {
        if (state < getTargetState(level, transitive)) {
            mutex.withLock {
                if (state < getTargetState(level, transitive)) {
                    context.debugSpanBuilder("MavenDependencyNode.resolveChildren")
                        .setAttribute("coordinates", this.toString())
                        .use {
                            resolve(context, level, transitive)
                        }
                }
            }
        }
    }

    private suspend fun resolve(context: Context, level: ResolutionLevel, transitive: Boolean) {
        try {
            if (version == null)
                return

            resetMetadataDiagnostics()

            val settings = context.settings
            // 1. Download pom.
            val pomText = if (pom.isDownloadedOrDownload(level, context, pom.diagnosticsReporter)) {
                pom.readText()
            } else {
                if (level != ResolutionLevel.NETWORK) {
                    pom.diagnosticsReporter.addMessage(
                        PomWasNotFound.asMessage(
                            this,
                            extra = DependencyResolutionBundle.message(
                                "extra.repositories",
                                settings.repositoryUrls.joinToString()
                            ),
                        )
                    )
                }
                null
            }
            this.pomText = pomText

            // 2. If pom is missing or mentions metadata, use it.
            if (pomText == null || pomText.contains("do_not_remove: published-with-gradle-metadata")) {
                if (moduleFile.isDownloadedOrDownload(level, context, moduleFile.diagnosticsReporter)) {
                    resolveUsingMetadata(context, level, transitive, moduleFile.diagnosticsReporter)
                    return
                }
                if (pomText != null) {
                    if (level != ResolutionLevel.NETWORK) {
                        moduleFile.diagnosticsReporter.addMessage(
                            PomWasFoundButMetadataIsMissing.asMessage(
                                this,
                                extra = DependencyResolutionBundle.message(
                                    "extra.repositories",
                                    settings.repositoryUrls.joinToString()
                                ),
                            )
                        )
                    }
                }
            }
            // 3. If metadata can't be used, use pom.
            if (pomText != null) {
                resolveUsingPom(pomText, context, level, transitive, pom.diagnosticsReporter)
                return
            }
        } finally {
            // 4. if neither pom nor module file were downloaded
            if (state < getTargetState(level, transitive)) {
                metadataResolutionFailureMessage = UnableToResolveDependency(
                    coordinates = this.coordinates,
                    repositoryUrls = context.settings.repositoryUrls,
                    resolutionLevel = level,
                    childMessages = pom.diagnosticsReporter.getMessages() + moduleFile.diagnosticsReporter.getMessages(),
                )
            }
        }
    }

    private fun getTargetState(level: ResolutionLevel, transitive: Boolean) =
        when (level) {
            ResolutionLevel.LOCAL -> ResolutionState.UNSURE
            ResolutionLevel.NETWORK -> if (transitive) ResolutionState.RESOLVED else ResolutionState.RESOLVED_WITHOUT_CHILDREN
        }

    private fun getTargetDownloadState(downloadSources: Boolean): DownloadState =
        if (downloadSources) DownloadState.COMPLETE else DownloadState.WITHOUT_SOURCES

    private fun resetMetadataDiagnostics() {
        metadataResolutionFailureMessage = null
        pom.diagnosticsReporter.reset()
        moduleFile.diagnosticsReporter.reset()
    }

    private fun List<Variant>.filterWithFallbackScope(scope: ResolutionScope): List<Variant> {
        val scopeVariants = this.filter { scope.matches(it) }
        return scopeVariants.takeIf { it.withoutDocumentationAndMetadata.isNotEmpty() }
            ?: scope.fallback()?.let { fallbackScope ->
                this.filter { fallbackScope.matches(it) }.takeIf { it.withoutDocumentationAndMetadata.isNotEmpty() }
            }
            ?: scopeVariants
    }

    private fun List<Variant>.filterWithFallbackPlatform(platform: ResolutionPlatform): List<Variant> {
        val platformVariants = this.filter { platform.type.matches(it) }
        return when {
            platformVariants.withoutDocumentationAndMetadata.isNotEmpty()
                    || platform.type.fallback == null -> platformVariants

            else -> this.filter { platform.type.fallback.matches(it) }
        }
    }

    private fun List<Variant>.filterWithFallbackJvmEnvironment(platform: ResolutionPlatform): List<Variant> {
        val platformVariants = this.filter { platform.type.matchesJvmEnvironment(it) }
        return when {
            platformVariants.withoutDocumentationAndMetadata.isNotEmpty()
                    || platform.type.fallback == null -> platformVariants

            else -> this.filter { platform.type.fallback.matchesJvmEnvironment(it) }
        }
    }

    private fun List<Variant>.filterWellKnowSpecialLibraries(group: String, module: String): List<Variant> {
        if (withoutDocumentationAndMetadata.size <= 1) return this

        if (group == "org.jetbrains.kotlin"
            && (module == "kotlin-gradle-plugin" || module == "fus-statistics-gradle-plugin")
        ) {
            val nonVersionVariants = filter { it.hasNoAttribute(PluginApiVersion) }
            if (nonVersionVariants.withoutDocumentationAndMetadata.size == 1) return nonVersionVariants
        }

        return this
    }

    private fun List<Variant>.filterMultipleVariantsByUnusedAttributes(): List<Variant> {
        return when {
            (this.withoutDocumentationAndMetadata.size == 1) -> this
            else -> {
                val usedAttributes = setOf(
                    "org.gradle.category",
                    "org.gradle.usage",
                    "org.jetbrains.kotlin.native.target",
                    "org.jetbrains.kotlin.platform.type",
                    "org.gradle.jvm.environment"
                )
                val minUnusedAttrsCount = this.minOfOrNull { v ->
                    v.attributes.count { it.key !in usedAttributes }
                }
                this.filter { v -> v.attributes.count { it.key !in usedAttributes } == minUnusedAttrsCount }
                    .let {
                        if (it.withoutDocumentationAndMetadata.size == 1) {
                            it
                        } else {
                            this
                        }
                    }
            }
        }
    }

    /**
     * It is intended to be called as the last resort in case several variants are still in play.
     * If all those variants have the same attribute and a single variant has the attribute with a preferred value,
     * then such a variant is selected.
     * Otherwise, the original variants list is returned.
     */
    private fun List<Variant>.filterMultipleVariantsByAttributePreferredValue(): List<Variant> {
        return if (this.withoutDocumentationAndMetadata.size > 1) {
            filterMultipleVariantsByAttribute(attribute = DependencyBundling, preferredValue = External)
        } else {
            this
        }
    }

    private inline fun <reified T : AttributeValue> List<Variant>.filterMultipleVariantsByAttribute(
        attribute: Attribute<T>, preferredValue: T
    ): List<Variant> {
        if (this.withoutDocumentationAndMetadata.all { v -> v.getAttributeValue(attribute) != null }) {
            // All variants contain dependency bundling, so we could try resolving the best match
            this.filter { v ->
                v.hasNoAttribute(attribute)
                        || v.getAttributeValue(attribute) == preferredValue
            }.let {
                if (it.withoutDocumentationAndMetadata.size == 1) {
                    return it
                }
            }
        }

        return this
    }

    private suspend fun resolveUsingMetadata(
        context: Context,
        level: ResolutionLevel,
        transitive: Boolean,
        diagnosticsReporter: DiagnosticReporter,
    ) {
        val moduleMetadata = parseModuleMetadata(context, level, diagnosticsReporter, true)
        this.moduleMetadata = moduleMetadata

        if (moduleMetadata == null) return

        if (context.settings.platforms.isEmpty()) {
            throw AmperDependencyResolutionException("Target platform is not specified.")
        } else if (context.settings.platforms.singleOrNull() == ResolutionPlatform.COMMON) {
            throw AmperDependencyResolutionException(
                "Dependency resolution can not be run for COMMON platform. " +
                        "Set of actual target platforms should be specified."
            )
        }

        val processedAsSpecialCase = processSpecialKmpLibraries(context, moduleMetadata, level, transitive, diagnosticsReporter)
        if (processedAsSpecialCase) {
            // Do nothing, dependency was already processed
        } else if (isBom) {
            val validVariants = resolveBomVariants(moduleMetadata, context.settings)
            if (validVariants.isEmpty()) {
                diagnosticsReporter.addMessage(RegularDependencyDeclaredAsBom(this.coordinates))
            } else {
                validVariants.also {
                    variants = it
                    if (it.withoutDocumentationAndMetadata.size > 1) {
                        diagnosticsReporter.addMessage(
                            MoreThanOneVariant.asMessage(
                                this,
                                extra = it.withoutDocumentationAndMetadata.joinToString { variant -> variant.name },
                            )
                        )
                    }
                }
                // Import platform/BOM dependency constraints
                validVariants
                    .withoutDocumentationAndMetadata
                    .let { variants ->
                        variants.flatMap {
                            it.dependencyConstraints
                        }.mapNotNull {
                            it.toMavenDependencyConstraint(context)
                        }.let {
                            dependencyConstraints = it
                        }
                    }

                // BOM declared in Gradle metadata as a dependency of type 'platform' can depend on other BOMs
                variants.flatMap {
                    // resolve transitive BOM dependencies even if isTransitive is set to false,
                    // because BOM sequence is an atomic thing that ia intended to be applied to the graph as a whole thing.
                    it.dependencies(context, level, diagnosticsReporter)
                    // `available-at` doesn't make sense for the BOM dependency, skip its processing
                }.map {
                    it.toMavenDependency(context, diagnosticsReporter)
                }.let {
                    children = it
                }
            }
        } else {
            // Single platform (or jvm+android) context
            if (context.settings.platforms.size == 1
                // [KTC-4474] Supporting JVM dependencies in jvm+android fragments.
                || context.settings.platforms == setOf(ResolutionPlatform.JVM, ResolutionPlatform.ANDROID))
            {
                val swiftPMMetadata = moduleMetadata.variants.firstOrNull { it.getAttributeValue(Usage)?.value == "swiftPMDependenciesMetadata" }
                if (swiftPMMetadata != null) {
                    swiftPMDependenciesMetadata = getDependencyFile(this, swiftPMMetadata.files.single(), false)
                }

                val platform =
                    if (context.settings.platforms == setOf(ResolutionPlatform.JVM, ResolutionPlatform.ANDROID))
                        // Even if the KMP library has a commonMain sourceSet resolvable in the jvm+android context,
                        // we should not use it because it could contain fewer symbols than jvm-specific variant
                        // which is still suitable for both platforms.
                        ResolutionPlatform.JVM
                    else
                        context.settings.platforms.single()

                val validVariants = resolveVariants(moduleMetadata, context.settings, platform)

                if (validVariants.isEmpty()) {
                    reportVariantMismatchForLibrary(diagnosticsReporter, moduleMetadata, setOf(platform))
                } else {
                    validVariants.also {
                        variants = it
                        if (it.withoutDocumentationAndMetadata.size > 1) {
                            diagnosticsReporter.addMessage(
                                MoreThanOneVariant.asMessage(
                                    this,
                                    extra = it.withoutDocumentationAndMetadata.joinToString { it.name },
                                )
                            )
                        }
                    }
                    // One platform case
                    validVariants
                        .withoutDocumentationAndMetadata
                        .let { variants ->
                            variants.flatMap {
                                val dependencies = if (transitive)
                                    it.dependencies(
                                        context,
                                        level,
                                        diagnosticsReporter,
                                    ) else emptyList()
                                dependencies + listOfNotNull(
                                    it.`available-at`?.takeIf { !it.shouldIgnoreDependency(context) }?.asDependency()
                                )
                            }.map {
                                it.toMavenDependency(context, diagnosticsReporter)
                            }.let {
                                children = it
                            }

                            variants.flatMap {
                                it.dependencyConstraints
                            }.mapNotNull {
                                it.toMavenDependencyConstraint(context)
                            }.let {
                                dependencyConstraints = it
                            }
                        }
                }
            } else {
                // Multiplatform case
                val [kotlinMetadataVariant, kmpMetadataFile] =
                    detectKotlinMetadataLibrary(
                        context,
                        ResolutionPlatform.COMMON,
                        moduleMetadata,
                        level,
                        diagnosticsReporter
                    ) ?: (null to null)

                if (kotlinMetadataVariant != null && kmpMetadataFile != null) {
                    resolveKmpLibrary(
                        kmpMetadataFile,
                        context,
                        moduleMetadata,
                        level,
                        transitive,
                        kotlinMetadataVariant,
                        diagnosticsReporter
                    )

                    // Add KMP sources
                    val sourcesDependencyFile =
                        getKotlinMetadataSourcesVariant(moduleMetadata.variants, ResolutionPlatform.COMMON)
                            ?.let { getKotlinMetadataFile(it, diagnosticsReporter) }
                            ?.let { getDependencyFile(this, it, isDocumentation = true) }
                            ?: getAutoAddedSourcesDependencyFile()

                    sourceSetsFiles = sourceSetsFiles.toMutableList() + listOf(sourcesDependencyFile)
                } else {
                    // source sets were not resolved, a corresponding error was reported (apart from an exceptional case of jvm+android)
                }
            }
        }

        state = getTargetState(level, transitive)

        // We have used a module metadata file for resolving dependency, => lower severity of pom-related issues.
        if (pom.diagnosticsReporter.hasErrors()) {
            pom.diagnosticsReporter.suppress { suppressedMessages ->
                MetadataResolvedWithPomErrors(coordinates, suppressedMessages)
            }
        }
    }

    private fun reportVariantMismatchForLibrary(
        diagnosticsReporter: DiagnosticReporter,
        module: Module,
        missingPlatforms: Set<ResolutionPlatform>,
    ) {
        val groupedByCategory = module.variants.groupBy { it.getAttributeValue(Category) }
        val libraryVariants = buildList {
            groupedByCategory[Category.Library]?.let { addAll(it) }
            // Old versions of Kotlin libraries might not have the proper category attribute set.
            groupedByCategory[null]?.let { addAll(it) }
        }
        if (libraryVariants.isEmpty() && groupedByCategory[Category.Platform] != null) {
            diagnosticsReporter.addMessage(BomDeclaredAsRegularDependency(this.coordinates))
            return
        }

        val supportedPlatforms = libraryVariants
            .mapNotNullTo(mutableSetOf()) { variant -> getLeafPlatformFromVariant(variant) }
        // This check might be more sophisticated,
        // but for the time being we suppose that all JVM libraries can be used on Android
        if (ResolutionPlatform.JVM in supportedPlatforms) {
            supportedPlatforms += ResolutionPlatform.ANDROID
        }
        if (supportedPlatforms.isNotEmpty()) {
            diagnosticsReporter.addMessage(PlatformsAreNotSupported(this, supportedPlatforms))
            return
        }

        // It's a fallback that actually shouldn't ever occur. It is possible that it can be safely deleted.
        missingPlatforms.forEach {
            diagnosticsReporter.addMessage(NoVariantForPlatform.asMessage(it.pretty, this))
        }
    }

    private fun getLeafPlatformFromVariant(variant: Variant): ResolutionPlatform? {
        val kotlinPlatform = variant.getAttributeValue(KotlinPlatformType) as? KotlinPlatformType.Known ?: return null
        return when (kotlinPlatform.platformType) {
            PlatformType.COMMON -> null
            PlatformType.JVM -> ResolutionPlatform.JVM
            PlatformType.ANDROID_JVM -> ResolutionPlatform.ANDROID
            PlatformType.JS -> ResolutionPlatform.JS
            PlatformType.WASM -> {
                val wasmTarget =
                    variant.getAttributeValue(KotlinWasmTarget) as? KotlinWasmTarget.Known ?: return null
                wasmTarget.platform
            }

            PlatformType.NATIVE -> {
                val nativeTarget =
                    variant.getAttributeValue(KotlinNativeTarget) as? KotlinNativeTarget.Known ?: return null
                nativeTarget.platform
            }
        }
    }

    fun getAutoAddedSourcesDependencyFile() =
        getDependencyFile(
            this,
            // Sources are published once for all classifiers, this is why 'moduleFile'.'nameWithoutExtension' is taken
            "${this.moduleFile.nameWithoutExtension}-sources",
            "jar",
            isDocumentation = true,
            isAutoAddedDocumentation = true
        )

    /**
     * Some pretty basic libraries that are used in a KMP world mimic for pure JVM libraries,
     * those cases should be processed in a custom way.
     *
     * If this method returns true, it means such a library was detected and processed
     * (library dependencies are registered to graph); no further processing by a usual way is needed.
     *
     * @return true, in case a Kmp library that needs special treatment was detected and processed, false - otherwise
     * @see isSpecialKmpLibrary
     */
    private suspend fun processSpecialKmpLibraries(
        context: Context,
        moduleMetadata: Module,
        level: ResolutionLevel,
        transitive: Boolean,
        diagnosticsReporter: DiagnosticReporter,
    ): Boolean {
        if (isSpecialKmpLibrary()) {
            moduleMetadata
                .variants
                .let {
                    if (transitive) {
                        it.flatMap {
                            it.dependencies(context, level, diagnosticsReporter)
                        }.map {
                            it.toMavenDependency(context, diagnosticsReporter)
                        }.let {
                            children = it
                        }
                    }

                    it.flatMap {
                        it.dependencyConstraints
                    }.mapNotNull {
                        it.toMavenDependencyConstraint(context)
                    }.let {
                        dependencyConstraints = it
                    }
                }
            return true
        }

        return false
    }

    private fun Dependency.toMavenDependencyConstraint(context: Context): MavenDependencyConstraintImpl? {
        return version?.let { context.createOrReuseDependencyConstraint(group, module, it) }
    }

    private fun Dependency.toMavenDependency(
        context: Context,
        reportError: (reason: String) -> Unit = {},
    ): MavenDependencyImpl {
        val coordinates = toMavenCoordinates(reportError)
        return context.createOrReuseDependency(coordinates, isBom())
    }

    private fun Dependency.toMavenCoordinates(
        reportError: (reason: String) -> Unit = {},
    ): MavenCoordinates {
        val resolvedVersion = resolveVersion(reportError)
        val classifier = thirdPartyCompatibility?.artifactSelector?.classifier
        return mavenCoordinatesTrimmed(groupId = group, artifactId = module, version = resolvedVersion, classifier = classifier)
    }

    private fun Dependency.toMavenDependency(
        context: Context,
        diagnosticsReporter: DiagnosticReporter,
    ): MavenDependencyImpl {
        val dependency = this
        return toMavenDependency(context) { reason ->
            val coordinates = this@MavenDependencyImpl.coordinates
            val dependency = "${dependency.group}:${dependency.module}"
            diagnosticsReporter.addMessage(
                UnableToDetermineDependencyVersion.asMessage(
                    coordinates,
                    dependency,
                    reason,
                )
            )
        }
    }

    private suspend fun Variant.bomDependencyConstraints(
        context: Context,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ): List<MavenDependencyConstraintImpl> =
        dependencies.mapNotNull {
            if (!it.isBom()) {
                null
            } else {
                withResolvedVersion(it)
                    .takeIf { it.version != null }
                    ?.toMavenDependency(context, diagnosticsReporter)
                    ?.let {
                        it.resolveChildren(context, level, true)
                        it.dependencyConstraints
                    }
            }
        }.flatten().takeIf { it.isNotEmpty() }
        // try to resolve constraints from '.pom' - descriptor
            ?: pomText?.let { resolveDependenciesConstraintsUsingPom(it, context, level, diagnosticsReporter) }
            ?: emptyList()

    private suspend fun Variant.dependencies(
        context: Context,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter
    ): List<Dependency> =
        dependencies.filterNot { shouldIgnoreDependency(it.group, it.module, context) }.map {
            withResolvedVersion(it) { bomDependencyConstraints(context, level, diagnosticsReporter) }
        }

    /**
     * Resolve a dependency version.
     *
     * Usually it is defined right on a dependency declaration, and in this case, we just return the dependency as is.
     * If it is not defined on a dependency, then we try to resolve it via dependency constraints
     * declared for current node metadata.
     * If a version is still not resolved (neither directly nor via constraints),
     * then BOM dependencies are resolved, and the version is taken from them (if any).
     *
     * BOM dependencies are lazily resolved at this stage if a version can't be resolved via current node metadata only.
     */
    private suspend fun Variant.withResolvedVersion(
        dep: Dependency,
        bomDependencyConstraints: suspend () -> List<MavenDependencyConstraintImpl> = { emptyList() }
    ): Dependency =
        if (dep.version != null) {
            dep
        } else {
            val versionFromConstraint = dependencyConstraints
                .firstOrNull { dep.module == it.module && dep.group == it.group && it.version != null }
                ?.version
                ?: bomDependencyConstraints()
                    .firstOrNull { dep.module == it.module && dep.group == it.group }
                    ?.version
            if (versionFromConstraint != null) {
                dep.copy(version = versionFromConstraint)
            } else {
                dep
            }
        }

    private fun Dependency.resolveVersion(reportError: (reason: String) -> Unit): String? {
        return if (version == null) {
            // An empty version of transitive dependency might be resolved from some BOM file from the dependency graph
            null
        } else {
            val resolvedVersion = version!!.resolve()
            if (resolvedVersion == null) {
                reportError(DependencyResolutionBundle.message("version.attributes.not.defined"))
                return null
            }
            resolvedVersion
        }
    }

    private suspend fun parseModuleMetadata(
        context: Context,
        level: ResolutionLevel,
        diagnosticReporter: DiagnosticReporter,
        skipIsDownloadedCheck: Boolean = false,
    ): Module? {
        if (skipIsDownloadedCheck || moduleFile.isDownloadedOrDownload(level, context, diagnosticReporter)) {
            try {
                return computeIfAbsentInResolutionCache(context, "parsedMetadata") {
                    moduleFile.readText().parseMetadata()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val message = UnableToParseMetadata.asMessage(
                    moduleFile,
                    extra = DependencyResolutionBundle.message("extra.exception", e),
                    exception = e,
                )
                logger.warn(message.message, e)
                diagnosticReporter.addMessage(message)
            }
        } else {
            diagnosticReporter.addMessage(
                ModuleFileNotDownloaded.asMessage(
                    this,
                    extra = DependencyResolutionBundle.message(
                        "extra.repositories",
                        context.settings.repositoryUrls.joinToString()
                    ),
                    overrideSeverity = Severity.WARNING.takeIf { level != ResolutionLevel.NETWORK },
                )
            )
        }
        return null
    }

    private  inline fun <reified T: Any> Context.retrieveCachedEntry(key: String): T? = resolutionCache[Key<T>(key)]

    internal suspend inline fun <reified T: Any> MavenDependencyImpl.computeIfAbsentInResolutionCache(
        context: Context,
        keyName: String,
        crossinline block: suspend () -> T?
    ): T? {
        contract {
            callsInPlace(block, InvocationKind.AT_MOST_ONCE)
//             returnsResultOf(block)
        }
        val keyScope = "$coordinates:$isBom"
        val scopedKey = "$keyScope:keyName=$keyName"

        return context.retrieveCachedEntry(scopedKey)
            ?: run {
                val mutex = context.resolutionCache.computeIfAbsent(Key<Mutex>(scopedKey)) { Mutex() }
                mutex.withLock {
                    context.retrieveCachedEntry(scopedKey)
                        ?: block()
                            ?.also { context.resolutionCache[Key<T>(scopedKey)] = it }
                }
            }
    }

    private suspend fun detectKotlinMetadataLibrary(
        context: Context,
        platform: ResolutionPlatform,
        moduleMetadata: Module,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ): Pair<Variant, DependencyFileImpl>? {
        val kotlinMetadataVariant =
            getKotlinMetadataVariant(moduleMetadata.variants, platform, context, diagnosticsReporter)
                ?: return null  // the children list is empty in case kmp common variant is not resolved
        val kotlinMetadataFile = getKotlinMetadataFile(kotlinMetadataVariant, diagnosticsReporter)
            ?: return null  // the children list is empty if kmp common variant file is not resolved

        val kmpMetadataDependencyFile = getDependencyFile(this, kotlinMetadataFile)

        return (kotlinMetadataVariant to kmpMetadataDependencyFile).takeIf {
            it.second.isDownloadedOrDownload(
                level,
                context,
                it.second.diagnosticsReporter
            )
        }
            ?: run {
                diagnosticsReporter.addMessage(
                    KotlinMetadataMissing.asMessage(
                        kmpMetadataDependencyFile.fileName,
                        this,
                        overrideSeverity = Severity.WARNING.takeIf { level != ResolutionLevel.NETWORK },
                        childMessages = kmpMetadataDependencyFile.diagnosticsReporter.getMessages(),
                    )
                )
                null
            }
    }

    private suspend fun resolveKmpLibrary(
        kmpMetadataFile: DependencyFileImpl,
        context: Context,
        moduleMetadata: Module,
        level: ResolutionLevel,
        transitive: Boolean,
        kotlinMetadataVariant: Variant,
        diagnosticsReporter: DiagnosticReporter
    ) {
        val kotlinProjectStructureMetadata: KotlinProjectStructureMetadata =
            computeIfAbsentInResolutionCache(context, "kotlinProjectStructureMetadata") {
                val kmpMetadata = kmpMetadataFile.getPath()?.let {
                    readJarEntry(it, "META-INF/kotlin-project-structure-metadata.json")
                }
                kmpMetadata?.parseKmpLibraryMetadata()
            } ?: run {
                diagnosticsReporter.addMessage(KotlinProjectStructureMetadataMissing.asMessage(kmpMetadataFile.fileName))
                return
            }

        // Resolving all leaf platform variants
        val resolvedVariants = context.settings.platforms.associateWith {
            resolveVariants(moduleMetadata, context.settings, it).withoutDocumentationAndMetadata
        }
        val platformsWithoutVariants = resolvedVariants.filterValues { it.isEmpty() }
        if (platformsWithoutVariants.isNotEmpty()) {
            reportVariantMismatchForLibrary(diagnosticsReporter, moduleMetadata, platformsWithoutVariants.keys)
        }

        val allPsmVariants = kotlinProjectStructureMetadata.projectStructure.variants.associateBy { it.name }

        // Mapping leaf platforms to visible sourceSets:
        //  - variants declared in Gradle metadata, but missing in PSM are ignored,
        //  - variants in PSM declaring empty list of visible "sourceSets" are ignored (those declarations make no sense)
        val resolvedPlatformSourceSets = resolvedVariants.mapValues {
            // join together visible source sets from multiple variants of the same platform
            it.value
                .mapNotNull { gradleVariant ->
                    allPsmVariants[gradleVariant.name]
                        ?: allPsmVariants[gradleVariant.name.removeSuffix(PUBLISHED_SUFFIX)]
                }.flatMap { it.sourceSet }.toSet()
        }

        val allSourceSets = kotlinProjectStructureMetadata.projectStructure.sourceSets.associateBy { it.name }

        // Selecting source sets visible for all target platforms (intersection).
        val sourceSetsIntersection = resolvedPlatformSourceSets.values
            .filter { it.isNotEmpty() }
            .let {
                if (it.isEmpty()) emptySet() else it.reduce { l1, l2 -> l1.intersect(l2) }
            }
            .filter { it in allSourceSets }.toSet()


        val allMatchingSourceSetNames = buildList {
            addAll(sourceSetsIntersection.sortFromMostSpecificSourceSet(allSourceSets))
            resolveCinteropSourceSet(sourceSetsIntersection, kotlinProjectStructureMetadata)?.let {
                // The cinterop metadata directory is not a source set and thus has no place in the 'dependsOn' hierarchy,
                // it is kept at the end of the list.
                add(it)
            }
        }

        // Transforming it right here, since it doesn't require network access in most cases.
        sourceSetsFiles = coroutineScope {
            allMatchingSourceSetNames
                .map {
                    async(Dispatchers.IO) {
                        toDependencyFile(
                            sourceSetName = it,
                            kmpMetadataFile,
                            moduleMetadata,
                            kotlinProjectStructureMetadata,
                            context,
                            level,
                            diagnosticsReporter
                        )
                    }
                }
        }.awaitAll()
            .mapNotNull { it }
            .flatten()

        if (transitive) {
            // Find source sets dependencies
            children = kotlinProjectStructureMetadata.projectStructure.sourceSets
                .filter { it.name in sourceSetsIntersection }
                .flatMap { it.moduleDependency }
                .toSet()
                .mapNotNull { rawDep ->
                    val parts = rawDep.split(":")
                    if (parts.size != 2) {
                        diagnosticsReporter.addMessage(UnexpectedDependencyFormat.asMessage(this, rawDep))
                        null
                    } else {
                        val dependencyGroup = parts[0]
                        val dependencyModule = parts[1]
                        kotlinMetadataVariant.dependencies(context, level, diagnosticsReporter)
                            .filterNot { shouldIgnoreDependency(it.group, it.module, context) }
                            .firstOrNull { it.group == dependencyGroup && it.module == dependencyModule }
                            ?.toMavenDependency(context) { reason ->
                                diagnosticsReporter.addMessage(
                                    UnableToDetermineDependencyVersionForKotlinLibrary.asMessage(
                                        this,
                                        rawDep,
                                        reason,
                                    )
                                )
                            }
                    }
                }
            // todo (AB) : take kotlinMetadataVariant.dependencyConstraints into account as well? What subset on constraints should be taken into account?
        }
    }

    /**
     * Orders the given sourceSet names from the most specific source sets to the most general ones,
     * so that the root source set (`commonMain` normally) comes last.
     *
     * Specificity is defined by the position of a source set in the `dependsOn` hierarchy: the longer the chain of
     * `dependsOn` edges leading from a source set to a root one, the more specific this source set is.
     * Source sets that are equally specific are ordered by name so that the result is deterministic.
     */
    private fun Collection<String>.sortFromMostSpecificSourceSet(
        psmSourceSets: Map<String, SourceSet>,
    ): List<String> {
        if (size < 2) return toList()

        val depths = mutableMapOf<String, Int>()

        fun depth(sourceSetName: String): Int = depths[sourceSetName] ?: run {
            // the temporary 0 guards against infinite recursion in case of a cycle in a malformed metadata
            depths[sourceSetName] = 0
            // source sets missing in the metadata are treated as root ones
            (psmSourceSets[sourceSetName]?.dependsOn?.maxOfOrNull { depth(it) + 1 } ?: 0)
                .also { depths[sourceSetName] = it }
        }

        return sortedWith(compareByDescending<String> { depth(it) }.thenBy { it })
    }

    /**
     * Cinterop source set is packaged differently from the regular sourceSets.
     * Each cinterop sourceSet has all available APIs.
     * For instance, macosSourceSet would have not only macOS-related API, but also apple, native and common ones.
     *
     * This way we have to select a single cinterop sourceSet - the most specific one matching target platforms.
     *
     * The code is inspired by the similar code from KGP plugin:
     * https://jetbrains.team/p/kt/repositories/kotlin/files/e8edf53610f82ecabfc2f8ae7aea8dc6f68409f2/libraries/tools/kotlin-gradle-plugin/src/common/kotlin/org/jetbrains/kotlin/gradle/targets/native/internal/CInteropMetadataDependencyClasspath.kt?tab=source&line=66&lines-count=1
     */
    private fun resolveCinteropSourceSet(
        sourceSetNames: Set<String>,
        kotlinProjectStructureMetadata: KotlinProjectStructureMetadata,
    ): String? {
        val sourceSetsWithCinterop = kotlinProjectStructureMetadata.projectStructure.sourceSets
            .filter { it.name in sourceSetNames && it.sourceSetCInteropMetadataDirectory != null }

        // All dependencies of given sourceSets
        val dependsOnSourceSets = sourceSetsWithCinterop
            .flatMap { it.dependsOn }
            .toSet()

        // Choose a sourceSet that nobody depends on from the list of matching sourceSets with cinterop,
        // such a source set contains the reachest API surface available for target platforms.
        val bottomSourceSets = sourceSetsWithCinterop.filter { it.name !in dependsOnSourceSets }.toSet()

        // Select the source set participating in the least number of variants (the most special one)
        val cinteropSourceSet = bottomSourceSets.minByOrNull { sourceSet ->
            kotlinProjectStructureMetadata.projectStructure.variants.count {
                sourceSet.name in it.sourceSet
            }
        }

        return cinteropSourceSet?.sourceSetCInteropMetadataDirectory
    }

    private fun getKotlinMetadataFile(kotlinMetadataVariant: Variant, diagnosticReporter: DiagnosticReporter) =
        kotlinMetadataVariant.files.singleOrNull()
            ?: run {
                diagnosticReporter.addMessage(KotlinMetadataNotResolved.asMessage(this))
                null
            }

    private fun getKotlinMetadataVariant(
        validVariants: List<Variant>,
        platform: ResolutionPlatform,
        context: Context,
        diagnosticReporter: DiagnosticReporter,
    ): Variant? {
        if (this.isKotlinTestAnnotationsCommon()) return null
        val metadataVariants = validVariants.filter { it.isKotlinMetadata(platform) }
        return metadataVariants.firstOrNull() ?: run {
            val resolvingForJvm =
                context.settings.platforms == setOf(ResolutionPlatform.JVM, ResolutionPlatform.ANDROID)
            diagnosticReporter.addMessage(
                DependencyIsNotMultiplatform.asMessage(
                    this,
                    overrideSeverity = Severity.WARNING.takeIf { resolvingForJvm }
                )
            )
            null
        }
    }

    private fun getKotlinMetadataSourcesVariant(
        validVariants: List<Variant>,
        platform: ResolutionPlatform,
    ): Variant? {
        if (this.isKotlinTestAnnotationsCommon()) return null
        return validVariants.firstOrNull { it.isKotlinMetadataSources(platform) }
    }

    // todo (AB) : All this logic might be wrapped into ExecuteOnChange
    // todo (AB) : in order to skip metadata resolution in case targetFile exists already
    private suspend fun toDependencyFile(
        sourceSetName: String,
        kmpMetadataFile: DependencyFileImpl,
        moduleMetadata: Module,
        kotlinProjectStructureMetadata: KotlinProjectStructureMetadata? = null, // is empty for sources only
        context: Context,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ): List<DependencyFileImpl>? {
        val group = kmpMetadataFile.dependency.group
        val module = kmpMetadataFile.dependency.module
        val version = kmpMetadataFile.dependency.version
        // kmpMetadataFile hash
        val sha1 = context.debugSpanBuilder("toDependencyFile -> getExpectedHash")
            .setAttribute("fileName", kmpMetadataFile.fileName)
            .use {
                kmpMetadataFile.getExpectedHash(getSha1Algorithm())
            }
            ?: kmpMetadataFile.getPath()?.let { path ->
                context.debugSpanBuilder("toDependencyFile -> computeHash")
                    .setAttribute("fileName", kmpMetadataFile.fileName)
                    .use {
                        computeHash(path, getSha1Algorithm()).hash
                    }
            }
            ?: run {
                diagnosticsReporter.addMessage(
                    KotlinMetadataHashNotResolved.asMessage(
                        kmpMetadataFile.dependency,
                        overrideSeverity = Severity.INFO.takeIf { level != ResolutionLevel.NETWORK },
                    )
                )
                return null
            }
        val kmpLibraryWithSourceSet = context.debugSpanBuilder("resolveKmpLibraryWithSourceSet")
            .use {
                kmpMetadataFile.dependency.computeIfAbsentInResolutionCache(
                    context,
                    "kmp:$sourceSetName:$level:${kotlinProjectStructureMetadata == null}:${kmpMetadataFile.fileName}"
                ) {
                    resolveKmpLibraryWithSourceSet(
                        sourceSetName,
                        kmpMetadataFile,
                        context,
                        kotlinProjectStructureMetadata,
                        moduleMetadata,
                        level,
                        diagnosticsReporter
                    )
                }?: run {
                    logger.debug("Source set $sourceSetName for Kotlin Multiplatform library ${kmpMetadataFile.fileName} is not found")
                    return@use null
                }
            } ?: return null

        val isSources = kmpMetadataFile.hasSourcesFilename()
        val sourcesSuffix = if (isSources) "-sources" else ""

        val targetDirectory = kmpMetadataFile.dependency.settings.fileCache.amperCache
            .resolve("kotlin/kotlinTransformedMetadataLibraries/")
            .resolve(group)
            .resolve(module)
            .resolve(version.orUnspecified())
            .resolve(sha1)

        val sourceSetFile = if (!sourceSetName.endsWith("-cinterop")) {
            // todo (AB) : Add test for downloading of KMP library sources of SNAPSHOT version
            // todo (AB) : (before the change such sources were incorrectly represented with regular DependencyFile)
            // regular sourceSet
            listOf(
                repackageSourceSet(
                    kmpMetadataFile,
                    sourceSetName,
                    kotlinProjectStructureMetadata,
                    moduleMetadata,
                    context,
                    kmpLibraryWithSourceSet,
                    targetDirectory,
                    "$module-$sourceSetName-$version$sourcesSuffix",
                    diagnosticsReporter
                )
            )
        } else {
            // todo (AB) : Check how it works with cinterop sources.
            // cinterop sourceSet
            val cinteropDirectoryName = "${kmpMetadataFile.dependency.module}-$sourceSetName$sourcesSuffix"
            val topLevelDirectories = getNestedDirectories(kmpLibraryWithSourceSet, sourceSetName)

            topLevelDirectories.map { cinteropName ->
                repackageSourceSet(
                    kmpMetadataFile,
                    sourceSetName,
                    kotlinProjectStructureMetadata,
                    moduleMetadata,
                    context,
                    kmpLibraryWithSourceSet,
                    targetDirectory.resolve(cinteropDirectoryName),
                    "$cinteropName$sourcesSuffix",
                    diagnosticsReporter,
                    pathInKmpLibrary = "$sourceSetName/$cinteropName",
                )
            }
        }
        return sourceSetFile
    }

    private suspend fun repackageSourceSet(
        kmpMetadataFile: DependencyFileImpl,
        sourceSetName: String,
        kotlinProjectStructureMetadata: KotlinProjectStructureMetadata?,
        moduleMetadata: Module,
        context: Context,
        kmpLibraryWithSourceSet: Path,
        targetDirectory: Path,
        targetFileNameWithoutExtension: String,
        diagnosticsReporter: DiagnosticReporter,
        pathInKmpLibrary: String = sourceSetName,
    ): DependencyFileImpl {
        val isSources = kmpMetadataFile.hasSourcesFilename()
        val extension = if (isSources) "jar" else "klib"

        val sourceSetFile = getDependencyFile(
            kmpMetadataFile.dependency,
            targetFileNameWithoutExtension,
            extension,
            isDocumentation = isSources
        )
        sourceSetFile.settings[KmpSourceSetName] = sourceSetName
        if (kotlinProjectStructureMetadata != null) {
            sourceSetFile.settings[KmpPlatforms] = retrievePlatforms(
                kotlinProjectStructureMetadata,
                moduleMetadata,
                sourceSetName,
            )
        }

        val targetFileName = "$targetFileNameWithoutExtension.$extension"
        val targetPath = targetDirectory.resolve(targetFileName)

        context.debugSpanBuilder("produceFileWithDoubleLockAndHash").use {
            produceFileWithDoubleLockAndHash(
                target = targetPath,
                tempDir = { sourceSetFile.getTempDir() },
            ) { _, fileChannel ->
                try {
                    copyJarEntryDirToJar(fileChannel, pathInKmpLibrary, kmpLibraryWithSourceSet)
                    true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val message = FailedRepackagingKMPLibrary.asMessage(
                        kmpLibraryWithSourceSet.name,
                        extra = DependencyResolutionBundle.message("extra.exception", e),
                        exception = e,
                        preventCaching = true,
                    )
                    logger.warn(message.message, e)
                    diagnosticsReporter.addMessage(message)
                    false
                }
            }
        }

        sourceSetFile.onFileDownloaded(targetPath)
        return sourceSetFile
    }

    /**
     * Retrieves all platforms supported by the given [sourceSetName] in the dependency.
     */
    private fun retrievePlatforms(
        kotlinProjectStructureMetadata: KotlinProjectStructureMetadata,
        moduleMetadata: Module,
        sourceSetName: String,
    ): Set<ResolutionPlatform> {
        val sourceSetVariants = kotlinProjectStructureMetadata.projectStructure
            .variants
            .filter { sourceSetName in it.sourceSet }
            .map { it.name }
        return moduleMetadata.variants
            .filter { it.name.removeSuffix(PUBLISHED_SUFFIX) in sourceSetVariants }
            .mapNotNull { getLeafPlatformFromVariant(it) }
            .toSet()
    }

    /**
     * This method returns kotlin metadata library that contains a given sourceSet.
     *
     * Usually, a kotlin metadata library contains both:
     * - sourceSets' descriptor: META-INF/kotlin-project-structure-metadata.json
     * - and sourceSets itself
     *
     * And in that case,
     * a path of the given kmpMetadataFile (representing the kotlin metadata library) is simply returned.
     *
     * But iOS sourceSet might be missing (for historical reasons);
     * in that case, sourceSets are stored in platform-specific kotlin metadata variants.
     * This method resolves such a platform-specific library and returns its path.
     *
     *  For example, let's consider a library
     *  org.jetbrains.compose.ui:ui-uikit:1.6.10
     *
     *  Its kotlin metadata variant defines sourceSet 'uikitMain', but it doesn't include sourceSet itself.
     *  (https://maven.pkg.jetbrains.space/public/p/compose/dev/org/jetbrains/compose/ui/ui-uikit/1.6.10/ui-uikit-1.6.10.jar),
     *
     *  Instead, sourceSet 'uikitMain' is included in the kotlin metadata variant of
     *  Each platform-specific dependency of the ui-uikit common library
     *  (for instance, in org.jetbrains.compose.ui:ui-uikit-uikitarm64:1.6.10)
     *  (https://maven.pkg.jetbrains.space/public/p/compose/dev/org/jetbrains/compose/ui/ui-uikit-uikitarm64/1.6.10/ui-uikit-uikitarm64-1.6.10-metadata.jar)
     */
    private suspend fun resolveKmpLibraryWithSourceSet(
        sourceSetName: String,
        kmpMetadataFile: DependencyFileImpl,
        context: Context,
        kotlinProjectStructureMetadata: KotlinProjectStructureMetadata?,
        moduleMetadata: Module,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ) = if (hasJarEntry(kmpMetadataFile.getPath()!!, sourceSetName) == true) {
        kmpMetadataFile.getPath()!!
    } else if (kotlinProjectStructureMetadata == null
        // Kotlin Toolchain doesn't support native leaf platform metadata files.
        // All existing source sets are packed in the all-metadata JAR.
        // If sourceSet is not found there, then it is empty.
        || moduleMetadata.createdBy?.kotlinToolchain != null)
    {
        null
    } else {
        val contextApplePlatforms = allApplePlatforms.intersect(context.settings.platforms)
        if (contextApplePlatforms.isNotEmpty()) {
            // 1. Find names of all variants that declare this sourceSet
            val variantsWithSourceSet = kotlinProjectStructureMetadata.projectStructure.variants
                .filter { it.sourceSet.contains(sourceSetName.removeSuffix("-cinterop")) }
                .map { it.name }

            // 2. Find Apple variants for actual Apple platforms
            val appleVariants = contextApplePlatforms.flatMap { platform ->
                resolveVariants(moduleMetadata, context.settings, platform)
                    .withoutDocumentationAndMetadata
                    .map { it to platform }
            }

            appleVariants.firstOrNull {
                // 3. Filter the first variant that declares sourceSet
                it.first.name.removeSuffix(PUBLISHED_SUFFIX) in variantsWithSourceSet
            }?.let {
                val platform = it.second
                // 4. Try to download artifact from that variant and resolve dependency from that
                it.first
                    .`available-at`
                    ?.asDependency()
                    ?.toMavenDependency(context, diagnosticsReporter)
                    ?.let { dependency ->
                        val depModuleMetadata = dependency.parseModuleMetadata(context, level, diagnosticsReporter)
                        depModuleMetadata?.let {
                            dependency.detectKotlinMetadataLibrary(
                                context,
                                platform,
                                depModuleMetadata,
                                level,
                                diagnosticsReporter
                            )
                        }
                    }?.let {
                        it.second.getPath()?.takeIf { hasJarEntry(it, sourceSetName) == true }
                    }
            }
        } else null
    }

    private fun resolveVariants(
        module: Module,
        settings: Settings,
        platform: ResolutionPlatform,
    ): List<Variant> {
        val initiallyFilteredVariants = module
            .variants
            .filter { capabilityMatches(it) }
            .filter { nativeTargetMatches(it, platform) }
            .filter { wasmJsTargetMatches(it, platform) }
            .filter { categoryMatches(it) }

        val validVariants = initiallyFilteredVariants
            .filterWithFallbackPlatform(platform)
            .filterWithFallbackJvmEnvironment(platform)
            .filterWithFallbackScope(settings.scope)
            .filterMultipleVariantsByUnusedAttributes()
            .filterWellKnowSpecialLibraries(this.group, this.module)
            .let {
                // If there are duplicates still.
                // We try to choose the best match by well-known attributes (not checked before)
                // that have a kind of "preferred" value.
                // This is intended to be the last step of variants resolution
                it.filterMultipleVariantsByAttributePreferredValue()
            }

        return validVariants
    }

    private fun resolveBomVariants(
        module: Module,
        settings: Settings,
    ): List<Variant> = module.variants
        .filter { categoryMatches(it) }
        .filterWithFallbackScope(settings.scope)

    private fun Variant.isOneOfExceptions() = isKotlinException() || isGuavaException() || isHibernateException()

    private fun Variant.isKotlinException() =
        isKotlinTestJunit() && capabilities.sortedBy { it.name } == listOf(
            Capability(group, "kotlin-test-framework-impl", version.orUnspecified()),
            toCapability()
        )

    // Skip metadata un-packaging for kotlin-test annotations.
    private fun isKotlinTestJunit() =
        group == "org.jetbrains.kotlin" && (module in setOf("kotlin-test-junit", "kotlin-test-junit5"))

    private fun isKotlinTestAnnotationsCommon() =
        group == "org.jetbrains.kotlin" && module == "kotlin-test-annotations-common"

    private fun isKotlinStdlibCommon() =
        group == "org.jetbrains.kotlin" && module == "kotlin-stdlib-common"

    private fun isKotlinStdlib() =
        group == "org.jetbrains.kotlin" && module == "kotlin-stdlib"

    private fun Variant.isGuavaException() =
        isGuava()
                && capabilities.contains(toCapability())
                && capabilities.contains(
            Capability(
                "com.google.collections",
                "google-collections",
                version.orUnspecified()
            )
        )

    private fun isGuava() = group == "com.google.guava" && module == "guava"

    /**
     * Hibernate ORM was published under the group `org.hibernate` until version 6, and under `org.hibernate.orm`
     * since then. To keep capability-based conflict detection working against the old coordinates, its variants
     * declare the legacy `org.hibernate:<module>` capability in addition to the current `org.hibernate.orm:<module>`
     * one.
     * This is a same-library rename that could in general produce a real capability conflict.
     * Being ignored, it could lead to adding classes from both old and new libraries on the classpath
     * in case the dependency graph includes both libraries (since those are not automatically aligned by vesion).
     * But in the case of Hibernate, the migration was done smoothly and transparently.
     * This is why a new version of a Hibernate library declaring capabilities
     * could be added to the dependency graph without any issues.
     *
     * How it works:
     * A new version of the library published to group `org.hibernate.orm` not only declares capabilities
     * but also declares dependency on `hibernate-platform` (BOM)
     * that among others defines a constraint for the OLD library as well.
     *
     * "dependencyConstraints": [
     *    ...
     *    {
     *     "group": "org.hibernate",
     *     "module": "hibernate-core",
     *     "version": {
     *       "requires": "7.4.1.Final"
     *      }
     *    },
     *
     * This way any OLD library met in the graph is automatically aligned with the version of the new library.
     * And, as a final piece of the puzzle, the old Hibernate library with group `org.hibernate` is kept publishing
     * with its new version as well.
     * But only pom.xml is published, and it is empty.
     * A single purpose of this stub pom is to serve as a relocation marker
     * and as a stub for dependency resolution. After the conflict is solved and a new version of old `org.hibernate` library
     * is resolved, the empty pom.xml comes into play and makes the resolution process happy.
     *
     * Note: Without this exception, [capabilityMatches] would reject the `apiElements`/`runtimeElements` variants (which
     * declare both capabilities) and keep only the capability-less `sources`/`javadoc` variants, silently dropping
     * the main jar related to the new Hibernate library from the classpath.
     */
    private fun Variant.isHibernateException() =
        isHibernate()
                && capabilities.contains(toCapability())
                && capabilities.contains(Capability("org.hibernate", module, version.orUnspecified()))

    private fun isHibernate() = group == "org.hibernate.orm"

    private fun MavenDependency.toCapability() = Capability(group, module, version.orUnspecified())

    private fun nativeTargetMatches(variant: Variant, platform: ResolutionPlatform) =
        !variant.hasKotlinPlatformType(PlatformType.NATIVE)
                || variant.hasNoAttribute(KotlinNativeTarget)
                || variant.hasKotlinNativeTarget(platform)

    private fun wasmJsTargetMatches(variant: Variant, platform: ResolutionPlatform) =
        !variant.hasKotlinPlatformType(PlatformType.WASM)
                || variant.hasNoAttribute(KotlinWasmTarget)
                || variant.hasKotlinWasmTarget(platform)

    private fun categoryMatches(variant: Variant) = variant.isBom() == isBom

    /**
     * Check that either dependency defines no capability, or its capability is equal to the library itself,
     * multiple capabilities are prohibited (apart from several well-known exceptional cases).
     *
     * Allowing libraries with multiple capabilities in a graph would lead to a potential runtime conflict
     * (when libraries with the same capabilities are added to the runtime).
     * Resolution of conflict between libraries with the same capability should be explicitly supported in Amper DR.
     * Until that, such libraries are denied.
     *
     * todo (AB): Why filtering against capabilities, how to make it right? See https://github.com/gradlex-org/jvm-dependency-conflict-resolution
     */
    private fun capabilityMatches(variant: Variant) =
        variant.capabilities.isEmpty() || variant.capabilities == listOf(toCapability()) || variant.isOneOfExceptions()

    private fun AvailableAt.asDependency() = Dependency(group, module, Version(version))

    /**
     * These libraries are applicable in the KMP context but don't have metadata with the set of supported platforms
     * as they're expected to always support everything.
     *
     * Thus, they can be erroneously treated as JVM-only, which isn't the case.
     */
    private fun isSpecialKmpLibrary(): Boolean = isKotlinTestAnnotationsCommon() || isKotlinStdlibCommon()

    private suspend fun resolveUsingPom(
        text: String,
        context: Context,
        level: ResolutionLevel,
        transitive: Boolean,
        diagnosticsReporter: DiagnosticReporter,
    ) {
        val project = resolvePom(text, context, level, diagnosticsReporter) ?: return

        if (isBom) {
            dependencyConstraints = project.resolveDependenciesConstraints(context)
        } else {
            if (transitive) {
                (project.dependencies?.dependencies ?: emptyList()).filter {
                    context.settings.scope.matches(it)
                }.filterNot {
                    shouldIgnoreDependency(it.groupId, it.artifactId, context)
                }.filter {
                    it.optional != true
                }.map {
                    context.createOrReuseDependency(it.coordinates, false)
                }.let {
                    children = it
                }
            }
        }

        // packaging type resolved from pom.xml
        pomPackagingType = project.packaging
            ?.let { PomPackagingType.FromPom(it) }
            ?: PomPackagingType.Unspecified

        // todo (AB): [KTC-5270]
        //  1. Do not resolve transitive dependencies of the library
        //  if its effective packaging type is among { 'fat', 'war', 'ear' }.
        //  Corresponding Maven ArtifactHandler specifies includesDependencies = true
        //  (i.e., resolved artifact includes dependencies already)
        //  2. Don't add resolved dependency artifact to the Graph
        //  if effective dependency packaging type is among { zip, rar, java-source }.
        //  Corresponding Maven ArtifactHandler specifies addedToClasspath = false

        state = getTargetState(level, transitive)

        if (mavenPackaging == "jar" && !isSpecialKmpLibrary()) {
            // effective packaging type is 'jar'
            val nonJvmPlatforms =
                context.settings.platforms.filter { it != ResolutionPlatform.JVM && it != ResolutionPlatform.ANDROID }
            // JAR-packed dependencies without metadata shouldn't be used for non-JVM platforms
            if (nonJvmPlatforms.isNotEmpty()) {
                diagnosticsReporter.addMessage(
                    PlatformsAreNotSupported(
                        this,
                        setOf(ResolutionPlatform.ANDROID, ResolutionPlatform.JVM)
                    )
                )
            }
        }

        // We have used a pom file for resolving dependency, => lower severity of module-metadata-related issues.
        if (moduleFile.diagnosticsReporter.hasErrors()) {
            moduleFile.diagnosticsReporter.suppress { suppressedMessages ->
                PomResolvedWithMetadataErrors(coordinates, suppressedMessages)
            }
        }
    }

    private suspend fun resolveDependenciesConstraintsUsingPom(
        text: String, context: Context, level: ResolutionLevel, diagnosticsReporter: DiagnosticReporter
    ): List<MavenDependencyConstraintImpl> = resolvePom(text, context, level, diagnosticsReporter)
        ?.resolveDependenciesConstraints(context)
        ?: emptyList()

    private fun Project.resolveDependenciesConstraints(context: Context): List<MavenDependencyConstraintImpl> {
        return (dependencyManagement?.dependencies?.dependencies ?: emptyList()).filter {
            it.version != null && it.optional != true
        }.map {
            context.createOrReuseDependencyConstraint(it.groupId, it.artifactId, Version(requires = it.version))
        }
    }

    internal val Collection<Variant>.withoutDocumentationAndMetadata: List<Variant>
        get() = filterNot { it.isDocumentationOrMetadata }

    private val Variant.isDocumentationOrMetadata: Boolean
        get() =
            isDocumentation() ||
                    getAttributeValue(Usage) == Usage.KotlinApi
                    && hasKotlinPlatformType(PlatformType.COMMON)

    private val Collection<Variant>.documentationOnly: List<Variant>
        get() = filter { it.isDocumentation() }

    suspend fun downloadDependencies(context: Context, downloadSources: Boolean = false) {
        if (downloadState < getTargetDownloadState(downloadSources)) {
            mutex.withLock {
                if (downloadState < getTargetDownloadState(downloadSources)) {
                    context.debugSpanBuilder("MavenDependencyNode.downloadDependencies")
                        .setAttribute("coordinates", this.toString())
                        .use {
                            downloadDependenciesImpl(context, downloadSources)
                        }
                }
            }
        }
    }

    private suspend fun downloadDependenciesImpl(context: Context, downloadSources: Boolean = false) {
        val withSources = downloadSources || alwaysDownloadSources()

        val allFiles = filesRaw(withSources)
        val notDownloaded = allFiles
            .filter {
                (context.settings.platforms.size == 1 // Verification of multiplatform hash is done at the file-producing stage
                        || it.settings[KmpSourceSetName] == null) // (except for artifact with all sources that is not marked with any kmpSourceSet)
                        && !it.isDownloadedWithVerification(settings = context.settings)
            }

        notDownloaded.forEach {
            it.diagnosticsReporter.reset()
            it.download(context, it.diagnosticsReporter)
        }

        allFiles.forEach { it.postProcess(context, withSources, ResolutionLevel.NETWORK, it.diagnosticsReporter) }

        downloadState = getTargetDownloadState(downloadSources)
    }

    private fun alwaysDownloadSources() = isKotlinStdlib()

    private suspend fun DependencyFileImpl.postProcess(
        context: Context,
        downloadSources: Boolean,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ) {
        repackageKmpLibrarySources(context, downloadSources, level, diagnosticsReporter)
    }

    private suspend fun DependencyFileImpl.repackageKmpLibrarySources(
        context: Context,
        downloadSources: Boolean,
        level: ResolutionLevel,
        diagnosticsReporter: DiagnosticReporter,
    ) {
        if (context.settings.platforms.size > 1
            && downloadSources
            && this.settings[KmpSourceSetName] == null
            && this.isSourcesDependencyFile()
        ) {
            // repackage KMP library sources.
            val kmpSourcesFile = this
            val sourceSetsSources = context.debugSpanBuilder("repackageKmpLibrarySources")
                .setAttribute("fileName", fileName)
                .use {
                    coroutineScope {
                        sourceSetsFiles
                            .map { sourceSetsFile ->
                                async(Dispatchers.IO) {
                                    context.debugSpanBuilder("toDependencyFile")
                                        .use {
                                            val sourceSetName =
                                                sourceSetsFile.settings[KmpSourceSetName] ?: return@use null
                                            val moduleMetadata =
                                                moduleMetadata ?: error("moduleMetadata wasn't initialized")

                                            // Extract sources from this DependencyFile and package extracted sources to separate location
                                            toDependencyFile(
                                                sourceSetName,
                                                kmpSourcesFile,
                                                moduleMetadata,
                                                null,
                                                context,
                                                level,
                                                diagnosticsReporter
                                            )
                                        }
                                }
                            }
                    }.awaitAll()
                        .mapNotNull { it }
                        .flatten()
                }
            // replace all-in-one sources file with per-sourceSet files
            sourceSetsFiles = sourceSetsFiles - this + sourceSetsSources
        }
    }

    private fun DependencyFileImpl.isSourcesDependencyFile(): Boolean =
        !files(withSources = false).map { it.fileName }.contains(this.fileName)

    private fun resolveArtifactExtension(packagingType: String): String {
        val actualPackagingType = when {
            // a not-substituted packaging type might be a result of referencing property
            // declared in the not yes supported active Maven profiles
            packagingType.contains("$") -> "jar".also {
                logger.warn("Packaging type of dependency $this is not resolved: $packagingType, falls back to $it")
                pom.diagnosticsReporter.addMessage(
                    UnresolvedMavenDependencyPackagingType.asMessage(this, packagingType, it)
                )
            }

            // Dependency packaging type (and further extension) is either specified explicitly
            // or resolved from the corresponding pom.xml
            else -> packagingType // by default get packaging type from pom (Maven uses "jar" by default)
        }
        return MavenCoordinates.resolveArtifactExtension(actualPackagingType)
    }

    companion object {
        /**
         * Suffix is added to the Gradle Metadata variant name.
         * It is an implementation detail and is a subject to change,
         * see https://docs.google.com/document/d/18MsmrX2iYuoKS3HvY-_xnk_SMenLQzSPArj4yuy1Hfw/edit?tab=t.0
         */
        private const val PUBLISHED_SUFFIX = "-published"

        sealed class PomPackagingType {
            object Unspecified : PomPackagingType() {
                const val DEFAULT: String = "jar"
            }
            data class FromPom(val value: String) : PomPackagingType()
        }

        val PomPackagingType.value: String
            get() = when(this) {
                PomPackagingType.Unspecified -> PomPackagingType.Unspecified.DEFAULT
                is PomPackagingType.FromPom -> value
            }
    }
}

fun mavenCoordinatesTrimmed(groupId: String, artifactId: String,version: String?, classifier: String? = null, packagingType: String? = null) =
        MavenCoordinates(
            groupId = groupId.trim(),
            artifactId = artifactId.trim(),
            version = version?.trim(),
            classifier = classifier?.trim(),
            packagingType = packagingType?.trim()
        )

/**
 * Describes coordinates of a Maven artifact.
 */
@Serializable
data class MavenCoordinates(
    val groupId: String,
    val artifactId: String,
    val version: String?,
    /*
     * Represents maven dependency packaging type (https://maven.apache.org/repositories/dependencies.html#dependency-types).
     * It might be explicitly defined as a part of a dependency declaration.
     *
     * Note: It is used for resolving maven dependency via its pom.xml descriptor only,
     * the value is ignored by DR if resolution is done via Gradle metadata (i.e.,
     * it is used only in case maven dependency is published without Gradle metadata).
     */
    val packagingType: String? = null,
    val classifier: String? = null,
) {
    override fun toString(): String = toPrettyString()

    fun toPrettyString(
        overridingVersion: String? = null,
        effectivePackagingType: String? = packagingType,
        hidePomPackagingType: Boolean = false,
    ): String {
        return "$groupId:$artifactId" +
                ":${version.orUnspecified()}" +
                (overridingVersion?.let { " -> $it" } ?: "") +
                (if (classifier != null) ":$classifier" else "") +
                (effectivePackagingType
                    ?.takeIf { resolveArtifactExtension(it) != "jar" } // No need to print default packaging type value
                    ?.takeIf { !hidePomPackagingType || it != "pom" } // Hiding pom packaging type from output
                    ?.let { "@$it" }
                    ?: "")
    }

    companion object {
        /**
         * The list includes well-known Maven packaging types that are represented with the artifact with jar extension
         * See default package types mapping https://maven.apache.org/ref/3.9.11/maven-core/artifact-handlers.html
         * Additionally, "bundle" is added here
         */
        private val packageTypeWithJavaExtension =
            setOf(
                "test-jar", "ejb", "ejb-client", "maven-plugin", "bundle",
                // since maven 4.1.0
                "classpath-jar", "module-jar", "processor", "classpath-processor", "modular-processor"
            )

        internal fun resolveArtifactExtension(packagingType: String): String {
            val extension =
                if (packagingType == "jar"
                    || packagingType in packageTypeWithJavaExtension
                    || packagingType.endsWith("-plugin")
                )
                    "jar"
                else
                    packagingType

            return extension
        }
    }
}

/**
 * The format of the 'available-at' element is described by the following link
 * https://github.com/gradle/gradle/blob/master/platforms/documentation/docs/src/docs/design/gradle-module-metadata-latest-specification.md#available-at-value
 * It doesn't have a built-in notion of classifier.
 */
internal fun AvailableAt.toCoordinates() =
    mavenCoordinatesTrimmed(group, module, version)

private fun Dependency.isBom(): Boolean = getAttributeValue(Category) == Category.Platform
private fun Variant.isBom(): Boolean = getAttributeValue(Category) == Category.Platform

private val allApplePlatforms = ResolutionPlatform.entries.filter {
    it.name.startsWith("IOS_")
            || it.name.startsWith("MACOS_")
            || it.name.startsWith("TVOS_")
            || it.name.startsWith("WATCHOS_")
}

// todo (AB) : 'strictly' should have special support (we have to take this into account during conflict resolution)
internal fun Version.resolve() = strictly?.resolveSingleVersion()
    ?: requires?.resolveSingleVersion()
    ?: prefers?.resolveSingleVersion()

internal fun Version.asString(): String =
    strictly?.let { "{strictly $strictly} -> $strictly" }
        ?: resolve()
        ?: "null"

internal fun String.resolveSingleVersion() = removeSquareBracketsForSingleValue()
    .reduceInterval()
    .takeIf { !it.isInterval() }

private fun String.isInterval() = startsWith("[") || startsWith("]")

private fun String.removeSquareBracketsForSingleValue() = when {
    startsWith("[") && endsWith("]") && !contains(",") -> substring(1, length - 1)
    else -> this
}

/**
 * Until intervals are fully supported, we try our best to interpret it at least as some viable version
 */
private fun String.reduceInterval() = when {
    startsWith("[") && contains(",") -> substring(1, this.indexOf(","))
    endsWith("]") && contains(",") -> substring(lastIndexOf(",") + 1, length - 1)
    else -> this
}

// todo (AB) :
// - interval are not implemented and we need to warn/show error to user about it
// - now strictly is treated as requires, should be supported properly

/**
 * Finds the path to the local .m2 repository as configured in Maven.
 * See the documentation of [findPath] for details.
 */
object LocalM2RepositoryFinder {
    /**
     * Finds the path to the local .m2 repository as configured in Maven.
     *
     * The location for the repository is determined in the same way as Gradle's mavenLocal() publications.
     * It looks at the following locations, in order of precedence:
     *
     * 1. The value of system property 'maven.repo.local' if set;
     * 2. The value of element `<localRepository>` of `~/.m2/settings.xml` if this file exists and an element is set;
     * 3. The value of element `<localRepository>` of `$M2_HOME/conf/settings.xml` (where `$M2_HOME` is the value of the
     *    environment variable with that name) if this file exists and an element is set;
     * 4. The path `<user.home>/.m2/repository` (where the user home is taken from the system property `user.home`)
     */
    fun findPath(): Path = Path(findLocalM2RepoPathString())

    private fun findLocalM2RepoPathString() = readFromSystemProperty()
        ?: parseFromUserHomeM2Settings()
        ?: parseFromM2HomeConfSettings()
        ?: "${System.getProperty("user.home")}/.m2/repository"

    private fun readFromSystemProperty() = System.getProperty("maven.repo.local")?.takeIf { it.isNotBlank() }

    private fun parseFromUserHomeM2Settings(): String? {
        val userHome = System.getProperty("user.home") ?: return null
        val userHomeSettingsXml = Path("$userHome/.m2/settings.xml")
        return parseLocalRepoIfExists(userHomeSettingsXml)
    }

    private fun parseFromM2HomeConfSettings(): String? {
        val m2Home = System.getenv("M2_HOME")?.takeIf { it.isNotBlank() } ?: return null
        val m2HomeSettingsXml = Path("$m2Home/conf/settings.xml")
        return parseLocalRepoIfExists(m2HomeSettingsXml)
    }

    private fun parseLocalRepoIfExists(settingsXml: Path): String? = resolveSafeOrNull {
        settingsXml
            .takeIf { it.exists() }
            ?.readText()
            ?.parseSettings()
            ?.localRepository()
    }
}

fun String?.orUnspecified(): String = this ?: "unspecified"

internal val org.jetbrains.amper.dependency.resolution.metadata.xml.Dependency.coordinates: MavenCoordinates
    get() = mavenCoordinatesTrimmed(groupId = groupId, artifactId = artifactId, version = version,
        classifier = classifier, packagingType = type)

fun DependencyNode.transitiveParents(
    visited: MutableSet<DependencyNode> = mutableSetOf(),
): Set<DependencyNode> {
    parents.forEach {
        if (visited.add(it)) {
            it.transitiveParents(visited)
        }
    }
    return visited
}