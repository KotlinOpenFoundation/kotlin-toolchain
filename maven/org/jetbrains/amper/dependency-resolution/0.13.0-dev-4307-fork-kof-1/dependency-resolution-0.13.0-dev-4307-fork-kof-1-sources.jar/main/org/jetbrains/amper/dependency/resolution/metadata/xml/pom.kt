/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.dependency.resolution.metadata.xml

import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.nullable
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encodeToString
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import nl.adaptivity.xmlutil.EventType
import nl.adaptivity.xmlutil.XmlBufferedReader
import nl.adaptivity.xmlutil.XmlWriter
import nl.adaptivity.xmlutil.consecutiveTextContent
import nl.adaptivity.xmlutil.serialization.XML
import nl.adaptivity.xmlutil.serialization.XmlChildrenName
import nl.adaptivity.xmlutil.serialization.XmlElement
import nl.adaptivity.xmlutil.serialization.XmlSerialName
import org.jetbrains.amper.dependency.resolution.resolveSingleVersion
import org.jetbrains.amper.incrementalcache.DynamicInputs
import org.jetbrains.amper.system.info.OsFamily

internal val xml = XML {
    defaultPolicy {
        ignoreUnknownChildren()
    }
}

internal fun String.parsePom(): Project {
    // Normalize 4.1.0 namespace to 4.0.0 for compatibility with annotations
    val xmlString = this
        .replace(POM_XML_NAMESPACE_4_1_0,POM_XML_NAMESPACE_4_0_0)
        .replace("<project>", "<project xmlns=\"$POM_XML_NAMESPACE_4_0_0\">")

    return xml.decodeFromString(xmlString)
}

internal fun Project.serialize(): String = xml.encodeToString(this)

private const val POM_XML_NAMESPACE_4_0_0 = "http://maven.apache.org/POM/4.0.0"
private const val POM_XML_NAMESPACE_4_1_0 = "http://maven.apache.org/POM/4.1.0"

object MavenPomPropertiesXmlSerializer : KSerializer<Properties> {

    private val fallbackSerializer = MapSerializer(String.serializer(), String.serializer().nullable)

    override val descriptor: SerialDescriptor = buildClassSerialDescriptor("maven.properties") {
        element("properties", fallbackSerializer.descriptor)
    }

    private val Decoder.xmlReaderOrNull
        get() = (this as? XML.XmlInput)?.input as? XmlBufferedReader

    private val Encoder.xmlWriterOrNull
        get() = (this as? XML.XmlOutput)?.target

    private fun XmlWriter.encodeProperties(properties: Map<String, String?>) {
        startTag(POM_XML_NAMESPACE_4_0_0, "properties", "")
        properties.forEach { [k, v] ->
            startTag(POM_XML_NAMESPACE_4_0_0, k, "")
            v?.let { text(v) }
            endTag(POM_XML_NAMESPACE_4_0_0, k, "")
        }
        endTag(POM_XML_NAMESPACE_4_0_0, "properties", "")
    }

    private fun XmlBufferedReader.decodeProperties(): Map<String, String?> = buildMap {
        if (localName != "properties") throw SerializationException("Expected properties tag")
        nextTag()
        while (hasNext()) {
            if (localName == "properties" && eventType == EventType.END_ELEMENT) break
            if (eventType == EventType.START_ELEMENT) {
                if (localName == "property") {
                    var name: String? = null
                    var value: String? = null
                    while (hasNext() && !(eventType == EventType.END_ELEMENT && localName == "property")) {
                        if (eventType == EventType.START_ELEMENT) {
                            when (localName) {
                                "name" -> name = consecutiveTextContent()
                                "value" -> value = consecutiveTextContent()
                            }
                        }
                        nextTag()
                    }
                    name ?: throw SerializationException("Property name is not specified")
                    value ?: throw SerializationException("Property value for name '$name' is not specified")
                    set(name, value)
                } else {
                    val localName = localName
                    if (next() == EventType.END_ELEMENT) {
                        set(localName, null)
                    } else {
                        set(localName, consecutiveTextContent())
                    }
                }
            }
            nextTag()
        }
    }

    override fun deserialize(decoder: Decoder) = Properties(
        decoder.xmlReaderOrNull?.decodeProperties()
            ?: fallbackSerializer.deserialize(decoder)
    )

    override fun serialize(encoder: Encoder, value: Properties) =
        encoder.xmlWriterOrNull?.encodeProperties(value.properties)
            ?: fallbackSerializer.serialize(encoder, value.properties)
}

@Serializable
@XmlSerialName("project", POM_XML_NAMESPACE_4_0_0)
data class Project(
    @XmlElement(true)
    val modelVersion: String? = null,
    @XmlElement(true)
    val parent: Parent? = null,
    @XmlElement(true)
    val groupId: String? = null,
    @XmlElement(true)
    val artifactId: String? = null,
    @XmlElement(true)
    val version: String? = null,
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val description: String? = null,
    @XmlElement(true)
    val url: String? = null,
    @XmlElement(true)
    val inceptionYear: String? = null,
    @XmlElement(true)
    val organization: Organization? = null,
    @XmlElement(true)
    val licenses: Licenses? = null,
    @XmlElement(true)
    val developers: Developers? = null,
    @XmlElement(true)
    val contributors: Contributors? = null,
    @XmlElement(true)
    val prerequisites: Prerequisites? = null,
    @XmlElement(true)
    val scm: Scm? = null,
    @XmlElement(true)
    val dependencyManagement: DependencyManagement? = null,
    @XmlElement(true)
    val properties: Properties? = null,
    @XmlElement(true)
    val dependencies: Dependencies? = null,
    @XmlElement(true)
    val packaging: String? = null,
    @XmlElement(true)
    val profiles: Profiles? = null
)

@Serializable
@XmlSerialName("parent", POM_XML_NAMESPACE_4_0_0)
data class Parent(
    @XmlElement(true)
    val groupId: String,
    @XmlElement(true)
    val artifactId: String,
    @XmlElement(true)
    val version: String,
)

@Serializable
@XmlSerialName("organization", POM_XML_NAMESPACE_4_0_0)
data class Organization(
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val url: String? = null,
)

@Serializable
@XmlSerialName("licenses", POM_XML_NAMESPACE_4_0_0)
data class Licenses(
    @XmlElement(true)
    val licenses: List<License>
)

@Serializable
@XmlSerialName("license", POM_XML_NAMESPACE_4_0_0)
data class License(
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val url: String? = null,
    @XmlElement(true)
    val distribution: String? = null,
)

@Serializable
@XmlSerialName("developers", POM_XML_NAMESPACE_4_0_0)
data class Developers(
    @XmlElement(true)
    val developers: List<Developer>
)

@Serializable
@XmlSerialName("developer", POM_XML_NAMESPACE_4_0_0)
data class Developer(
    @XmlElement(true)
    val id: String? = null,
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val email: String? = null,
    @XmlElement(true)
    val organization: String? = null,
    @XmlElement(true)
    val organizationUrl: String? = null,
    @XmlElement(true)
    @XmlSerialName("roles", POM_XML_NAMESPACE_4_0_0)
    @XmlChildrenName("role", POM_XML_NAMESPACE_4_0_0)
    val roles: List<String>? = null,
)

@Serializable
@XmlSerialName("contributors", POM_XML_NAMESPACE_4_0_0)
data class Contributors(
    @XmlElement(true)
    val contributors: List<Contributor>
)

@Serializable
@XmlSerialName("contributor", POM_XML_NAMESPACE_4_0_0)
data class Contributor(
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val organization: String? = null,
    @XmlElement(true)
    val email: String? = null,
    @XmlElement(true)
    val url: String? = null,
    @XmlElement(true)
    @XmlSerialName("roles", POM_XML_NAMESPACE_4_0_0)
    @XmlChildrenName("role", POM_XML_NAMESPACE_4_0_0)
    val roles: List<String>? = null,
)

@Serializable
@XmlSerialName("prerequisites", POM_XML_NAMESPACE_4_0_0)
data class Prerequisites(
    @XmlElement(true)
    val maven: String = "2.0",
)

@Serializable
@XmlSerialName("dependencyManagement", POM_XML_NAMESPACE_4_0_0)
data class DependencyManagement(
    @XmlElement(true)
    val dependencies: Dependencies? = null,
)

@JvmName("plusNullable")
operator fun DependencyManagement?.plus(other: DependencyManagement?): DependencyManagement? {
    if (this == null) return other
    return this + other
}

operator fun DependencyManagement.plus(other: DependencyManagement?): DependencyManagement {
    if (other == null) return this
    if (this.dependencies == null) return other
    return DependencyManagement(this.dependencies + other.dependencies)
}

@Serializable(with = MavenPomPropertiesXmlSerializer::class)
@XmlSerialName("Properties", POM_XML_NAMESPACE_4_0_0)
data class Properties(
    val properties: Map<String, String?> = mapOf(),
)

operator fun Properties?.plus(other: Properties?): Properties? {
    if (this == null) return other
    return Properties(this.properties + (other?.properties ?: mapOf()))
}

@Serializable
@XmlSerialName("dependencies", POM_XML_NAMESPACE_4_0_0)
data class Dependencies(
    @XmlElement(true)
    val dependencies: List<Dependency>
)

@JvmName("plusNullable")
operator fun Dependencies?.plus(other: Dependencies?): Dependencies? {
    if (this == null) return other
    return this + other
}

operator fun Dependencies.plus(other: Dependencies?): Dependencies {
    val allDependencies = this.dependencies + (other?.dependencies ?: emptyList())
    return Dependencies(
        // Keep a single declaration per [Dependency.managementKey]
        // (closest to the original pom => the first one in the list)
        allDependencies.distinctBy { it.managementKey }
    )
}

@Serializable
@XmlSerialName("scm", POM_XML_NAMESPACE_4_0_0)
data class Scm(
    @XmlElement(true)
    val connection: String? = null,
    @XmlElement(true)
    val developerConnection: String? = null,
    @XmlElement(true)
    val url: String? = null,
    @XmlElement(true)
    val tag: String? = null,
)

@Serializable
@XmlSerialName("dependency", POM_XML_NAMESPACE_4_0_0)
data class Dependency(
    @XmlElement(true)
    val groupId: String,
    @XmlElement(true)
    val artifactId: String,
    @XmlElement(true)
    val version: String? = null,
    @XmlElement(true)
    val optional: Boolean? = null,
    @XmlElement(true)
    val type: String? = null,
    @XmlElement(true)
    val classifier: String? = null,
    @XmlElement(true)
    val scope: String? = null,
    @XmlElement(true)
    val exclusions: Exclusions? = null,
)

/**
 * The key a dependency declaration is identified by while merging the `dependencies` sections of several poms.
 * It matches the key used by Maven (see `org.apache.maven.model.Dependency.getManagementKey`),
 * in particular, [Dependency.type] defaults to `jar` and [Dependency.classifier] is a part of the key.
 */
internal val Dependency.managementKey: String
    get() = "$groupId:$artifactId:${type ?: "jar"}" + (classifier?.let { ":$it" } ?: "")

@Serializable
@XmlSerialName("exclusions", POM_XML_NAMESPACE_4_0_0)
data class Exclusions(
    @XmlElement(true)
    val exclusions: List<Exclusion>,
)

@Serializable
@XmlSerialName("exclusion", POM_XML_NAMESPACE_4_0_0)
data class Exclusion(
    @XmlElement(true)
    val groupId: String,
    @XmlElement(true)
    val artifactId: String? = null,
)

@Serializable
@XmlSerialName("profiles", POM_XML_NAMESPACE_4_0_0)
data class Profiles(
    @XmlElement(true)
    val profiles: List<Profile>? = null
)


@Serializable
@XmlSerialName("profile", POM_XML_NAMESPACE_4_0_0)
data class Profile(
    @XmlElement(true)
    val id: String? = null,
    @XmlElement(true)
    val activation: List<ProfileActivation>? = null,
    @XmlElement(true)
    val properties: Properties? = null,
    @XmlElement(true)
    val dependencies: Dependencies? = null,
    @XmlElement(true)
    val dependencyManagement: DependencyManagement? = null,
)

@Serializable
@XmlSerialName("activation", POM_XML_NAMESPACE_4_0_0)
data class ProfileActivation(
    @XmlElement(true)
    val activeByDefault: Boolean? = null,
    @XmlElement(true)
    val jdk: String? = null,
    @XmlElement(true)
    val os: ActivationOS? = null,
    @XmlElement(true)
    val property: ActivationProperty? = null,
    @XmlElement(true)
    val file: ActivationFile? = null,
)

@Serializable
@XmlSerialName("property", POM_XML_NAMESPACE_4_0_0)
data class ActivationProperty(
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val value: String? = null,
)

@Serializable
@XmlSerialName("file", POM_XML_NAMESPACE_4_0_0)
data class ActivationFile(
    @XmlElement(true)
    val missing: String? = null,
    @XmlElement(true)
    val exists: String? = null,
)

@Serializable
@XmlSerialName("os", POM_XML_NAMESPACE_4_0_0)
data class ActivationOS(
    @XmlElement(true)
    val name: String? = null,
    @XmlElement(true)
    val family: String? = null,
    @XmlElement(true)
    val arch: String? = null,
    @XmlElement(true)
    val version: String? = null,
)

internal fun Dependency.expandTemplates(project: Project, dynamicInputs: DynamicInputs): Dependency = copy(
    groupId = groupId.expandTemplate(project, dynamicInputs),
    artifactId = artifactId.expandTemplate(project, dynamicInputs),
    version = version?.expandTemplate(project, dynamicInputs)?.takeIf{ it.isNotBlank() }?.resolveSingleVersion(),
    type = type?.expandTemplate(project, dynamicInputs)?.takeIf{ it.isNotBlank() },
    classifier = classifier?.expandTemplate(project, dynamicInputs)?.takeIf{ it.isNotBlank() },
    scope = scope?.expandTemplate(project, dynamicInputs)?.takeIf{ it.isNotBlank() },
)

internal fun Project.expandTemplates(dynamicInputs: DynamicInputs): Project = copy(
    packaging = packaging?.expandTemplate(this, dynamicInputs),
    artifactId = artifactId?.expandTemplate(this, dynamicInputs),
    groupId = groupId?.expandTemplate(this, dynamicInputs),
    version = version?.expandTemplate(this, dynamicInputs),
)

/**
 * Substitutes references to the properties used in this string with their actual values the way Maven does
 * (see `org.apache.maven.model.interpolation.AbstractStringBasedModelInterpolator.createValueSources`):
 * built-in properties of the project, and the properties declared in its pom take precedence
 * over system properties and environment variables.
 */
internal fun String.expandTemplate(project: Project, dynamicInputs: DynamicInputs): String {
    if (!contains($$"${") || !contains("}")) {
        return this
    }

    val keyStarts = indexOf($$"${")
    val keyEnds = indexOf("}")

    val key = substring(keyStarts + $$"${".length, keyEnds)

    // Maven resolves built-in properties prefixed with 'pom.'
    // the same way it resolves built-in properties prefixed with 'project.'
    val builtInPrefix = "project.".takeIf { key.startsWith(it) }
        ?: "pom.".takeIf { key.startsWith(it) }

    val builtInPropertyValue = if (builtInPrefix != null) {
        when (key.removePrefix(builtInPrefix)) {
            "groupId" -> project.groupId ?: project.parent?.groupId
            "artifactId" -> project.artifactId ?: project.parent?.artifactId
            "version" -> project.version ?: project.parent?.version
            "prerequisites.maven" -> project.prerequisites?.maven
            "parent.groupId" -> project.parent?.groupId
            "parent.artifactId" -> project.parent?.artifactId
            "parent.version" -> project.parent?.version
            else -> null
        }
    } else null

    val value = builtInPropertyValue
        ?: project.properties?.properties?.let { properties ->
            if (properties.containsKey(key)) properties[key] ?: "" else null // null value works as well
        }
        ?: dynamicInputs.systemPropertyOrEnvironmentVariable(key)
        // Maven keeps the references it failed to resolve as is
        ?: return this

    val expandedValue = substring(0, keyStarts) +
            value.expandTemplate(project, dynamicInputs) +
            substring(keyEnds + 1, this.length)

    // recursively replace all later properties in the given string
    return expandedValue.expandTemplate(project, dynamicInputs)
}

/**
 * Resolves the value of the property [name] as Maven does: names prefixed with `env.` refer to environment variables,
 * the rest refer to system properties.
 *
 * The access is registered as a dynamic input so that the cached resolution result is invalidated
 * once the value changes.
 */
internal fun DynamicInputs.systemPropertyOrEnvironmentVariable(name: String): String? =
    if (name.startsWith("env.")) {
        name.substringAfter("env.")
            .let { if (OsFamily.current.isWindows) it.uppercase() else it }
            .let { readEnv(it) }
    } else {
        readSystemProperty(name)
    }
