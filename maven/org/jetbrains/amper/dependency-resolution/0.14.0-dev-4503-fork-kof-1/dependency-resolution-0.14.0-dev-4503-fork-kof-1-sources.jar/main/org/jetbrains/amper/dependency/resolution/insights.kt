/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.dependency.resolution

import org.jetbrains.amper.dependency.resolution.diagnostics.Message

/**
 * Wraps given dependency node overriding its parents and children.
 * It is intended to be used to filter out redundant information from the graph representing
 * a partial subgraph of the original graph.
 */
internal class DependencyNodeWithChildren(val node: DependencyNode): DependencyNode {
    override val children: MutableList<DependencyNode> = mutableListOf()
    override val key: Key<*> = node.key
    override val messages: List<Message> = node.messages.toMutableList()

    override val parents: MutableSet<DependencyNode> = mutableSetOf()

    override val graphEntryName: String
        get() = node.graphEntryName

    override fun toString() = graphEntryName
}

/**
 * Returned filtered dependencies graph,
 * containing paths from the given root node to the maven dependency node corresponding to the given coordinates ([group] and [module])
 * and having the version equal to the actual resolved version of this dependency in the graph.
 * If the resolved dependency version is enforced by constraint, then the path to that constraint is presented
 * in a returned graph together with paths to all versions of this dependency.
 *
 * Every node of the returned graph is of the type [DependencyNodeWithChildren] holding the corresponding node of the original graph inside.
 */
fun DependencyNode.filterGraph(group: String, module: String, resolvedVersionOnly: Boolean = false): DependencyNode {
    val graph = this

    val targetNodes: MutableSet<DependencyNode> = mutableSetOf()
    val groupedResolvedConstraintsByKey: MutableMap<Pair<String, String>, MutableList<MavenDependencyConstraintNode>> = mutableMapOf()

    // Do one iteration through the graph collecting all necessary information
    graph.distinctBfsSequence().forEach { node ->
        if (node.belongsTo(group, module)) {
            // Nodes that we are interested in
            targetNodes.add(node)
        }
        if (node is MavenDependencyConstraintNode && node.version == node.dependencyConstraint.version) {
            // Decisive (non-overridden) constraints
            val constraintsList = groupedResolvedConstraintsByKey[node.group to node.module]
                ?: mutableListOf<MavenDependencyConstraintNode>()
                    .also {
                        groupedResolvedConstraintsByKey[node.group to node.module] = it
                    }
            constraintsList.add(node)
        }
    }

    if (targetNodes.isEmpty()) {
        // root node without children
        return DependencyNodeWithChildren(graph)
    }

    if (resolvedVersionOnly && targetNodes.any { it is MavenDependencyNode }) {
        // Ignoring redundant constraints
        targetNodes.removeIf { it !is MavenDependencyNode }
    }

    val nodesWithDecisiveParents = mutableSetOf<DependencyNode>()
    targetNodes.addDecisiveParents(
        nodesWithDecisiveParents, graph, group, module, resolvedVersionOnly, groupedResolvedConstraintsByKey)

    val filteredGraph = graph.withFilteredChildren(resolvedVersionOnly = resolvedVersionOnly) { child, parent ->
        !resolvedVersionOnly && child in nodesWithDecisiveParents
                ||
                (resolvedVersionOnly
                        && child in nodesWithDecisiveParents
                        && (child.correspondsToResolvedVersionOf(group, module)
                        || !parent.correspondsToResolvedVersionOf(group, module)
                        && !parent.children.any { it.correspondsToResolvedVersionOf(group, module) })
                        )
    }
    return filteredGraph
}

private fun DependencyNode.belongsTo(group: String, module: String): Boolean =
    this is MavenDependencyNode && this.group == group && this.module == module
            || this is MavenDependencyConstraintNode && this.group == group && this.module == module

private fun DependencyNode.correspondsToResolvedVersionOf(group: String, module: String): Boolean =
     this.belongsTo(group, module) && this.originalVersion() == this.resolvedVersion()

/**
 * It takes a collection of nodes and calculates all intermediate nodes up to the root
 * that belong to the path from the root node to the node from the original collection.
 *
 * It takes none-overridden nodes only if possible
 * (as soon as a dependency node is overridden,
 * it is no longer possible to say whether its actual overridden children were requested by the original version of the dependency or not)
 *
 * On the first step the given collection is filtered the following way:
 * - Nodes of the given collection that are neither maven dependency nor constraints are added to the resulting set unconditionally
 * - If the given collection contains non-overridden dependency nodes, then those are added to the resulting set,
 *   and the method is called for parents of the resulting set nodes.
 * - If all dependency nodes from the given collection are overridden,
 *   and there is a constraint that caused that (either in a given list or somewhere else in a graph).
 *   Then all dependency nodes together with effective constraint are added to the resulting set,
 *   and the method is called for parents of the resulting set nodes.
 */
private fun Set<DependencyNode>.addDecisiveParents(
    nodesWithDecisiveParents: MutableSet<DependencyNode>,
    graph: DependencyNode,
    groupForInsight: String,
    moduleForInsight: String,
    resolvedVersionOnly: Boolean,
    groupedResolvedConstraintsByKey: Map<Pair<String, String>, List<MavenDependencyConstraintNode>>,
) {
    val allDependenciesAndConstraints = filter { it is MavenDependencyNode || it is MavenDependencyConstraintNode }.toSet()
    val noneFilterableNodes = this - allDependenciesAndConstraints

    val nodes = if (allDependenciesAndConstraints.isEmpty()) {
        emptySet()
    } else {
        val groupedByCoordinates = allDependenciesAndConstraints.groupBy {
            when (it) {
                is MavenDependencyNode -> it.group to it.module
                is MavenDependencyConstraintNode -> it.group to it.module
                else -> error("unexpected node type ${it::class.java.simpleName}")
            }
        }

        groupedByCoordinates.flatMap { entry ->
            val [group, module] = entry.key
            val dependenciesAndConstraints = entry.value

            val effectiveNodes = dependenciesAndConstraints.filter {
                it is MavenDependencyNode &&  it.dependency.version != null && it.originalVersion == it.dependency.version
                        || it is MavenDependencyConstraintNode && it.version == it.dependencyConstraint.version
            }.toSet()

            val dependencies = dependenciesAndConstraints.filterIsInstance<MavenDependencyNode>()
            if (effectiveNodes.isEmpty()) {
                val constraints = dependenciesAndConstraints
                    .mapNotNull { node ->
                        groupedResolvedConstraintsByKey[entry.key]
                            ?.filter {
                                it.group == group && it.module == module
                                        && it.version == it.dependencyConstraint.version
                                        && node.resolvedVersion() == it.originalVersion()
                            }
                    }.flatten()
                    .distinct()

                (dependencies + constraints).toSet()
            } else {
                if (effectiveNodes.any { it is MavenDependencyNode }) {
                    // Constraints are redundant
                    (effectiveNodes.filterIsInstance<MavenDependencyNode>()
                            + if (!resolvedVersionOnly) dependencies.filter { it.group == groupForInsight && it.module == moduleForInsight } else emptySet()
                    ).toSet()
                } else {
                    // constraints only => take both dependencies and constraints
                    (dependencies + effectiveNodes).toSet()
                }
            }.filter {
                !resolvedVersionOnly
                        || it.isThereAPathToTopBypassingEffectiveParents(group, module)
                        && it.isThereAPathToTopBypassingEffectiveParents(groupForInsight, moduleForInsight)
            }
        }
    } + noneFilterableNodes

    val addedNodes = nodes.filter { nodesWithDecisiveParents.add(it) }

    addedNodes.forEach {
        // todo (AB) : Some parents might be obsolete (unreachable from the root) in case those are left from canceled conflicting subgraph
        it.parents.toSet().addDecisiveParents(
            nodesWithDecisiveParents, graph, groupForInsight, moduleForInsight, resolvedVersionOnly, groupedResolvedConstraintsByKey)
    }
}

/**
 * This method checks that the node is reachable from the root via some path
 * that doesn't contain the given dependency of the effective (resolved) version.
 *
 * If there is no such path, that means that the node can't affect the version of a given dependency because it was added
 * to the graph because of that dependency in the first place.
 *
 * Effective parents are either
 * parents if a dependency version was not overridden
 * or a set of nodes that caused the version of dependency to be overridden
 */
private fun DependencyNode.isThereAPathToTopBypassingEffectiveParents(group: String, module: String, visited: MutableSet<DependencyNode> = mutableSetOf()): Boolean {
    if (parents.isEmpty()) return true // we reach the root

    visited.add(this)

    val filteredEffectiveParents = when(this) {
        is MavenDependencyNode -> if (this.resolvedVersion() != this.originalVersion()) overriddenBy else parents
        is MavenDependencyConstraintNode -> if (this.resolvedVersion() != this.originalVersion()) overriddenBy else parents
        else -> parents
    }.filterNot { it.correspondsToResolvedVersionOf(group, module) }


    if (filteredEffectiveParents.isEmpty()) return false // node has effective parents, but all of them are among those we should bypass along the way to root

    return filteredEffectiveParents
        .filterNot { it in visited }
        .any { it.isThereAPathToTopBypassingEffectiveParents(group, module, visited) }
}

fun DependencyNode.withFilteredChildren(
    resolvedVersionOnly: Boolean = false,
    childrenFilter: (DependencyNode, DependencyNode) -> Boolean
): DependencyNode = withFilteredChildrenImpl(
    resolvedVersionOnly = resolvedVersionOnly,
    childrenFilter = childrenFilter
)

/**
 * Returned filtered dependencies graph.
 * Given filter is applied transitively to the children of all the nodes of the original graph.
 *
 * Every node of the returned graph is of the type [DependencyNodeWithChildren] holding the original node inside.
 */
private fun DependencyNode.withFilteredChildrenImpl(
    cachedChildrenMap: MutableMap<DependencyNode, DependencyNodeWithChildren> = mutableMapOf(),
    resolvedVersionOnly: Boolean = false,
    childrenFilter: (DependencyNode, DependencyNode) -> Boolean
): DependencyNodeWithChildren {
    val currentNode = this
    return cachedChildrenMap[currentNode] ?: run {
        val nodeWithFilteredChildren = DependencyNodeWithChildren(currentNode)
        // Put the node in the map before traversing children
        cachedChildrenMap[currentNode] = nodeWithFilteredChildren

        val children = children
            .filter { childrenFilter(it, currentNode) }
            // Leaving the only transitive subtree (all other subtrees don't add valuable information)
            .let { if (it.size > 1 && resolvedVersionOnly && this is MavenDependencyNode) it.subList(0,1) else it }
            .map { it.withFilteredChildrenImpl(cachedChildrenMap, resolvedVersionOnly, childrenFilter) }
        nodeWithFilteredChildren.children.addAll(children)

        children.forEach { it.parents.add(nodeWithFilteredChildren) }

        nodeWithFilteredChildren
    }
}
