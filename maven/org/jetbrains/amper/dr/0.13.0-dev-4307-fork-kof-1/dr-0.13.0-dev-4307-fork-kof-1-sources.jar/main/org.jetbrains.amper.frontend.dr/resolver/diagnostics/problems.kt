/*
 * Copyright 2000-2025 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */
package org.jetbrains.amper.frontend.dr.resolver.diagnostics

import org.jetbrains.amper.dependency.resolution.DependencyNode
import org.jetbrains.amper.dependency.resolution.TypedKeyMap
import org.jetbrains.amper.dependency.resolution.diagnostics.Message
import org.jetbrains.amper.dependency.resolution.diagnostics.Severity
import org.jetbrains.amper.frontend.dr.resolver.diagnostics.DrDiagnosticsRegistrar.reporters
import org.jetbrains.amper.frontend.dr.resolver.diagnostics.reporters.BasicDrDiagnosticsReporter
import org.jetbrains.amper.frontend.dr.resolver.diagnostics.reporters.OverriddenDirectModuleDependencies
import org.jetbrains.amper.problems.reporting.Level
import org.jetbrains.amper.problems.reporting.ProblemReporter

object DrDiagnosticsRegistrar {
    val reporters = listOf(
        BasicDrDiagnosticsReporter,
        OverriddenDirectModuleDependencies(),
    )
}

interface DrDiagnosticsReporter {
    /**
     * The most severe level at which diagnostics are reported by this reporter.
     * If the requested level is more severe than the level of the diagnostics reporter, then it is skipped.
     */
    val level: Level

    fun reportBuildProblemsForNode(node: DependencyNode, problemReporter: ProblemReporter, level: Level, context: DrReporterContext)
}

/**
 * Traverse the entire dependencies graph collecting build problems for every node with the help of a predefined
 * list of diagnostics reporters
 */
fun collectBuildProblems(graph: DependencyNode, problemReporter: ProblemReporter, level: Level) =
    collectBuildProblems(graph, problemReporter, level, reporters)

/**
 * Traverse the entire dependencies graph collecting build problems for every node.
 */
fun collectBuildProblems(graph: DependencyNode, problemReporter: ProblemReporter, level: Level, diagnosticReporters: List<DrDiagnosticsReporter>){
    val drReporterContext = DrReporterContext(graph)
    for (node in graph.distinctBfsSequence()) {
        diagnosticReporters.forEach { reporter ->
            if (reporter.level.atLeastAsSevereAs(level)) {
                reporter.reportBuildProblemsForNode(node, problemReporter, level, drReporterContext)
            }
        }
    }
}

data class DrReporterContext(
    val graphRoot: DependencyNode,
    val cache: TypedKeyMap = TypedKeyMap()
)

internal fun Message.mapSeverityToLevel(): Level = when (severity) {
    Severity.ERROR -> Level.Error
    Severity.WARNING -> Level.Warning
    Severity.INFO -> Level.WeakWarning
}

internal fun Level.mapLevelToSeverity(): Severity = when (this) {
    Level.Error -> Severity.ERROR
    Level.Warning -> Severity.WARNING
    Level.WeakWarning -> Severity.INFO
}
