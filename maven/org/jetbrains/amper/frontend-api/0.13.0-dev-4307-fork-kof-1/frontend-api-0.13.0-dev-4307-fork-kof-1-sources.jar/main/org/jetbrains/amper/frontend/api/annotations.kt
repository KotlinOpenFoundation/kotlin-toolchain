/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.api

import org.jetbrains.amper.frontend.Platform
import org.jetbrains.amper.frontend.schema.ProductType
import org.jetbrains.amper.frontend.schema.SchemaMavenCoordinates
import org.jetbrains.amper.frontend.types.SchemaType
import org.jetbrains.amper.plugins.schema.model.InputOutputMark
import kotlin.reflect.KClass

/**
 * An annotation to specify documentation bundle entry.
 */
@Target(AnnotationTarget.PROPERTY, AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class SchemaDoc(
//    val bundleKey: String

    // TODO Replace by bundle key.
    val doc: String
)

/**
 * Special marker to highlight that this property can
 * have "@" modifier.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
// TODO Need to rename this one, since now it is solely YAML specific.
annotation class ModifierAware

/**
 *
 * Example:
 * ```kotlin
 * class MyDependency : SchemaNode() {
 *    @FromKeyAndTheRestIsNested
 *    val notation: String by value()
 *    val exported: Boolean by value(default=...)
 *    val scope: Scope by value(default=...)
 * }
 * ```
 * Then such object can be described in YAML like this:
 * ```yaml
 * my-dependency-1:
 *   "this-is-notation"          # MyDependency(notation="this-is-notation", exported=<default>, scope=<default>)
 * my-dependency-2:
 *   "this-is-also-notation":    # MyDependency(notation="this-is-also-notation", exported=true, scope=compile)
 *       exported: true
 *       scope: compile
 * ```
 * Note, that it's not possible to use such a property normally:
 * ```yaml
 * my-dependency:
 *   notation: foo  # error: not possible
 *   exported: true
 *   scope: runtime
 * ```
 * Only (Traceable)Strings/Paths are supported for now.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class FromKeyAndTheRestIsNested

/**
 * Works like [FromKeyAndTheRestIsNested], but this annotation is applied explicitly
 * for [SchemaMavenCoordinates] inheritors and [org.jetbrains.amper.frontend.plugins.generated.ShadowDependencyMaven].
 * 
 * The key difference is that referenced classes have several fields that are fileld from maven coordinates string;
 * thus there is no single field for which we can use [FromKeyAndTheRestIsNested].
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class ExternalDependencyNotation

/**
 * This annotation can be used to indicate that the order in which the enumeration constants
 * are declared is important.
 * This will be utilized in JSON schema by setting the meta property `x-intellij-enum-order-sensitive` to `true`.
 *
 * [reverse] parameter can be used to sort values in the reverse order.
 * This is useful for versions, which should be compared in the natural order but displayed in the reversed one.
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class EnumOrderSensitive(
    val reverse: Boolean = false,
)

/**
 * This annotation can be used to filter enum values that are propagated into the generated JSON schema
 *
 * [filterPropertyName] property name of the enum class that acts as a filter for values
 * [isNegated] if the filter is negated, e.g., when we want to filter out the obsolete values
 * This property must exist and must be boolean for the filtering to work.
 * 'True' means the value is accepted, and 'false' means that the value is not included in the JSON schema
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class EnumValueFilter(
    val filterPropertyName: String,
    val isNegated: Boolean = false
)

/**
 * This annotation can be used for properties to mark them as platform-specific
 * [platforms] The list of platforms, treated as an OR list
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class PlatformSpecific(
    vararg val platforms: Platform
)

/**
 * This annotation can be used for properties to mark them as product type-specific
 * [productTypes] The list of product types, treated as an OR list
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class ProductTypeSpecific(
    vararg val productTypes: ProductType
)

/**
 * This annotation can be used for properties to specify that they can only be used without any modifier.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class PlatformAgnostic

/**
 * This annotation should be applied to properties
 *  which represent shorthand values for their parent object construction
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class Shorthand

/**
 * If we don't want to limit a value by an enum, but we still want to provide code assistance for known values
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class KnownStringValues(vararg val values: String)

/**
 * If we don't want to limit a value by an enum, but we still want to provide code assistance for known values
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class KnownIntValues(vararg val values: Int)

/**
 * Other names that users might try when looking for this property.
 * These are not valid names for this property, and using them in config files is an error.
 * However, they can be used to help with completion in the IDE, or for more meaningful error messages.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class Misnomers(vararg val values: String)

/**
 * Properties annotated with this are ignored in [SchemaNode] in terms of schema generation.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class IgnoreForSchema

/**
 * Properties annotated with this are hidden from completion in IDE. Recursively.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class HiddenFromCompletion

/**
 * Specified Input/Output semantics for Path-referencing properties. Used by tasks from plugins.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class PathMark(val type: InputOutputMark)

/**
 * For [String]/[TraceableString] schema properties.
 *
 * @see SchemaType.StringType.Semantics
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class StringSemantics(val value: SchemaType.StringType.Semantics)

/**
 * For properties that can be directly referenced in referencing-enabled files
 * using the `${...}` syntax. Also needed for builtin references aka dependent values.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class CanBeReferenced

/**
 * For properties that are not user-settable.
 *
 * If an object/mapping property is marked as [ReadOnly], then all its child properties cannot be set as well.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class ReadOnly

/**
 * *Applicable for plugin contexts.*
 * Property is forced to have a fully resolved value, not depending on any external references.
 * Example (assuming `foo`, `baz`, `quu`, `quu` are "constinit"):
 * ```yaml
 * foo: bar   # okay - literal
 * baz: ${foo}  # okay - resolves to "bar"
 * quu: ${module.name} # error - references external parameter
 * quuu: # error - subtree references external parameter
 *   one: two
 *   three: ${project.rootDir}
 * ```
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class ConstInit

/**
 * If present on the [SchemaNode] inheritor, means that it has a custom, manually-provided
 * [org.jetbrains.amper.frontend.types.SchemaTypeDeclaration], and no auto-generated one will be present.
 */
@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.RUNTIME)
annotation class CustomSchemaDeclaration(
    vararg val requiredReferences: KClass<out SchemaNode>
)

/**
 * Marks the property as deprecated.
 * If it's used by the user (has non-default trace), then it's going to be diagnosed.
 */
@Target(AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.RUNTIME)
annotation class DeprecatedSchema(
    /**
     * Message bundle ID for the deprecation message to include in the diagnostic.
     * Must be from [org.jetbrains.amper.frontend.SchemaBundle].
     */
    val messageBundleId: String,
    val isError: Boolean = true,
)
