/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend

import org.jetbrains.amper.buildinfo.AmperBuild
import org.jetbrains.amper.frontend.api.EnumValueFilter
import org.jetbrains.amper.frontend.api.TraceableEnum

/**
 * Enum, that describes the concrete platform the sources are built for.
 *
 * [parent] — Parent of the platform in natural KMP hierarchy.
 * [isLeaf] — Helper flag to indicate that the platform is a leaf in the hierarchy.
 */
@EnumValueFilter("isLeaf")
enum class Platform(
    override val parent: Platform? = null,
    override val isLeaf: Boolean = false,
    override val outdated: Boolean = false,
    /**
     * Whether this platform represents an Apple simulator (as opposed to a physical device).
     * See https://kotlinlang.org/docs/native-target-support.html for more details about native targets.
     */
    val isAppleDevice: Boolean = false,
) : SchemaEnum, Context {
    COMMON,

    JVM(COMMON, isLeaf = true),
    ANDROID(COMMON, isLeaf = true),

    WEB(COMMON),
    JS(WEB, isLeaf = true),
    WASM_JS(WEB, isLeaf = true),

    WASM_WASI(COMMON, isLeaf = true),

    NATIVE(COMMON),

    LINUX(NATIVE),
    LINUX_X64(LINUX, isLeaf = true),
    LINUX_ARM64(LINUX, isLeaf = true),

    APPLE(NATIVE),

    MACOS(APPLE),
    MACOS_X64(MACOS, isLeaf = true, outdated = true), // deprecated in Kotlin 2.3.20, soon unsupported by Apple
    MACOS_ARM64(MACOS, isLeaf = true),

    TVOS(APPLE),
    TVOS_ARM64(TVOS, isLeaf = true, isAppleDevice = true),
    TVOS_X64(TVOS, isLeaf = true, outdated = true, isAppleDevice = false), // deprecated in Kotlin 2.3.20, soon unsupported by Apple
    TVOS_SIMULATOR_ARM64(TVOS, isLeaf = true, isAppleDevice = false),

    IOS(APPLE),
    IOS_ARM64(IOS, isLeaf = true, isAppleDevice = true),
    IOS_SIMULATOR_ARM64(IOS, isLeaf = true, isAppleDevice = false),
    IOS_X64(IOS, isLeaf = true, isAppleDevice = false),

    WATCHOS(APPLE),
    WATCHOS_ARM64(WATCHOS, isLeaf = true, isAppleDevice = true),
    WATCHOS_ARM32(WATCHOS, isLeaf = true, isAppleDevice = true, outdated = true), // Is planned to be removed in Kotlin 2.5.0, unsupported by Apple since Xcode 27 (KT-78078)
    WATCHOS_DEVICE_ARM64(WATCHOS, isLeaf = true, isAppleDevice = true),
    WATCHOS_SIMULATOR_ARM64(WATCHOS, isLeaf = true, isAppleDevice = false),

    MINGW(NATIVE),
    MINGW_X64(MINGW, isLeaf = true),

    ANDROID_NATIVE(NATIVE),
    ANDROID_NATIVE_ARM32(ANDROID_NATIVE, isLeaf = true),
    ANDROID_NATIVE_ARM64(ANDROID_NATIVE, isLeaf = true),
    ANDROID_NATIVE_X64(ANDROID_NATIVE, isLeaf = true),
    ANDROID_NATIVE_X86(ANDROID_NATIVE, isLeaf = true),
    ;

    // TODO Copy pasted. Check why NoSuchMethodError arises when using outer method.
    private val prettyRegex = "_.".toRegex()
    private fun String.doCamelCase() = this.lowercase().replace(prettyRegex) { it.value.removePrefix("_").uppercase() }
    override val pretty get() = name.doCamelCase()

    override val schemaValue: String = pretty

    /**
     * The name of this target platform as defined by the Kotlin compiler.
     *
     * * It should match the values of the `-target` argument of the Kotlin/Native compiler.
     * * It should match the names of the platforms in the .konan directory.
     */
    val nameForCompiler: String
        get() = when {
            isDescendantOf(ANDROID_NATIVE) -> name.replace("_NATIVE", "")
            else -> name
        }.lowercase()

    /**
     * Get leaf children of this parent if it is a parent; List of self otherwise.
     */
    override val leaves: Set<Platform> by lazy {
        if (isLeaf) setOf(this)
        else naturalHierarchy[this] ?: error("Platform $this is not a leaf platform and doesn't have a hierarchy")
    }

    val topmostParentNoCommon by lazy { generateSequence(this) { it.parentNoCommon }.last() }

    val pathToParent by lazy { generateSequence(this) { it.parent }.toSet() }

    val parentNoCommon by lazy { parent?.takeIf { it != COMMON } }

    companion object : EnumMap<Platform, String>(Platform::values, { pretty }) {

        const val docsUrl = "${AmperBuild.documentationUrl}/user-guide/multiplatform/#supported-platforms"

        val leafPlatforms: Set<Platform> = Platform.values.filterTo(mutableSetOf()) { it.isLeaf }

        /**
         * Parent-child relations throughout parent hierarchy for every leaf child.
         * For example, **`MACOS/[ MACOS_X64, ... ]`** and **`APPLE/[ MACOS_X64, ... ]`** are both present.
         *
         * Leaf platforms are **not present** (for example, **`IOS_ARM64/[ IOS_ARM64 ]`** is not in the map).
         *
         * Hierarchy **doest not include** COMMON platform.
         */
        val naturalHierarchy: Map<Platform, Set<Platform>> = buildMap<Platform, MutableSet<Platform>> {
            // Add parent-child relation for every parent in hierarchy.
            fun add(parent: Platform?, child: Platform): Unit = if (parent != null && parent != COMMON) {
                this[parent] = (this[parent] ?: mutableSetOf()).apply { add(child) }
                add(parent.parent, child)
            } else Unit
            leafPlatforms.forEach { add(it.parent, it) }
        }

        /**
         * [naturalHierarchy] with [COMMON] and leaves included.
         */
        val naturalHierarchyExt = naturalHierarchy + (COMMON to leafPlatforms) + leafPlatforms.associateWith { setOf(it) }
    }
}

@get:JvmName("getLeavesTraceable")
val Iterable<TraceableEnum<Platform>>.leaves get() = flatMap { it.value.leaves }.toSet()
val Iterable<Platform>.leaves get() = flatMap { it.leaves }.toSet()
val Array<out Platform>.leaves get() = flatMap { it.leaves }.toSet()

fun Platform.isDescendantOf(other: Platform): Boolean =
    this == other || parent?.isDescendantOf(other) == true

fun Platform.isParentOf(other: Platform) = other.isDescendantOf(this)
fun Platform.isParentOfStrict(other: Platform) = this != other && other.isDescendantOf(this)