/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.plugins

import org.jetbrains.amper.frontend.api.DeprecatedSchema
import org.jetbrains.amper.frontend.api.SchemaNode
import org.jetbrains.amper.frontend.api.StringSemantics
import org.jetbrains.amper.frontend.schema.ModuleProduct
import org.jetbrains.amper.frontend.types.SchemaType
import org.jetbrains.amper.plugins.schema.model.PluginData

/**
 * Needed by the `preparePlugins` stage to read the plugin information from the local plugin module, before the full
 * schema for `module.yaml` is available. This is required because the full schema depends on the plugins schema.
 */
class MinimalPluginModule : SchemaNode() {
    val product by value<ModuleProduct>()

    val description by nullableValue<String>()

    val pluginInfo: MinimalPluginDeclarationSchema by nested()
}

class MinimalPluginDeclarationSchema : SchemaNode() {
    val id by nullableValue<PluginData.Id>()
    @DeprecatedSchema("plugin.description.should.be.top.level", isError = false)
    @Deprecated("Use the description from the plugin's module instead")
    val description by nullableValue<String>()
    @StringSemantics(SchemaType.StringType.Semantics.PluginSettingsClass)
    val settingsClass by nullableValue<String>()
}