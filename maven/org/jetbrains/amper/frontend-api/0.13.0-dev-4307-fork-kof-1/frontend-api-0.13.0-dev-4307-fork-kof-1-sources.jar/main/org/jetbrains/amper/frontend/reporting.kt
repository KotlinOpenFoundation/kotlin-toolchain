/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend

import com.intellij.openapi.application.runReadActionBlocking
import com.intellij.openapi.editor.Document
import com.intellij.psi.PsiElement
import org.jetbrains.amper.frontend.api.PsiTrace
import org.jetbrains.amper.frontend.api.SchemaValueDelegate
import org.jetbrains.amper.frontend.api.Trace
import org.jetbrains.amper.frontend.api.Traceable
import org.jetbrains.amper.frontend.messages.PsiBuildProblemSource
import org.jetbrains.amper.frontend.messages.extractPsiElementOrNull
import org.jetbrains.amper.problems.reporting.BuildProblemImpl
import org.jetbrains.amper.problems.reporting.BuildProblemSource
import org.jetbrains.amper.problems.reporting.BuildProblemType
import org.jetbrains.amper.problems.reporting.DiagnosticId
import org.jetbrains.amper.problems.reporting.GlobalBuildProblemSource
import org.jetbrains.amper.problems.reporting.Level
import org.jetbrains.amper.problems.reporting.LineAndColumn
import org.jetbrains.amper.problems.reporting.LineAndColumnRange
import org.jetbrains.amper.problems.reporting.MessageBundle
import org.jetbrains.amper.problems.reporting.NonIdealDiagnostic
import org.jetbrains.amper.problems.reporting.ProblemReporter

object SchemaBundle : MessageBundle("messages.SchemaBundle")

fun ProblemReporter.reportBundleError(
    source: BuildProblemSource,
    diagnosticId: DiagnosticId,
    messageKey: String,
    vararg arguments: Any?,
    bundle: MessageBundle = SchemaBundle,
    level: Level = Level.Error,
    problemType: BuildProblemType = BuildProblemType.Generic,
) {
    reportMessage(
        BuildProblemImpl(
            diagnosticId = diagnosticId,
            source = source,
            message = bundle.message(messageKey, *arguments),
            level = level,
            type = problemType,
        )
    )
}

@JvmName("reportBundleErrorWithContext")
context(reporter: ProblemReporter)
fun reportBundleError(
    source: BuildProblemSource,
    diagnosticId: DiagnosticId,
    messageKey: String,
    vararg arguments: Any?,
    bundle: MessageBundle = SchemaBundle,
    level: Level = Level.Error,
    problemType: BuildProblemType = BuildProblemType.Generic,
) {
    reporter.reportBundleError(
        source = source,
        diagnosticId = diagnosticId,
        messageKey = messageKey,
        arguments = arguments,
        bundle = bundle,
        level = level,
        problemType = problemType,
    )
}

fun Traceable.asBuildProblemSource(): BuildProblemSource = trace.asBuildProblemSource()

fun SchemaValueDelegate<*>.keyValueAsBuildProblemSource(): BuildProblemSource = keyValueTrace.asBuildProblemSource()

@OptIn(NonIdealDiagnostic::class)
fun Trace.asBuildProblemSource(): BuildProblemSource {
    if (this is PsiTrace && rangeInElement != null) {
        return PsiBuildProblemSource(psiElement, rangeInElement)
    }
    return extractPsiElementOrNull()?.asBuildProblemSource()
        ?: GlobalBuildProblemSource
}

fun PsiElement.asBuildProblemSource(): PsiBuildProblemSource = PsiBuildProblemSource(this)

fun getLineAndColumnRangeInPsiFile(node: PsiElement): LineAndColumnRange {
    val document: Document = runReadActionBlocking {
        node.containingFile.viewProvider.document
    }

    val textRange = node.textRange
    return LineAndColumnRange(
        offsetToLineAndColumn(document, textRange.startOffset),
        offsetToLineAndColumn(document, textRange.endOffset),
    )
}

fun getLineAndColumnRangeInDocument(document: Document?, range: IntRange): LineAndColumnRange {
    return LineAndColumnRange(
        offsetToLineAndColumn(document, range.first),
        offsetToLineAndColumn(document, range.last),
    )
}

private fun offsetToLineAndColumn(
    document: Document?,
    offset: Int
): LineAndColumn {
    if (document == null || document.textLength == 0) {
        return LineAndColumn(-1, offset)
    }

    val lineNumber = document.getLineNumber(offset)
    val lineStartOffset = document.getLineStartOffset(lineNumber)
    val column = offset - lineStartOffset

    return LineAndColumn(
        lineNumber + 1,
        column + 1,
    )
}
