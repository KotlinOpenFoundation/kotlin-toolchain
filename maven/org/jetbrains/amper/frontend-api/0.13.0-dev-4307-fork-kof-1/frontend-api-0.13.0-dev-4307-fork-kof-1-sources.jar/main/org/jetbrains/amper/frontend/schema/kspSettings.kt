/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.schema

import org.jetbrains.amper.frontend.api.Misnomers
import org.jetbrains.amper.frontend.api.PlatformAgnostic
import org.jetbrains.amper.frontend.api.SchemaDoc
import org.jetbrains.amper.frontend.api.SchemaNode
import org.jetbrains.amper.frontend.api.TraceableString

class KspSettings : SchemaNode() {

    @PlatformAgnostic
    @SchemaDoc("The version of KSP to use")
    val version by value(DefaultVersions.ksp)

    @SchemaDoc("The list of KSP processors to use. Each item can be a path to a local module, a catalog reference, or maven coordinates.")
    val processors by value<List<UnscopedDependency>>(default = emptyList())

    @Misnomers("processorSettings")
    @SchemaDoc("Some options to pass to KSP processors. Refer to each processor documentation for details.")
    val processorOptions by value<Map<TraceableString, TraceableString>>(default = emptyMap())
}

/**
 * Whether KSP should be run.
 */
val KspSettings.enabled: Boolean
    get() = processors.isNotEmpty()
