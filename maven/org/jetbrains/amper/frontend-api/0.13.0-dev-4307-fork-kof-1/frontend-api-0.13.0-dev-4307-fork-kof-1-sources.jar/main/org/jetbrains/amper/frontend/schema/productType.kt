/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.schema

import org.jetbrains.amper.frontend.EnumMap
import org.jetbrains.amper.frontend.Platform
import org.jetbrains.amper.frontend.SchemaEnum
import org.jetbrains.amper.frontend.api.CanBeReferenced
import org.jetbrains.amper.frontend.api.DefaultTrace
import org.jetbrains.amper.frontend.api.EnumOrderSensitive
import org.jetbrains.amper.frontend.api.EnumValueFilter
import org.jetbrains.amper.frontend.api.Misnomers
import org.jetbrains.amper.frontend.api.SchemaDoc
import org.jetbrains.amper.frontend.api.SchemaNode
import org.jetbrains.amper.frontend.api.Shorthand
import org.jetbrains.amper.frontend.api.TraceableEnum
import org.jetbrains.amper.frontend.api.asTraceable
import org.jetbrains.amper.frontend.tree.EnumNode
import org.jetbrains.amper.frontend.tree.ReferenceNode
import org.jetbrains.amper.frontend.tree.RefinedTreeNode
import org.jetbrains.amper.frontend.tree.enumConstantIfAvailable
import org.jetbrains.amper.frontend.userGuideUrl

@SchemaDoc("Defines what should be produced out of the module. Read more about the [product types]($userGuideUrl/product-types)")
@EnumValueFilter("outdated", isNegated = true)
@EnumOrderSensitive
enum class ProductType(
    val value: String,
    val supportedPlatforms: Set<Platform>,
    val defaultPlatforms: Set<Platform>?,
    val supportsFragmentBamboos: Boolean = true,
    override val outdated: Boolean = false,
): SchemaEnum {

    @Deprecated(
        message = "Renamed to KMP_LIB (kmp/lib)",
        replaceWith = ReplaceWith(
            expression = "ProductType.KMP_LIB",
            imports = ["org.jetbrains.amper.frontend.schema.ProductType"],
        )
    )
    @SchemaDoc("A reusable multiplatform library which could be used as dependency by other modules in the codebase")
    LIB(
        "lib",
        supportedPlatforms = Platform.leafPlatforms,
        defaultPlatforms = null,
    ),

    @SchemaDoc("A JVM application (console, desktop, server...)")
    JVM_APP(
        "jvm/app",
        supportedPlatforms = setOf(Platform.JVM),
        defaultPlatforms = setOf(Platform.JVM),
        supportsFragmentBamboos = false,
    ),

    @SchemaDoc("A reusable JVM library, which can be used as dependency by other modules in the codebase (in their JVM sources)")
    JVM_LIB(
        "jvm/lib",
        supportedPlatforms = setOf(Platform.JVM),
        defaultPlatforms = setOf(Platform.JVM),
        supportsFragmentBamboos = false,
    ),

    @SchemaDoc("A reusable Kotlin multiplatform library, which can be used as dependency by other modules in the codebase")
    KMP_LIB(
        "kmp/lib",
        supportedPlatforms = Platform.leafPlatforms,
        defaultPlatforms = null,
    ),

    @SchemaDoc("A Kotlin Toolchain plugin")
    JVM_AMPER_PLUGIN(
        "jvm/amper-plugin",
        supportedPlatforms = setOf(Platform.JVM),
        defaultPlatforms = setOf(Platform.JVM),
        supportsFragmentBamboos = false,
    ),

    @SchemaDoc("An Android application")
    ANDROID_APP(
        "android/app",
        supportedPlatforms = setOf(Platform.ANDROID),
        defaultPlatforms = setOf(Platform.ANDROID),
        supportsFragmentBamboos = false,
    ),

    @SchemaDoc("An iOS application")
    IOS_APP(
        "ios/app",
        supportedPlatforms = setOf(Platform.IOS_ARM64, Platform.IOS_SIMULATOR_ARM64),
        defaultPlatforms = setOf(Platform.IOS_ARM64, Platform.IOS_SIMULATOR_ARM64)
    ),

    @SchemaDoc("A native macOS application")
    MACOS_APP(
        "macos/app",
        supportedPlatforms = setOf(Platform.MACOS_X64, Platform.MACOS_ARM64),
        defaultPlatforms = setOf(Platform.MACOS_ARM64)
    ),

    @SchemaDoc("A native linux application")
    LINUX_APP(
        "linux/app",
        supportedPlatforms = setOf(Platform.LINUX_X64, Platform.LINUX_ARM64),
        defaultPlatforms = setOf(Platform.LINUX_X64, Platform.LINUX_ARM64)
    ),

    @SchemaDoc("A native Windows application")
    WINDOWS_APP(
        "windows/app",
        supportedPlatforms = setOf(Platform.MINGW_X64),
        defaultPlatforms = setOf(Platform.MINGW_X64),
    ),

    @SchemaDoc("A WebAssembly application with browser APIs")
    WASM_JS_APP(
        "wasm-js/app",
        supportedPlatforms = setOf(Platform.WASM_JS),
        defaultPlatforms = setOf(Platform.WASM_JS)
    ),

    @SchemaDoc("A WebAssembly application with WASI APIs")
    WASM_WASI_APP(
        "wasm-wasi/app",
        supportedPlatforms = setOf(Platform.WASM_WASI),
        defaultPlatforms = setOf(Platform.WASM_WASI)
    ),

    @SchemaDoc("A JavaScript application")
    JS_APP(
        "js/app",
        supportedPlatforms = setOf(Platform.JS),
        defaultPlatforms = setOf(Platform.JS),
    ),;

    fun isLibrary() = this == KMP_LIB || this == JVM_AMPER_PLUGIN || this == JVM_LIB
    fun isApplication() = !isLibrary()
    override fun toString() = value
    override val schemaValue: String = value

    companion object : EnumMap<ProductType, String>(ProductType::values, ProductType::value)
}

@SchemaDoc("Defines what should be produced out of the module. [Read more]($userGuideUrl/product-types)")
class ModuleProduct : SchemaNode() {

    @CanBeReferenced
    @Misnomers("application", "library")
    @Shorthand
    @SchemaDoc("What type of product to generate")
    val type by value<ProductType>()

    @SchemaDoc("What platforms to generate the product for")
    val platforms: List<TraceableEnum<Platform>> by referenceValue(::type, "default platform for this product type",
        PlatformTransform())

    class PlatformTransform : ReferenceNode.TransformFunction<List<TraceableEnum<Platform>>> {
        override fun transform(node: RefinedTreeNode): List<TraceableEnum<Platform>> {
            if (node !is EnumNode) {  // Can be ErrorNode
                return emptyList()
            }
            val productType = node.enumConstantIfAvailable as ProductType
            return productType.defaultPlatforms
                ?.map { platform ->
                    platform.asTraceable(DefaultTrace)
                }
            // Degenerate case when there are no default platforms but also platforms are not declared by the user.
            // It is reported as an error via diagnostics, so it will never reach AOM consumers, and thus it's better
            // to keep this type non-nullable.
            // Note that this empty list can still be obtained when running other diagnostics. This is actually
            // desirable because it correctly represents the fact that we have no platforms at all (thus aliases or
            // @Platform-specific property usages will be properly reported).
                ?: emptyList()
        }
    }
}
