/*
 * Copyright 2000-2025 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.tree

import org.jetbrains.amper.frontend.api.Trace
import org.jetbrains.amper.frontend.api.Traceable
import org.jetbrains.amper.frontend.contexts.WithContexts

/**
 * The tree node sealed interface.
 *
 * The [mapping nodes][MappingNode] of the tree may contain [key-value][KeyValue] pairs
 * with the same key but different contexts.
 *
 * To get a tree for specific contexts, the tree must be "refined".
 * The resulting tree consists of [RefinedTreeNode]s.
 *
 * As [RefinedTreeNode] extends the [TreeNode], the unrefined trees *may* physically contain refined nodes;
 * This may lead to refined mappings being copied as unrefined ones,
 * but that is usually what is already expected when working with the base tree node interface.
 */
sealed interface TreeNode : WithContexts, Traceable

/**
 * The refined tree node sealed interface.
 *
 * The [mapping nodes][RefinedMappingNode] of the tree contain [key-value][RefinedKeyValue] pairs with unique keys.
 */
sealed interface RefinedTreeNode : TreeNode

/**
 * The complete tree node sealed interface.
 *
 * A *complete* tree is free of inconsistencies or errors and has all references resolved.
 * Thus, the hierarchy doesn't include [ErrorNode], [ReferenceNode] and [StringInterpolationNode].
 *
 * The type-safe wrapper [org.jetbrains.amper.frontend.api.SchemaNode] can be obtained
 * from a complete object node using [instance] helper function.
 */
sealed interface CompleteTreeNode : RefinedTreeNode

/**
 * A leaf tree value that cannot have any children.
 * As such, it can be used both in refined and non-refined trees.
 */
sealed interface LeafTreeNode : TreeNode, RefinedTreeNode

fun TreeNode.copyWithTrace(
    trace: Trace,
): TreeNode = when (this) {
    is RefinedTreeNode -> copyWithTrace(trace = trace)
    is ListNode -> copy(trace = trace)
    is MappingNode -> copy(trace = trace)
}

fun RefinedTreeNode.copyWithTrace(
    trace: Trace,
): RefinedTreeNode = when (this) {
    is RefinedListNode -> copy(trace = trace)
    is RefinedMappingNode -> copy(trace = trace)
    is LeafTreeNode -> copyWithTrace(trace = trace)
}

fun LeafTreeNode.copyWithTrace(
    trace: Trace,
): LeafTreeNode = when (this) {
    is ErrorNode -> ErrorNode(expectedType, trace, contexts)
    is ReferenceNode -> ReferenceNode(referencedPath, expectedType, transform, trace, contexts)
    is StringInterpolationNode -> StringInterpolationNode(parts, expectedType, trace, contexts)
    is NullLiteralNode -> NullLiteralNode(trace, contexts)
    is BooleanNode -> BooleanNode(value, trace, contexts)
    is EnumNode -> EnumNode(entryName, declaration, trace, contexts)
    is IntNode -> IntNode(value, trace, contexts)
    is PathNode -> PathNode(value, trace, contexts)
    is StringNode -> StringNode(value, semantics, trace, contexts)
}
