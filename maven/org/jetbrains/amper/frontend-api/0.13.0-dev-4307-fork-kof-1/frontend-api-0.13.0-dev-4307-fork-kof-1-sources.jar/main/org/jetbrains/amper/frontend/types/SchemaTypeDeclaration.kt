/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.types

interface SchemaTypeDeclaration {
    /**
     * Fully qualified name, using dots as separators.
     */
    val qualifiedName: String

    /**
     * User-readable public name that can be included in messages.
     */
    val displayName: String
        get() = qualifiedName.substringAfterLast('.')

    /**
     * Reflection name of the public API interface, if applicable.
     * `null` for builtin declarations.
     */
    val publicInterfaceReflectionName: String?
        get() = null

    /**
     * Where the declaration comes from.
     */
    val origin: SchemaOrigin
        get() = SchemaOrigin.Builtin

    /**
     * Creates a type with this declaration.
     */
    fun toType(isMarkedNullable: Boolean = false): SchemaType
}