/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend

import org.jetbrains.amper.core.UsedInIdePlugin
import org.jetbrains.amper.frontend.schema.Settings
import java.nio.file.Path
import java.util.*
import kotlin.io.path.PathWalkOption
import kotlin.io.path.isDirectory
import kotlin.io.path.name
import kotlin.io.path.readText
import kotlin.io.path.walk

/**
 * A part of a module containing its own sources, resources, dependencies, and even toolchain settings.
 *
 * It must respect the *single resolution context* invariant: every source file can be analyzed with a specific set of
 * dependencies that doesn't depend on, say, which platform we're compiling against.
 */
interface Fragment {
    /**
     * The name of this fragment.
     */
    val name: String

    /**
     * The modifier that can be used in the build file or in the source directories names to refer to this fragment.
     *
     * Example: `@mingwX64` is the modifier used in the source directory name `src@mingwX64` for the Windows fragment.
     */
    val modifier: String

    /**
     * The module this fragment belongs to.
     */
    val module: AmperModule

    /**
     * Fragments (within the same module) that this fragment depends on.
     */
    val fragmentDependencies: List<FragmentLink>

    /**
     * Fragments (within the same module) that depend on this fragment.
     */
    val fragmentDependants: List<FragmentLink>

    /**
     * Dependencies of this fragment. They can be Maven modules or other source modules in the project.
     */
    val externalDependencies: List<Notation>

    /**
     * The settings of this fragment, including inherited settings from parent fragments.
     * For instance, the settings of the iosArm64 fragment contain merged settings from iosArm64, ios, native, and common.
     */
    val settings: Settings

    /**
     * Leaf platforms that this fragment is compiled to.
     */
    val platforms: Set<Platform>

    /**
     * Whether this fragment contains test-only sources.
     */
    val isTest: Boolean

    /**
     * Sources directories.
     */
    val sourceRoots: List<Path>

    /**
     * Resources directories.
     */
    val resourcesPath: Path

    /**
     * Cinterop definition files directory.
     * `null` if not supported by this fragment.
     */
    val cinteropPath: Path?

    /**
     * Path to compose resources' directory.
     */
    val composeResourcesPath: Path

    /**
     * Paths to the source directories specific for Android.
     */
    @UsedInIdePlugin
    val sourceAndroidConventionPaths: SourceAndroidConventionPaths?

    /**
     * Paths to the generated source roots that will be used to build the fragment.
     */
    @UsedInIdePlugin
    fun generatedSourceDirs(buildOutputRoot: Path): List<Path>

    /**
     * Paths to the generated resource roots that will be used to build the fragment.
     */
    @UsedInIdePlugin
    fun generatedResourceDirs(buildOutputRoot: Path): List<Path>

    /**
     * Paths to the generated classes roots that will be used to build the fragment.
     */
    @UsedInIdePlugin
    fun generatedClassDirs(buildOutputRoot: Path): List<Path>

    /**
     * Path to converted Compose resources that can be used on the runtime to access the resources.
     */
    @UsedInIdePlugin
    fun preparedComposeResourcesConventionPath(buildOutputRoot: Path): Path

    /**
     * A path to the directory where all the cinterop generated/commonized klibs are for this fragment.
     *
     * - If this is a fragment with a *single platform*,
     *   there are `.klib` archives in the directory for all the `.def` files of the *refined closure* of this fragment.
     * - If this is a multi-platform fragment, then `null` is returned here.
     *
     * Always returns `null` for the fragments that do not support `cinterop` ([cinteropPath] is `null`).
     *
     * NOTE: For commonized cinterop libraries use [AmperModule.commonizedCinteropLibrariesRoot].
     */
    @UsedInIdePlugin
    fun generatedCinteropKlibsDirPath(buildOutputRoot: Path): Path?

    /**
     * Concrete paths of the klibs/exploded klibs generated from the cinterop files.
     * These libraries are needed in the IDE to enable correct code-insight for the native definitions.
     *
     * The contents of these paths are populated during the build or using the `ide-integration` command.
     * Some paths may not exist if the generation failed for that platform.
     *
     * All the paths are children of [generatedCinteropKlibsDirPath] of *some* fragment in the same [module].
     */
    @UsedInIdePlugin
    @Deprecated(
        "This function no longer correctly predicts the build output. " +
                "Use `generatedCinteropKlibsDirPath` or `AmperModule.commonizedCinteropLibrariesRoot` instead " +
                "and enumerate file entries within after the build.",
    )
    fun generatedCinteropKlibPaths(buildOutputRoot: Path): List<Path>
}

/**
 * A dependency between fragments.
 */
interface FragmentLink {
    val target: Fragment
    val type: FragmentDependencyType
}

/**
 * A type that describes the relation between a fragment and the fragment it depends on.
 */
enum class FragmentDependencyType {
    /**
     * When fragment A depends on B with a "refines" relationship, it means A can define `actual` declarations for the
     * `expect` declarations of B.
     */
    REFINE,
    /**
     * When fragment A depends on B with a "friends" relationship, it means A can see `internal` declarations from B.
     * Note: this relation is not symmetric.
     */
    FRIEND,
}

/**
 * A [Fragment] that has exactly one target platform.
 *
 * There is a one-to-one mapping between leaf fragments and platform-specific artifacts.
 */
interface LeafFragment : Fragment {
    /**
     * The single platform that this fragment is compiled to.
     */
    val platform: Platform
}

/**
 * Fragments (within the same module) that this fragment depends on with the FRIEND relationship.
 * Internal declarations from these fragments will be visible despite the independent compilation.
 */
val Fragment.friends: List<Fragment>
    get() = fragmentDependencies.filter { it.type == FragmentDependencyType.FRIEND }.map { it.target }

/**
 * Fragments (within the same module) that this fragment depends on with the REFINE relationship.
 * Expect declarations from these fragments will be visible despite a possible independent compilation (for instance,
 * this is useful for metadata compilation).
 */
val Fragment.refinedFragments: List<Fragment>
    get() = fragmentDependencies.filter { it.type == FragmentDependencyType.REFINE }.map { it.target }

/**
 * Returns the path to the single source root directory of this [Fragment], or fails if there is more than one.
 *
 * The given [reason] should explain why it is expected for this fragment to have only one source root
 * (typically, this function should only be used with fragments that are not allowed to use the maven-like layout).
 */
fun Fragment.singleSourceRoot(reason: String): Path =
    sourceRoots.singleOrNull() ?: error("Expected a single source root in fragment '$name' ($reason). Got:\n${sourceRoots.joinToString("\n")}")

/**
 * Returns all fragments that this fragment depends on transitively, in DFS order.
 */
fun Fragment.allFragmentDependencies(includeSelf: Boolean = false, dependencyType: FragmentDependencyType? = null): Sequence<Fragment> =
    sequence {
        if (includeSelf) {
            yield(this@allFragmentDependencies)
        }
        val traversed = hashSetOf<FragmentLink>()
        val stack = ArrayList(fragmentDependencies)
        while (stack.isNotEmpty<FragmentLink>()) {
            val link = stack.removeLast()
            if ((dependencyType == null || dependencyType == link.type) && traversed.add(link)) {
                yield(link.target)
                stack.addAll(link.target.fragmentDependencies)
            }
        }
    }

/**
 * Returns the path from this [Fragment] to its farthest ancestor (more general parents).
 * Closer parents appear first, even when they're on different paths (BFS order).
 *
 * Example:
 * ```
 *      common
 *      /    \
 *  desktop  apple
 *      \    /
 *    macosArm64
 * ```
 * In this situation calling [ancestralPath] on `macosArm64` yields `[macosArm64, desktop, apple, common]`.
 * The order between `desktop` and `apple` is unspecified.
 */
fun Fragment.ancestralPath(): Sequence<Fragment> = sequence {
    val seenAncestorNames = mutableSetOf<String>()

    val queue = ArrayDeque<Fragment>()
    queue.add(this@ancestralPath)
    while (queue.isNotEmpty()) {
        val fragment = queue.removeFirst()
        yield(fragment)
        fragment.fragmentDependencies.forEach { link ->
            val parent = link.target
            if (parent.name !in seenAncestorNames) {
                queue.add(parent)
                seenAncestorNames.add(parent.name)
            }
        }
    }
}

/**
 * Finds the fully qualified name of the JVM main class for these fragments.
 *
 * This function first looks for an explicit main class in the user settings.
 * If not found, the sources are inspected to find the main class based on the Amper naming convention.
 * If not found either, this function returns null.
 */
@UsedInIdePlugin
fun List<Fragment>.findEffectiveJvmMainClass(): String? {
    // TODO replace with unanimous setting getter
    val explicitMainClass = firstNotNullOfOrNull { it.settings.jvm.mainClass }
    if (explicitMainClass != null) {
        return explicitMainClass
    }

    // TODO what if several fragments have main.kt?
    return firstNotNullOfOrNull { it.findConventionalEntryPoint() }
}

/**
 * Finds the fist source file named `main.kt` (ignoring case), if any, and returns the corresponding fqn.
 * This is the convention defined in Amper documentation.
 */
private fun Fragment.findConventionalEntryPoint(): String? {
    for (sourceRoot in sourceRoots) {
        if (!sourceRoot.isDirectory()) {
            continue
        }

        val firstMainKtFile = sourceRoot.walk(PathWalkOption.BREADTH_FIRST)
            .firstOrNull { it.name.equals("main.kt", ignoreCase = true) }

        if (firstMainKtFile == null) {
            continue
        }

        val pkg = firstMainKtFile.readPackageName()
        val prefix = if (pkg != null) "${pkg}." else ""

        return "${prefix}MainKt"
    }
    return null
}

private val packageRegex = "^package\\s+([\\w.]+)".toRegex(RegexOption.MULTILINE)

private fun Path.readPackageName(): String? = packageRegex.find(readText())?.groupValues?.get(1)?.trim()
