/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.plugins

import org.jetbrains.amper.frontend.TaskId
import org.jetbrains.amper.plugins.schema.model.PluginData

/**
 * A custom checker contributed by a plugin.
 * It defines a check that can be invoked via the `amper check` command.
 */
class CheckFromPlugin(
    /**
     * The name of this check as it appears in the CLI.
     */
    val name: String,

    /**
     * The id of the task that performs this check.
     */
    val performedBy: TaskId,

    /**
     * Plugin ID that this checker belongs to.
     */
    val pluginId: PluginData.Id,
)
