/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.plugins

import org.jetbrains.amper.frontend.api.DeprecatedSchema
import org.jetbrains.amper.frontend.api.NotBlank
import org.jetbrains.amper.frontend.api.SchemaDoc
import org.jetbrains.amper.frontend.api.SchemaNode
import org.jetbrains.amper.frontend.api.StringSemantics
import org.jetbrains.amper.frontend.types.SchemaType.StringType.Semantics
import org.jetbrains.amper.plugins.schema.model.PluginData

/**
 * This schema is used in `module.yaml` files with project type `jvm/amper-plugin`.
 */
@SchemaDoc("Current plugin manifest information")
class PluginDeclarationSchema : SchemaNode() {
    @SchemaDoc("Plugin id that is going to be used to refer to the plugin in the configuration files. " +
            "Module name is used by default.")
    @NotBlank
    val id by value<PluginData.Id>() // Defaults to the module name, is set on the tree level later.

    @DeprecatedSchema("plugin.description.should.be.top.level", isError = false)
    @Deprecated("Use the plugin module's description instead.")
    @SchemaDoc("Plugin description. " +
            "Can be used by tooling to provide documentation on plugin references in configuration files. " +
            "DEPRECATED: superseded by the description of the module (at the top level of module.yaml). " +
            "This `pluginInfo.description` field will be removed in a future version."
    )
    val description by nullableValue<String>()

    @SchemaDoc("Fully qualified name of the @Configurable-annotated interface to be used as plugin configuration. " +
            "This interface can't come from a dependency, it must be declared in the source directory.")
    @StringSemantics(Semantics.PluginSettingsClass)
    @NotBlank
    val settingsClass by nullableValue<String>()
}
