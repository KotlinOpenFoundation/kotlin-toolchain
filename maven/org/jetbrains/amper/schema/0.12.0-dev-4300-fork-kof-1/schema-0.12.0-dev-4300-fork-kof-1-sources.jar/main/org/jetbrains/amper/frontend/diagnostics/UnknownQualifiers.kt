/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.diagnostics

import org.jetbrains.amper.frontend.Platform
import org.jetbrains.amper.frontend.asBuildProblemSource
import org.jetbrains.amper.frontend.contexts.MinimalModule
import org.jetbrains.amper.frontend.contexts.PlatformCtx
import org.jetbrains.amper.frontend.diagnostics.helpers.extractKeyElement
import org.jetbrains.amper.frontend.messages.extractPsiElementOrNull
import org.jetbrains.amper.frontend.reportBundleError
import org.jetbrains.amper.frontend.tree.TreeNode
import org.jetbrains.amper.frontend.tree.visitNodes
import org.jetbrains.amper.problems.reporting.BuildProblemType
import org.jetbrains.amper.problems.reporting.ProblemReporter

object UnknownQualifiers : TreeDiagnosticFactory {

    private val knownPlatforms = Platform.values.map { it.schemaValue }

    override fun analyze(root: TreeNode, minimalModule: MinimalModule, problemReporter: ProblemReporter) {
        val knownAliases = minimalModule.aliases?.keys.orEmpty()
        val knownModifiers = knownAliases + knownPlatforms
        root.visitNodes { value ->
            value.contexts
                .filterIsInstance<PlatformCtx>().filter { it.trace != null }
                .filter { it.value !in knownModifiers }
                .forEach {
                    problemReporter.reportBundleError(
                        source = it.trace?.extractPsiElementOrNull()?.extractKeyElement()?.asBuildProblemSource()
                            ?: return@forEach, // Skip for unknown places.
                        diagnosticId = FrontendDiagnosticId.UnknownQualifiers,
                        messageKey = "product.unknown.qualifier",
                        it.value,
                        problemType = BuildProblemType.UnknownSymbol,
                    )
                }
        }
    }
}
