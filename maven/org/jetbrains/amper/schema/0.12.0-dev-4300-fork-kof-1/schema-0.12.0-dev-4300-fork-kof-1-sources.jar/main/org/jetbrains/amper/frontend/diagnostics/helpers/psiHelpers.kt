/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.diagnostics.helpers

import com.intellij.psi.PsiElement
import org.jetbrains.yaml.psi.YAMLKeyValue

/**
 * Get the corresponding key PsiElement if the current node is a key value pair. Return `this` otherwise.
 */
internal fun PsiElement.extractKeyElement(): PsiElement = when (this) {
    is YAMLKeyValue -> key ?: this
    else -> this
}