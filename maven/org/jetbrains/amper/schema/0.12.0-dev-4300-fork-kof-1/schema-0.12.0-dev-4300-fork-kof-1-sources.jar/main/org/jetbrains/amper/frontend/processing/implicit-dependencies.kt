/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.processing

import org.jetbrains.amper.buildinfo.AmperBuild
import org.jetbrains.amper.frontend.BomDependency
import org.jetbrains.amper.frontend.Fragment
import org.jetbrains.amper.frontend.MavenCoordinates
import org.jetbrains.amper.frontend.MavenDependency
import org.jetbrains.amper.frontend.MavenDependencyBase
import org.jetbrains.amper.frontend.Platform
import org.jetbrains.amper.frontend.ResolutionRepository
import org.jetbrains.amper.frontend.ancestralPath
import org.jetbrains.amper.frontend.aomBuilder.DefaultFragment
import org.jetbrains.amper.frontend.aomBuilder.DefaultModule
import org.jetbrains.amper.frontend.api.DefaultTrace
import org.jetbrains.amper.frontend.api.Trace
import org.jetbrains.amper.frontend.api.TraceableString
import org.jetbrains.amper.frontend.api.TransformedValueTrace
import org.jetbrains.amper.frontend.api.asTraceableValue
import org.jetbrains.amper.frontend.api.isExplicitlySet
import org.jetbrains.amper.frontend.schema.JUnitVersion
import org.jetbrains.amper.frontend.schema.ProductType
import org.jetbrains.amper.frontend.schema.Repository.Companion.SpecialMavenLocalUrl
import org.jetbrains.amper.frontend.schema.kotlin.plugins.legacySerializationFormatNone
import org.jetbrains.amper.frontend.types.generated.*

private fun kotlinDependencyOf(artifactId: String, version: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.kotlin", artifactId, version),
    trace = dependencyTrace,
)

private fun lombokDependency(version: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.projectlombok", "lombok", version),
    trace = dependencyTrace,
)

private fun kotlinxSerializationCoreDependency(version: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.kotlinx", "kotlinx-serialization-core", version),
    trace = dependencyTrace,
)

private fun kotlinxSerializationFormatDependency(format: String, version: TraceableString, dependencyTrace: Trace) =
    MavenDependency(
        coordinates = coords("org.jetbrains.kotlinx", "kotlinx-serialization-$format", version),
        trace = dependencyTrace,
    )

private fun kotlinxDataFrameCoreDependency(version: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.kotlinx", "dataframe-core", version),
    trace = dependencyTrace,
)

private fun composeRuntimeDependency(composeVersion: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.compose.runtime", "runtime", composeVersion),
    trace = dependencyTrace,
)

private fun composeResourcesDependency(composeVersion: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.compose.components", "components-resources", composeVersion),
    trace = dependencyTrace,
)

private fun kotlinxRpcBomDependency(kotlinxRpcVersion: TraceableString, dependencyTrace: Trace): BomDependency = BomDependency(
    coordinates = coords("org.jetbrains.kotlinx", "kotlinx-rpc-bom", kotlinxRpcVersion),
    trace = dependencyTrace,
)

private fun kotlinxRpcCoreDependency(kotlinxRpcVersion: TraceableString, dependencyTrace: Trace) = MavenDependency(
    coordinates = coords("org.jetbrains.kotlinx", "kotlinx-rpc-core", kotlinxRpcVersion),
    trace = dependencyTrace,
)

private fun ktorBomDependency(ktorVersion: TraceableString, dependencyTrace: Trace): BomDependency = BomDependency(
    coordinates = coords("io.ktor", "ktor-bom", ktorVersion),
    trace = dependencyTrace,
)

private fun springBootBomDependency(springBootVersion: TraceableString, dependencyTrace: Trace): BomDependency =
    BomDependency(
        coordinates = coords("org.springframework.boot", "spring-boot-dependencies", springBootVersion),
        trace = dependencyTrace,
    )

/**
 * Creates a new [TraceableString] with a value computed from this [TraceableString]'s value.
 * The new trace will be the same as this one.
 */
private fun coords(group: String, artifact: String, version: TraceableString) = MavenCoordinates(
    groupId = group,
    artifactId = artifact,
    version = version,
    trace = TransformedValueTrace(
        description = "injected version ${version.value} into default coordinates",
        sourceValue = version,
    ),
)

/**
 * Add automatically-added implicit dependencies to default module impl.
 */
internal fun DefaultModule.addImplicitDependencies() {
    fragments.associateWith {
        // Precompute allExternalMavenDependencies because addImplicitDependencies would affect these.
        it.allExternalMavenDependencies().mapTo(hashSetOf()) { it.coordinates.groupAndArtifact }
    }.forEach { [fragment, deps] -> fragment.addImplicitDependencies(deps) }

    mavenResolveRepositories = mavenResolveRepositories + implicitMavenRepositories(
        productType = type,
        fragments = fragments,
    )
}

private fun Fragment.addImplicitDependencies(
    explicitMavenDependencies: Set<String>,
) {
    val implicitDependencies = calculateImplicitDependencies()
    if (implicitDependencies.isEmpty()) {
        return
    }

    // we don't add an implicit dependency if it is already defined explicitly by the user (in any version)
    val nonOverriddenImplicitDeps = implicitDependencies.filterNot {
        // todo (AB) : Take classifier into account. If dependency with custom classifier is added directly,
        //  implicit one (without classifier) should be added as well.
        it.coordinates.groupAndArtifact in explicitMavenDependencies
    }

    // TODO report cases where explicit dependencies only partially override a group of related implicit dependencies.
    //   For example, an explicit `kotlin-test` dependency, but no explicit `kotlin-test-junit` dependency (in JVM).
    //   This will require the notion of "groups of implicit dependencies", and we may have to think about transitive
    //   dependencies too: what to do if the junit dependency itself is declared explicitly but not kotlin-test-junit?
    //
    //  Instead of just reporting, should we entirely avoid adding implicit dependencies from the whole group?
    //  Example: the user adds kotlin-test:1.8.20, should we add kotlin-test-junit at all? (the version could mismatch)

    val newExternalDependencies = externalDependencies + nonOverriddenImplicitDeps

    // TODO: Write this in a way that doesn't require mutable list references
    (this as DefaultFragment).externalDependencies = newExternalDependencies
}

private fun Fragment.allExternalMavenDependencies() = ancestralPath()
    .flatMap { it.externalDependencies }
    .filterIsInstance<MavenDependencyBase>()

private fun Fragment.calculateImplicitDependencies(): List<MavenDependencyBase> = buildList {
    val kotlinVersion = settings.kotlin.versionDelegate.asTraceableValue()
    add(kotlinDependencyOf("kotlin-stdlib", kotlinVersion, DefaultTrace))

    // hack for avoiding classpath clashes in android dependencies, until DR support dependency constraints from
    // Gradle module metadata
    if (platforms == setOf(Platform.ANDROID)) {
        // TODO we should trace to the android platform declaration, but we don't have access to the declared platforms
        //  traces here in the AOM.
        add(kotlinDependencyOf("kotlin-stdlib-jdk7", kotlinVersion, DefaultTrace))
        add(kotlinDependencyOf("kotlin-stdlib-jdk8", kotlinVersion, DefaultTrace))
    }

    if (isTest) {
        addAll(inferredTestDependencies())
    }
    if (settings.kotlin.serialization.enabled) {
        val kotlinSerializationVersion = settings.kotlin.serialization.versionDelegate.asTraceableValue()
        val serializationEnabledTrace = TransformedValueTrace(
            description = "because Kotlinx Serialization is enabled",
            sourceValue = settings.kotlin.serialization.enabledDelegate,
        )

        // if kotlinx.serialization plugin is enabled, we need the @Serializable annotation, which is in core
        add(kotlinxSerializationCoreDependency(kotlinSerializationVersion, dependencyTrace = serializationEnabledTrace))

        val format = settings.kotlin.serialization.format
        if (format != null && format != legacySerializationFormatNone) {
            val serializationFormatTrace = TransformedValueTrace(
                description = "because kotlin.serialization.format=$format",
                sourceValue = settings.kotlin.serialization.formatDelegate,
            )
            add(kotlinxSerializationFormatDependency(
                format = format,
                version = kotlinSerializationVersion,
                dependencyTrace = serializationFormatTrace,
            ))
        }
    }
    if (settings.kotlin.dataframe.enabled) {
        val dataframeVersion = settings.kotlin.dataframe.versionDelegate.asTraceableValue()
        val dataframeDependencyTrace = TransformedValueTrace(
            description = "because Kotlin DataFrame is enabled",
            sourceValue = settings.kotlin.dataframe.enabledDelegate,
        )
        add(kotlinxDataFrameCoreDependency(
            version = dataframeVersion,
            dependencyTrace = dataframeDependencyTrace,
        ))
    }
    if (settings.kotlin.jsPlainObjects.enabled && setOf(Platform.JS) == platforms) {
        val jsPlainObjectsDependencyTrace = TransformedValueTrace(
            description = "because Kotlin JsPlainObjects is enabled",
            sourceValue = settings.kotlin.jsPlainObjects.enabledDelegate,
        )
        add(kotlinDependencyOf(
            artifactId = "kotlin-js-plain-objects",
            version = kotlinVersion,
            dependencyTrace = jsPlainObjectsDependencyTrace,
        ))
    }
    if (settings.kotlin.powerAssert.enabled) {
        val powerAssertDependencyTrace = TransformedValueTrace(
            description = "because PowerAssert is enabled",
            sourceValue = settings.kotlin.powerAssert.enabledDelegate,
        )
        add(kotlinDependencyOf(
            artifactId = "kotlin-power-assert-runtime",
            version = kotlinVersion,
            dependencyTrace = powerAssertDependencyTrace,
        ))
    }
    if (settings.android.parcelize.enabled && setOf(Platform.JVM, Platform.ANDROID).containsAll(platforms)) {
        val parcelizeDependencyTrace = TransformedValueTrace(
            description = "because Android Parcelize is enabled",
            sourceValue = settings.android.parcelize.enabledDelegate,
        )
        add(kotlinDependencyOf("kotlin-parcelize-runtime", kotlinVersion, dependencyTrace = parcelizeDependencyTrace))
    }
    if (settings.lombok.enabled) {
        val lombokVersion = settings.lombok.versionDelegate.asTraceableValue()
        val lombokDependencyTrace = TransformedValueTrace(
            description = "because Lombok is enabled",
            sourceValue = settings.lombok.enabledDelegate,
        )
        add(lombokDependency(lombokVersion, lombokDependencyTrace))
    }
    if (settings.compose.enabled) {
        val composeVersion = settings.compose.versionDelegate.asTraceableValue()
        val composeDependencyTrace = TransformedValueTrace(
            description = "because Compose is enabled",
            sourceValue = settings.compose.enabledDelegate,
        )
        add(composeRuntimeDependency(composeVersion, dependencyTrace = composeDependencyTrace))

        // Compose resources dependency is always added when compose is enabled.
        add(composeResourcesDependency(composeVersion, dependencyTrace = composeDependencyTrace))
    }

    if (settings.kotlin.rpc.enabled) {
        val kotlinxRpcVersion = settings.kotlin.rpc.versionDelegate.asTraceableValue()
        val kotlinxRpcEnabledTrace = TransformedValueTrace(
            description = "because kotlinx.rpc is enabled",
            sourceValue = settings.kotlin.rpc.enabledDelegate,
        )
        add(kotlinxRpcCoreDependency(kotlinxRpcVersion, dependencyTrace = kotlinxRpcEnabledTrace))

        if (settings.kotlin.rpc.applyBom) {
            val kotlinxRpcBomTrace = TransformedValueTrace(
                description = "because kotlinx.rpc is enabled and kotlin.rpc.applyBom=true",
                sourceValue = if (settings.kotlin.rpc.applyBomDelegate.isExplicitlySet) {
                    settings.kotlin.rpc.applyBomDelegate
                } else {
                    settings.kotlin.rpc.enabledDelegate
                },
            )
            add(kotlinxRpcBomDependency(kotlinxRpcVersion, dependencyTrace = kotlinxRpcBomTrace))
        }
    }

    if (settings.ktor.enabled && settings.ktor.applyBom) {
        val ktorVersion = settings.ktor.versionDelegate.asTraceableValue()
        val ktorApplyBomTrace = TransformedValueTrace(
            description = "because Ktor is enabled and ktor.applyBom=true",
            sourceValue = if (settings.ktor.applyBomDelegate.isExplicitlySet) {
                settings.ktor.applyBomDelegate
            } else {
                settings.ktor.enabledDelegate
            },
        )
        add(ktorBomDependency(ktorVersion, dependencyTrace = ktorApplyBomTrace))
    }

    if (settings.springBoot.enabled && settings.springBoot.applyBom) {
        val springBootVersion = settings.springBoot.versionDelegate.asTraceableValue()
        val springBootApplyBomTrace = TransformedValueTrace(
            description = "because Spring Boot is enabled and springBoot.applyBom=true",
            sourceValue = if (settings.springBoot.applyBomDelegate.isExplicitlySet) {
                // TODO: Was there a copy-paste bug?
                settings.springBoot.applyBomDelegate
            } else {
                settings.springBoot.enabledDelegate
            },
        )
        add(springBootBomDependency(springBootVersion, dependencyTrace = springBootApplyBomTrace))
    }

    if (module.type == ProductType.JVM_AMPER_PLUGIN) {
        // TODO: It'd be better to have some builtin dependency that resolves to a jar inside Amper distribution.
        add(MavenDependency(
            coordinates = MavenCoordinates(
                groupId = "org.jetbrains.amper",
                artifactId = "amper-extensibility-api",
                version = TraceableString(AmperBuild.mavenVersion, DefaultTrace),
                trace = DefaultTrace,
            ),
            // TODO we should trace to the product type, but we don't seem to have this trace in the AOM
            trace = DefaultTrace,
        ))
    }
}

private fun Fragment.inferredTestDependencies(): List<MavenDependency> = buildList {
    val kotlinVersion = settings.kotlin.versionDelegate.asTraceableValue()
    if (platforms.size == 1 && platforms.single().supportsJvmTestFrameworks()) {
        val junitTrace = TransformedValueTrace(
            description = "because the test engine is ${settings.junit.schemaValue}",
            sourceValue = settings.junitDelegate,
        )
        when (settings.junit) {
            // TODO support kotlin-test-testng?
            //   For this, we should rename settings.junit -> settings.jvm.testFramework and add the TESTNG value to the enum
            JUnitVersion.JUNIT4 -> add(kotlinDependencyOf("kotlin-test-junit", kotlinVersion, junitTrace))
            JUnitVersion.JUNIT5 -> add(kotlinDependencyOf("kotlin-test-junit5", kotlinVersion, junitTrace))
            JUnitVersion.NONE -> add(kotlinDependencyOf("kotlin-test", kotlinVersion, DefaultTrace))
        }
    } else {
        add(kotlinDependencyOf("kotlin-test", kotlinVersion, DefaultTrace))
        add(kotlinDependencyOf("kotlin-test-annotations-common", kotlinVersion, DefaultTrace))
    }
}

private fun Platform.supportsJvmTestFrameworks() = this == Platform.JVM || this == Platform.ANDROID

private val MavenCoordinates.groupAndArtifact: String
    get() = "${groupId}:${artifactId}"

private fun implicitMavenRepositories(
    productType: ProductType,
    fragments: List<Fragment>,
): List<ResolutionRepository> {
    return buildList {
        val isHotReloadRuntimeApiPresent = fragments
            .flatMap { it.externalDependencies }
            .filterIsInstance<MavenDependency>()
            .any { it.coordinates.groupAndArtifact == "org.jetbrains.compose.hot-reload:hot-reload-runtime-api" }
        if (isHotReloadRuntimeApiPresent) {
            add(
                ResolutionRepository(
                    id = "amper-hot-reload-dev",
                    url = "https://packages.jetbrains.team/maven/p/amper/compose-hot-reload",
                )
            )
        }

        if (productType == ProductType.JVM_AMPER_PLUGIN) {
            if (AmperBuild.isSNAPSHOT) {
                add(
                    ResolutionRepository(
                        id = "maven-local-resolve",
                        url = SpecialMavenLocalUrl,
                    )
                )
            } else {
                add(
                    ResolutionRepository(
                        id = "amper-maven",
                        url = pluginApiRepositoryUrl(),
                    )
                )
            }
        }
    }
}

internal const val DefaultAmperRepositoryUrl = "https://packages.jetbrains.team/maven/p/amper/amper"

/**
 * The repository that holds the `amper-extensibility-api` a module of type `jvm/amper-plugin` implicitly
 * depends on, at the version of the distribution that builds it.
 *
 * That artifact is published next to the distribution itself, so a distribution served from anywhere
 * other than [DefaultAmperRepositoryUrl] - a mirror, a fork, a build published inside a company - holds
 * it in the repository it was downloaded from, and in no other. [downloadRoot], which the wrapper
 * scripts report through the `KOTLIN_CLI_DOWNLOAD_ROOT` environment variable, is where that is; the
 * default repository is used when it says nothing, which is the case when the distribution was not
 * started through a wrapper script.
 */
internal fun pluginApiRepositoryUrl(
    downloadRoot: String? = System.getenv("KOTLIN_CLI_DOWNLOAD_ROOT"),
): String = downloadRoot
    ?.trim()
    ?.trimEnd('/')
    ?.takeIf { it.isNotEmpty() }
    ?: DefaultAmperRepositoryUrl
