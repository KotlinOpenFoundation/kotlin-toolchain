/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */
package org.jetbrains.amper.frontend.project

import com.intellij.openapi.vfs.VfsUtilCore
import com.intellij.openapi.vfs.VirtualFile
import io.opentelemetry.api.common.Attributes
import org.jetbrains.amper.core.UsedInIdePlugin
import org.jetbrains.amper.frontend.FrontendPathResolver
import org.jetbrains.amper.frontend.VersionCatalog
import org.jetbrains.amper.frontend.aomBuilder.readProject
import org.jetbrains.amper.frontend.api.TraceableString
import org.jetbrains.amper.frontend.asBuildProblemSource
import org.jetbrains.amper.frontend.catalogs.parseGradleVersionCatalog
import org.jetbrains.amper.frontend.diagnostics.UnresolvedModuleDeclaration
import org.jetbrains.amper.frontend.reportBundleError
import org.jetbrains.amper.frontend.schema.MavenPlugin
import org.jetbrains.amper.frontend.schema.Project
import org.jetbrains.amper.frontend.types.generated.*
import org.jetbrains.amper.problems.reporting.BuildProblemType
import org.jetbrains.amper.problems.reporting.GlobalBuildProblemSource
import org.jetbrains.amper.problems.reporting.Level
import org.jetbrains.amper.problems.reporting.NonIdealDiagnostic
import org.jetbrains.amper.problems.reporting.ProblemReporter
import org.jetbrains.amper.telemetry.spanBuilder
import org.jetbrains.amper.telemetry.useWithoutCoroutines
import java.nio.file.Path
import java.util.regex.PatternSyntaxException
import kotlin.io.path.createDirectories
import kotlin.io.path.relativeTo

private val amperProjectFileNames = setOf("project.yaml", "project.amper")

@UsedInIdePlugin
class StandaloneAmperProjectContext(
    override val frontendPathResolver: FrontendPathResolver,
    projectRootDir: VirtualFile,
    projectBuildDir: Path?,
    override val amperModuleFiles: List<VirtualFile>,
    override val enabledLocalAmperPluginModuleFiles: List<VirtualFile>,
    override val externalMavenPlugins: List<MavenPlugin>,
) : AmperProjectContext {

    override val projectRoot by lazy {
        AmperFrontendProjectRoot(projectRootDir)
    }

    override val projectBuildDir: Path by lazy {
        (projectBuildDir ?: projectRootDir.toNioPath().resolve("build")).createDirectories()
    }

    override val projectVersionsCatalog: VersionCatalog? by lazy {
        val catalogFile = projectRootDir.findChild("libs.versions.toml")
            ?: projectRootDir.findChild("gradle")?.findChild("libs.versions.toml")
        catalogFile?.let { catalogFile ->
            frontendPathResolver.parseGradleVersionCatalog(catalogFile)
        }
    }

    companion object {
        context(_: ProblemReporter)
        internal fun find(
            start: VirtualFile,
            buildDir: Path?,
            frontendPathResolver: FrontendPathResolver,
        ): AmperProjectContext? {
            val result = preSearchProjectRoot(start = start) ?: return null

            val potentialContext = spanBuilder("Create candidate project context")
                .setAttribute("potential-root", result.potentialRoot.presentableUrl)
                .useWithoutCoroutines {
                    create(result.potentialRoot, buildDir, frontendPathResolver)
                        ?: error("potentialRoot should point to a valid project root")
                }

            if (result.startModuleFile != null && result.startModuleFile !in potentialContext.amperModuleFiles) {
                // We found a module file while going up, and the project file higher up doesn't include it.
                // This means that the potential context (defined by the project file) is not our actual context,
                // we're just a single module project.
                return StandaloneAmperProjectContext(
                    frontendPathResolver = frontendPathResolver,
                    projectRootDir = result.startModuleFile.parent,
                    projectBuildDir = buildDir,
                    amperModuleFiles = listOf(result.startModuleFile),
                    enabledLocalAmperPluginModuleFiles = emptyList(), // no plugins for the single-module project.
                    externalMavenPlugins = emptyList(), // no maven plugins for the single-module project.
                )
            }
            return potentialContext
        }

        /**
         * Creates an [AmperProjectContext] for the specified [rootDir] based on the contained project or module file.
         * If there is no project file nor module file in the given directory, null is returned and the caller is
         * responsible for handling the situation (only the caller knows whether this is a valid situation).
         *
         * The given [frontendPathResolver] is used to resolve virtual files and PSI files.
         */
        @OptIn(NonIdealDiagnostic::class)
        context(problemReporter: ProblemReporter)
        internal fun create(
            rootDir: VirtualFile,
            buildDir: Path?,
            frontendPathResolver: FrontendPathResolver,
        ): AmperProjectContext? {
            val rootModuleFile = rootDir.findChildMatchingAnyOf(amperModuleFileNames)
            val amperProject = with(frontendPathResolver) { parseAmperProject(rootDir) }

            if (rootModuleFile == null && amperProject == null) {
                return null
            }

            val explicitProjectModuleFiles = amperProject?.modulePaths(rootDir) ?: emptyList()
            val amperModuleFiles = listOfNotNull(rootModuleFile) + explicitProjectModuleFiles
            if (amperModuleFiles.isEmpty()) {
                problemReporter.reportBundleError(
                    source = amperProject?.asBuildProblemSource() ?: GlobalBuildProblemSource,
                    diagnosticId = ProjectDiagnosticId.ProjectHasNoModules,
                    messageKey = "project.has.no.modules",
                    rootDir.presentableUrl,
                    level = Level.Warning,
                )
            }

            val explicitModulePaths = amperProject?.modules?.map {
                // `./` prefix shouldn't affect ordering
                it.value.removePrefix("./")
            }
            if (!explicitModulePaths.isNullOrEmpty()) {
                val sortedList = explicitModulePaths.sorted()
                if (sortedList != explicitModulePaths) {
                    problemReporter.reportBundleError(
                        source = amperProject.modulesDelegate.asBuildProblemSource(),
                        diagnosticId = ProjectDiagnosticId.ModuleListShouldBeSorted,
                        messageKey = "project.module.list.should.be.sorted",
                        level = Level.WeakWarning,
                    )
                }
            }

            val localPluginDependencies = amperProject?.plugins.orEmpty().mapNotNull { dependency ->
                val pluginModuleFile = frontendPathResolver.loadVirtualFileOrNull(dependency.path)
                    ?.findChildMatchingAnyOf(amperModuleFileNames)
                when (pluginModuleFile) {
                    null -> {
                        problemReporter.reportBundleError(
                            source = dependency.trace.asBuildProblemSource(),
                            diagnosticId = ProjectDiagnosticId.PluginDependencyNotFound,
                            messageKey = "plugin.dependency.not.found",
                            dependency.path.relativeTo(rootDir.toNioPath())
                        ); null
                    }
                    !in amperModuleFiles -> {
                        // TODO: Quickfix?
                        problemReporter.reportBundleError(
                            source = dependency.trace.asBuildProblemSource(),
                            diagnosticId = ProjectDiagnosticId.PluginDependencyNotIncludedAsModule,
                            messageKey = "plugin.dependency.not.included",
                            dependency.path.relativeTo(rootDir.toNioPath())
                        ); null
                    }
                    else -> pluginModuleFile
                }
            }

            return StandaloneAmperProjectContext(
                frontendPathResolver = frontendPathResolver,
                projectRootDir = rootDir,
                projectBuildDir = buildDir,
                amperModuleFiles = amperModuleFiles,
                enabledLocalAmperPluginModuleFiles = localPluginDependencies,
                externalMavenPlugins = amperProject?.mavenPlugins.orEmpty(),
            )
        }
    }
}

private data class RootSearchResult(
    /**
     * A directory containing either a project file or a module file, and that is a potential root for the project.
     * It might be the root of an unrelated project higher in the file system hierarchy, so we still need to verify that
     * [startModuleFile], if present, is part of that project.
     */
    val potentialRoot: VirtualFile,
    /**
     * The first module file that was found while going up the file system hierarchy (if any), and which must be
     * included in the current project.
     * It defines the root of the project unless a project file is found higher up and includes this module.
     */
    val startModuleFile: VirtualFile?,
)

/**
 * Attempts to find the project root directory in an Amper project from the given [start] point.
 *
 * In practice, this function goes up the file hierarchy and looks for module files or a project file along the way.
 * The returned [RootSearchResult] is a record of what was found.
 * If neither a project file nor a module file are found, we don't have an Amper project and null is returned.
 */
private fun preSearchProjectRoot(start: VirtualFile): RootSearchResult? = spanBuilder("Pre-search project root")
    .setAttribute("start", start.path)
    .useWithoutCoroutines block@{ span ->
        var currentDir: VirtualFile? = if (start.isDirectory) start else start.parent
        var closestModuleFile: VirtualFile? = null
        while (currentDir != null) {
            if (currentDir.hasChildMatchingAnyOf(amperProjectFileNames)) {
                return@block RootSearchResult(potentialRoot = currentDir, startModuleFile = closestModuleFile)
            }
            if (closestModuleFile == null) {
                val moduleFile = currentDir.findChildMatchingAnyOf(amperModuleFileNames)
                if (moduleFile != null) {
                    span.addEvent(
                        "found start module file",
                        Attributes.builder().put("path", moduleFile.presentableUrl).build()
                    )
                    closestModuleFile = moduleFile
                }
            }
            currentDir = currentDir.parent
        }
        if (closestModuleFile != null) {
            return@block RootSearchResult(potentialRoot = closestModuleFile.parent, startModuleFile = closestModuleFile)
        }
        null // neither project nor module file found
    }

context(_: ProblemReporter, frontendPathResolver: FrontendPathResolver)
private fun parseAmperProject(projectRootDir: VirtualFile): Project? {
    val projectFile = projectRootDir.findChildMatchingAnyOf(amperProjectFileNames) ?: return null
    return spanBuilder("Parse Kotlin project file")
        .setAttribute("project-file", projectFile.path)
        .useWithoutCoroutines {
            context(AmperFrontendProjectRoot(projectRootDir)) {
                readProject(projectFile)
            }
        }
}

context(_: ProblemReporter)
private fun Project.modulePaths(projectRootDir: VirtualFile): List<VirtualFile> =
    spanBuilder("Resolve module paths from project file")
        .setAttribute("module-count", modules.size.toString())
        .useWithoutCoroutines {
            modules
                .flatMap { modulePathOrGlob -> projectRootDir.resolveMatchingModuleFiles(modulePathOrGlob) }
                .distinct() // TODO report error/warning for duplicates
        }

context(_: ProblemReporter)
private fun VirtualFile.resolveMatchingModuleFiles(relativeModulePathOrGlob: TraceableString): List<VirtualFile> {
    // avoid walking the file tree if it's just a plain path (not a glob)
    if (!relativeModulePathOrGlob.value.hasGlobCharacters()) {
        return listOfNotNull(resolveModuleFileOrNull(relativeModulePathOrGlob))
    }
    return resolveModuleFilesRecursively(relativeModulePathOrGlob)
}

context(problemReporter: ProblemReporter)
private fun VirtualFile.resolveModuleFileOrNull(relativeModulePath: TraceableString): VirtualFile? {
    val moduleDir = findFileByRelativePath(relativeModulePath.value)
    if (moduleDir == null) {
        problemReporter.reportMessage(UnresolvedModuleDeclaration(relativeModulePath))
        return null
    }
    if (!moduleDir.isDirectory) {
        problemReporter.reportBundleError(
            source = relativeModulePath.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.ModuleReferenceIsNotDirectory,
            messageKey = "project.module.path.0.is.not.a.directory",
            relativeModulePath.value,
            level = Level.Error,
            problemType = BuildProblemType.TypeMismatch,
        )
        return null
    }
    val moduleFile = moduleDir.findChildMatchingAnyOf(amperModuleFileNames)
    if (moduleFile == null) {
        problemReporter.reportBundleError(
            source = relativeModulePath.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.ModuleDirectoryHasNoModuleFile,
            messageKey = "project.module.dir.0.has.no.module.file",
            relativeModulePath.value,
            level = Level.Error,
        )
        return null
    }
    if (moduleDir.url == url) {
        problemReporter.reportBundleError(
            source = relativeModulePath.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.ModuleRootIsIncludedByDefault,
            messageKey = "project.module.root.is.included.by.default",
            level = Level.WeakWarning,
            problemType = BuildProblemType.RedundantDeclaration,
        )
        return null
    }
    if (!VfsUtilCore.isAncestor(this, moduleDir, false)) {
        problemReporter.reportBundleError(
            source = relativeModulePath.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.ModuleDirectoryIsNotUnderRoot,
            messageKey = "project.module.dir.0.is.not.under.root",
            relativeModulePath.value,
            level = Level.Error,
        )
        return null
    }
    // We use the canonicalFile because we want paths to be normalized. Since our model parser normalizes paths
    // automatically, we rely on this "paths are normalized" invariant throughout the frontend, so we need to respect
    // it here (otherwise this breaks maps with paths as keys).
    return moduleFile.canonicalFile
}

context(problemReporter: ProblemReporter)
private fun VirtualFile.resolveModuleFilesRecursively(moduleDirGlob: TraceableString): List<VirtualFile> {
    val moduleFileNamesCommaSeparated = amperModuleFileNames.joinToString(",")
    val moduleFilesGlobPattern = "${moduleDirGlob.value}/{$moduleFileNamesCommaSeparated}"
    val moduleFilesGlob = try {
        Glob(moduleFilesGlobPattern)
    } catch (_: PatternSyntaxException) {
        reportInvalidGlob(moduleDirGlob, moduleFilesGlobPattern)
        return emptyList()
    }
    if ("**" in moduleDirGlob.value) {
        problemReporter.reportBundleError(
            source = moduleDirGlob.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.DoubleStarNotSupportedInGlobs,
            messageKey = "project.module.glob.0.double.star.not.supported",
            moduleDirGlob.value,
            level = Level.Error,
        )
        return emptyList()
    }
    val matchingModuleFiles = this.findAllDescendantsMatching(glob = moduleFilesGlob)
    if (matchingModuleFiles.isEmpty()) {
        problemReporter.reportBundleError(
            source = moduleDirGlob.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.GlobMatchesNothing,
            messageKey = "project.module.glob.0.matches.nothing",
            moduleDirGlob.value,
            level = Level.WeakWarning,
            problemType = BuildProblemType.RedundantDeclaration,
        )
    }
    return matchingModuleFiles
}

context(problemReporter: ProblemReporter)
private fun reportInvalidGlob(moduleDirGlob: TraceableString, generatedModuleFilesGlob: String) {
    try {
        // we want to generate a glob syntax error for the exact user-provided string, not our own construction
        Glob.checkValid(moduleDirGlob.value)
        // If the user glob succeeds on its own, we have a bug in our code which creates an invalid glob for module files
        error("Invalid glob '$generatedModuleFilesGlob' constructed internally for a valid user-provided glob '${moduleDirGlob.value}'")
    } catch (e: PatternSyntaxException) {
        problemReporter.reportBundleError(
            source = moduleDirGlob.asBuildProblemSource(),
            diagnosticId = ProjectDiagnosticId.InvalidGlobPattern,
            messageKey = "project.module.glob.0.is.invalid.1",
            moduleDirGlob.value,
            e.message ?: "(no additional information)",
            level = Level.Error,
        )
    }
}

/**
 * Returns all descendants of this directory that match the given [glob].
 */
private fun VirtualFile.findAllDescendantsMatching(glob: Glob): List<VirtualFile> {
    val base = this.toNioPath()

    // TODO we could optimize the search here because we know the depth up front (** is forbidden)
    return filterDescendants { file ->
        val pathToTest = file.toNioPath().relativeTo(base)
        glob.matches(pathToTest)
    }
}
