/*
 * Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package org.jetbrains.amper.frontend.diagnostics

import org.jetbrains.amper.problems.reporting.DiagnosticId

/**
 * Diagnostics reported about module semantics (module and template files).
 */
enum class FrontendDiagnosticId : DiagnosticId {
    AliasExpandsToNothing,
    AliasInSinglePlatformModule,
    AliasIntersectsWithNaturalHierarchy,
    AliasIsEmpty,
    AliasUsesNonLeafPlatform,
    AliasUsesUndeclaredPlatform,
    AndroidApplicationIdMissing,
    AndroidSettingCannotBeNull,
    AndroidVersionShouldBeAtLeastMinSdk,
    AndroidVersionTooOld,
    ComposeMaterial3UnknownVersionMapping,
    ComposeHotReloadVersionMismatch,
    ComposeVersionWithoutCompose,
    CredentialsFileDoesNotExist,
    CredentialsFileDoesNotHaveKey,
    DependencyResolutionProblem,
    DependencyVersionIsOverridden,
    IncorrectSettingsSection,
    InvalidKotlinCompilerVersion,
    InvalidXmlForPlexusConfiguration,
    JavaIncrementalCompilationRequiresJava16,
    JdkDistributionRequiresLicense,
    JdkVersionTooLow,
    JvmReleaseTooLowForDependency,
    KeystoreFileDoesNotExist,
    KeystorePropertiesDoesNotContainKey,
    NotifyKlibsIoRequiresMultiplatform,
    KotlinCompilerVersionTooLow,
    KotlinIncrementalCompilationMayBehaveIncorrectly,
    KotlinVersionDoesNotSupportJdk,
    LocalSwiftPackageInRemotePublication,
    LocalSwiftPackageOutsideProject,
    MandatoryFieldInPropertiesFileMustBePresent,
    MavenCentralPublishingEnabledButPublishingDisabled,
    ModuleDependencyDoesntHaveNeededPlatforms,
    ModuleDependencyLoopProblem,
    ModuleDependencySelfProblem,
    NoCatalogValue,
    ObsoleteLibProductType,
    ProductNotDefined,
    ProductPlatformsShouldNotBeEmpty,
    ProductTypeDoesNotSupportPlatform,
    ProductTypeHasNoDefaultPlatforms,
    PublishingSettingsMissingInDependencies,
    RequiredPropertiesMissingForMavenCentralPublication,
    SerializationVersionWithoutSerialization,
    SigningEnabledWithoutPropertiesFile,
    SigningIsRequiredForMavenCentralPublication,
    SourcesJarIsRequiredForMavenCentralPublication,
    SwiftPMDependencyInNonApplePlatform,
    TemplateApplicationLoop,
    TemplateNameWithoutPostfix,
    TestOnlySwiftPMDependency,
    UnknownPluginId,
    UnknownProperty,
    UnknownPropertyInUserControlledType,
    UnknownQualifiers,
    UnresolvedModuleDeclaration,
    UnresolvedModuleDependency,
    UnresolvedTemplate,
    UnsupportedLayout,
    @Deprecated(
        message = "The corresponding diagnostic no longer exists, remove the support.",
        level = DeprecationLevel.ERROR,
    )
    UselessSetting,
    @Deprecated(
        message = "Blank versions are now reported as TreeDiagnosticId.BlankValueNotAllowed, " +
                "via the @NotBlank annotation on the version properties.",
        level = DeprecationLevel.ERROR,
        replaceWith = ReplaceWith("BlankValueNotAllowed", imports = ["org.jetbrains.amper.frontend.tree.TreeDiagnosticId.BlankValueNotAllowed"])
    )
    VersionCannotBeEmpty,
}
